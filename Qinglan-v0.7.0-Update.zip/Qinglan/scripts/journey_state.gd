extends RefCounted
const F = preload("res://scripts/furnishing_rules.gd")
const E = preload("res://scripts/expansion_state.gd")
var sect_stage := 0
var clues := 0
var support := 0
var hunts := 0
var rite := false
var contribution := 0
var contract := ""
var contract_count := 0
var contract_clues := 0
var tracking := false
var stock := F.STOCK.duplicate()
var layout: Array = F.initial_layout()
var next_furniture := 3

func snapshot() -> Dictionary:
 return {"sect_stage":sect_stage,"clues":clues,"support":support,"hunts":hunts,"rite":rite,"contribution":contribution,"contract":contract,"contract_count":contract_count,"contract_clues":contract_clues,"tracking":tracking,"stock":stock.duplicate(),"layout":layout.duplicate(true),"next_furniture":next_furniture}

func restore(data: Variant) -> bool:
 if not data is Dictionary: return false
 for key in snapshot():
  if not data.has(key): return false
 for pair in [["sect_stage",4],["clues",3],["support",2],["hunts",7],["contribution",100000],["contract_count",2],["contract_clues",3],["next_furniture",100000000]]:
  if not E.integer(data[pair[0]],0,pair[1]): return false
 if data.next_furniture<3 or not data.rite is bool or not data.tracking is bool or data.contract not in ["","hunt","trace"]: return false
 if data.sect_stage>=2 and data.clues!=3: return false
 if (data.sect_stage<2 and data.support!=0) or (data.sect_stage>=3 and data.support==0): return false
 if data.sect_stage<3 and (data.hunts!=0 or data.rite): return false
 if data.rite and data.hunts!=7: return false
 if data.sect_stage==4 and not data.rite: return false
 if data.sect_stage<4 and not data.contract.is_empty(): return false
 if not data.stock is Dictionary or data.stock.size()!=F.STOCK.size(): return false
 for kind in F.STOCK:
  if not E.integer(data.stock.get(kind),0,30): return false
 if not data.layout is Array: return false
 var ids := []
 for item in data.layout:
  if not item is Dictionary or item.size()!=5 or not E.integer(item.get("uid"),1) or item.uid>=data.next_furniture or int(item.uid) in ids or not E.integer(item.get("turn"),0,3): return false
  if not item.get("kind") is String or not F.KINDS.has(item.kind): return false
  for key in ["x","z"]:
   var value: Variant = item.get(key)
   if not (value is int or value is float) or not is_finite(float(value)) or absf(value)>9: return false
  ids.append(int(item.uid))
 if not F.valid_layout(data.layout): return false
 sect_stage=int(data.sect_stage);clues=int(data.clues);support=int(data.support);hunts=int(data.hunts);rite=data.rite
 contribution=int(data.contribution);contract=data.contract;contract_count=int(data.contract_count);contract_clues=int(data.contract_clues);tracking=data.tracking
 stock=data.stock.duplicate();layout=data.layout.duplicate(true);next_furniture=int(data.next_furniture)
 for kind in stock: stock[kind]=int(stock[kind])
 for item in layout: item.uid=int(item.uid);item.turn=int(item.turn);item.x=float(item.x);item.z=float(item.z)
 return true

func field_kill(species: int) -> void:
 if sect_stage==3 and species in [0,1,2]: hunts |= 1<<species
 if contract=="hunt": contract_count=mini(2,contract_count+1)

func investigate(index: int) -> bool:
 if index not in [0,1]: return false
 var bit := 1<<index
 var changed := false
 if sect_stage==1 and not clues&bit:
  clues |= bit
  changed=true
 if contract=="trace" and not contract_clues&bit:
  contract_clues |= bit
  changed=true
 return changed

func aid(p: RefCounted, choice: int) -> bool:
 if sect_stage!=2 or support!=0 or choice not in [1,2]: return false
 var item := "herb" if choice==1 else "ore"
 var count := 4 if choice==1 else 3
 if p.item_count(item)<count: return false
 p.add_item(item,-count)
 support=choice
 return true

func turn_in(p: RefCounted) -> bool:
 if contribution>99870 or p.coins>99999800: return false
 match sect_stage:
  0:
   if not p.learned or p.realm!=1: return false
   tracking=true
  1:
   if clues!=3: return false
   p.coins+=40;contribution+=20
  2:
   if support==0: return false
   contribution+=30
  3:
   if not rite or hunts!=7 or p.expansion.gear.size()>=p.expansion.MAX_GEAR: return false
   p.expansion.add_gear("moss_robe")
   p.coins+=100;contribution+=80
  _: return false
 sect_stage+=1
 return true

func accept_contract(kind: String) -> bool:
 if sect_stage!=4 or not contract.is_empty() or kind not in ["hunt","trace"]: return false
 contract=kind;contract_count=0;contract_clues=0;tracking=true
 return true

func claim_contract(p: RefCounted) -> bool:
 if contribution>99975 or p.coins>99999965: return false
 if not ((contract=="hunt" and contract_count>=2) or (contract=="trace" and contract_clues==3)): return false
 contribution+=25;p.coins+=35;contract="";contract_count=0;contract_clues=0
 return true

func buy_furniture(kind: String, p: RefCounted) -> bool:
 if not stock.has(kind) or stock[kind]>=30: return false
 var data: Dictionary = F.KINDS[kind]
 if data.get("sect",false):
  if sect_stage!=4 or contribution<int(data.price): return false
  contribution-=int(data.price)
 else:
  if p.coins<int(data.price): return false
  p.coins-=int(data.price)
 stock[kind]+=1
 return true

func place(kind: String, at: Vector2, turn: int, uid := 0) -> bool:
 if not F.KINDS.has(kind) or turn not in [0,1,2,3] or not is_finite(at.x) or not is_finite(at.y): return false
 var next := layout.duplicate(true)
 if uid:
  var found := false
  for item in next:
   if int(item.uid)==uid:
    if item.kind!=kind: return false
    item.x=at.x;item.z=at.y;item.turn=turn;found=true
  if not found: return false
 else:
  if not stock.has(kind) or stock[kind]<=0 or next_furniture>=100000000: return false
  next.append({"uid":next_furniture,"kind":kind,"x":at.x,"z":at.y,"turn":turn})
 if not F.valid_layout(next): return false
 layout=next
 if not uid:
  stock[kind]-=1;next_furniture+=1
 return true

func collect_furniture(uid: int) -> bool:
 for i in range(layout.size()):
  var item: Dictionary = layout[i]
  if int(item.uid)!=uid: continue
  if not stock.has(item.kind) or stock[item.kind]>=30: return false
  var next:=layout.duplicate(true)
  next.remove_at(i)
  if not F.valid_layout(next): return false
  stock[item.kind]+=1;layout=next
  return true
 return false
