extends RefCounted
## Pure gameplay state. No renderer or device-specific input dependencies.

const Rules = preload("res://scripts/world_rules.gd")
const C = preload("res://scripts/catalog.gd")
const Expansion = preload("res://scripts/expansion_state.gd")
const VERSION := 5
var expansion = Expansion.new()
const HERB_COUNT := 5
const ROBES := ["青灰", "墨绿", "赭红"]
var character_name := "无名"
var robe := 0
var learned := false
var collected: Array[int] = []
var beast_cores := 0
var core: bool:
	get:
		return beast_cores > 0
	set(value):
		beast_cores = maxi(1, beast_cores) if value else 0
var beast_dead := false
var realm := 0
var hp := 100.0
var qi := 100.0
var herb_stock := 0
var home_claimed := false
var home_style := 0
var vault_herbs := 0
var vault_items := {"core": 0, "seed": 0, "heal": 0, "mana": 0}
var inside_home := false
var seeds := 0
var plots: Array[float] = [-1.0, -1.0, -1.0]
var world_time := 0.0
var cultivation := 0
var runes := 0
var spitter_dead := false
var guardian_dead := false
var relic := false
var coins := 30
var heal_potions := 0
var mana_potions := 0
var weapon_level := 0
var active_order := ""
var orders_completed := 0
var surveyed := false
var pending_loot: Array = []
var next_loot_id := 1
var monster_ready := {}
var herb_ready := {}
const GROW_SECONDS := 90.0

func max_hp() -> float:
	return (140.0 if realm == 1 else 100.0) + cultivation * 5 + weapon_level * 8 + expansion.bonuses().hp

func max_qi() -> float:
	return (140.0 if realm == 1 else 100.0) + cultivation * 10 + weapon_level * 5 + expansion.bonuses().qi

func damage_bonus() -> float:
	return expansion.bonuses().attack + (8 if expansion.focus_until > world_time else 0)

func herbs() -> int:
	return herb_stock

func gather(id: int) -> bool:
	if id < 0 or id >= HERB_COUNT or id in collected:
		return false
	collected.append(id)
	herb_stock += 1
	return true

func cast() -> bool:
	if not learned or qi < 14.0 or hp <= 0.0:
		return false
	qi -= 14.0
	return true

func breakthrough() -> bool:
	if realm != 0 or not learned or not core or herbs() < 3:
		return false
	realm = 1
	herb_stock -= 3
	beast_cores -= 1
	hp = max_hp()
	qi = max_qi()
	return true

func spend_qi(amount: float) -> bool:
	if not learned or amount <= 0 or qi < amount or hp <= 0:
		return false
	qi -= amount
	return true

func claim_home() -> bool:
	if home_claimed:
		return false
	home_claimed = true
	seeds += 3
	return true

func plant_or_harvest(id: int) -> String:
	if not home_claimed or id < 0 or id >= plots.size():
		return "先认领洞府，才能使用灵田。"
	if plots[id] < 0:
		if seeds <= 0:
			return "没有灵种。遗府传承也会赠送灵种。"
		seeds -= 1
		plots[id] = world_time + GROW_SECONDS
		return "种下灵草：游玩 90 秒后成熟，暂停与离线不计时。"
	if world_time < plots[id]:
		return "灵草尚未成熟，还需 %d 秒。" % ceili(plots[id] - world_time)
	plots[id] = -1
	herb_stock += 2
	seeds += 1
	return "收获两株灵草，并回收一枚灵种。"

func transfer_herb(to_vault: bool) -> bool:
	return transfer_item("herb", to_vault, 1)

func item_count(item: String, in_vault := false) -> int:
	if item in C.MATERIALS:
		return int(expansion.vault[item] if in_vault else expansion.materials[item])
	if in_vault:
		return vault_herbs if item == "herb" else int(vault_items.get(item, 0))
	match item:
		"herb": return herb_stock
		"core": return beast_cores
		"seed": return seeds
		"heal": return heal_potions
		"mana": return mana_potions
	return 0

func transfer_item(item: String, to_vault: bool, amount := 1) -> bool:
	if not home_claimed or item not in ["herb", "core", "seed", "heal", "mana"] + C.MATERIALS or amount < 1 or amount > 100000:
		return false
	if item_count(item, not to_vault) < amount or item_count(item, to_vault) + amount > 100000:
		return false
	var change := amount if to_vault else -amount
	if item in C.MATERIALS:
		expansion.vault[item] += change
		expansion.materials[item] -= change
	elif item == "herb":
		vault_herbs += change
		herb_stock -= change
	else:
		vault_items[item] += change
		match item:
			"core": beast_cores -= change
			"seed": seeds -= change
			"heal": heal_potions -= change
			"mana": mana_potions -= change
	return true

func cultivate() -> bool:
	if not home_claimed or not learned or herbs() < 2 or cultivation >= 3:
		return false
	herb_stock -= 2
	cultivation += 1
	hp = max_hp()
	qi = max_qi()
	return true

func activate_rune(id: int) -> bool:
	if runes == 3 or id < 0 or id > 2:
		return false
	if id != runes:
		runes = 0
		return false
	runes += 1
	return true

func take_relic() -> bool:
	if relic or not guardian_dead or runes != 3 or realm != 1:
		return false
	relic = true
	seeds += 3
	return true

func add_item(item: String, amount: int) -> void:
	if item in C.MATERIALS:
		expansion.materials[item] += amount
		return
	match item:
		"herb": herb_stock += amount
		"core": beast_cores += amount
		"seed": seeds += amount
		"heal": heal_potions += amount
		"mana": mana_potions += amount
		"coins": coins += amount

func buy(item: String) -> bool:
	if not Rules.BUY.has(item) or coins < Rules.BUY[item] or item_count(item) >= 100000:
		return false
	coins -= Rules.BUY[item]
	add_item(item, 1)
	return true

func sell(item: String) -> bool:
	if not Rules.SELL.has(item) or item_count(item) < 1: return false
	add_item(item, -1)
	coins += Rules.SELL[item]
	return true

func upgrade_cost() -> int:
	return 60 + weapon_level * 45

func upgrade_weapon() -> bool:
	if weapon_level >= 8 or coins < upgrade_cost():
		return false
	coins -= upgrade_cost()
	weapon_level += 1
	return true

func use_potion(kind: String) -> bool:
	if kind == "focus" and expansion.materials.focus > 0 and expansion.focus_until <= world_time:
		expansion.materials.focus -= 1
		expansion.focus_until = world_time + 120
		return true
	if kind == "heal" and heal_potions > 0 and hp < max_hp():
		heal_potions -= 1
		hp = minf(max_hp(), hp + 60)
		return true
	if kind == "mana" and mana_potions > 0 and qi < max_qi():
		mana_potions -= 1
		qi = minf(max_qi(), qi + 60)
		return true
	return false

func accept_order(kind: String) -> bool:
	if not active_order.is_empty() or not Rules.ORDER_REWARDS.has(kind):
		return false
	active_order = kind
	surveyed = false
	return true

func order_ready() -> bool:
	match active_order:
		"herbs": return herb_stock >= 3
		"hunt": return beast_cores >= 2
		"survey": return surveyed
		"brew": return heal_potions >= 2
	return false

func complete_order() -> bool:
	if not order_ready():
		return false
	if active_order == "herbs":
		herb_stock -= 3
	elif active_order == "hunt":
		beast_cores -= 2
	elif active_order == "brew":
		heal_potions -= 2
	coins += Rules.ORDER_REWARDS[active_order]
	orders_completed += 1
	active_order = ""
	surveyed = false
	return true

func add_loot(item: String, count: int, at: Vector3) -> int:
	if item not in C.NAMES or count <= 0:
		return -1
	for record in pending_loot:
		var position := Vector3(record.position[0], 0, record.position[2])
		if record.item == item and (position.distance_to(at) < 1.5 or pending_loot.size() >= 240):
			record.count += count
			return int(record.uid)
	var id := next_loot_id
	next_loot_id += 1
	pending_loot.append({"uid": id, "item": item, "count": count, "position": [at.x, 0.2, at.z]})
	return id

func add_gear_loot(gear_id: String, at: Vector3) -> int:
	if not C.GEAR.has(gear_id): return -1
	if pending_loot.size() >= 500:
		return add_loot("ore", 1 + int(C.GEAR[gear_id].quality), at)
	var uid := next_loot_id
	next_loot_id += 1
	pending_loot.append({"uid": uid, "item": "gear", "count": 1, "gear_id": gear_id, "position": [at.x, 0.2, at.z]})
	return uid

func pickup_loot(id: int) -> bool:
	for i in range(pending_loot.size()):
		var item: Dictionary = pending_loot[i]
		if int(item.uid) != id: continue
		if item.item == "gear":
			if expansion.add_gear(item.gear_id) < 0: return false
		else:
			if item.item != "coins" and item_count(item.item) + int(item.count) > 100000: return false
			add_item(item.item, int(item.count))
		pending_loot.remove_at(i)
		return true
	return false

func snapshot(position: Vector3) -> Dictionary:
	return {"version": VERSION, "name": character_name, "robe": robe,
		"learned": learned, "collected": collected.duplicate(), "core": core,
		"beast_dead": beast_dead, "realm": realm, "hp": hp, "qi": qi,
		"position": [position.x, position.y, position.z],
		"herb_stock": herb_stock, "home_claimed": home_claimed, "vault_herbs": vault_herbs,
		"home_style": home_style,
		"seeds": seeds, "plots": plots.duplicate(), "world_time": world_time,
		"cultivation": cultivation, "runes": runes, "spitter_dead": spitter_dead,
		"guardian_dead": guardian_dead, "relic": relic,
		"beast_cores": beast_cores, "coins": coins, "heal_potions": heal_potions,
		"mana_potions": mana_potions, "weapon_level": weapon_level,
		"active_order": active_order, "orders_completed": orders_completed, "surveyed": surveyed,
		"pending_loot": pending_loot.duplicate(true), "next_loot_id": next_loot_id,
		"monster_ready": monster_ready.duplicate(), "herb_ready": herb_ready.duplicate(),
		"vault_items": vault_items.duplicate(), "inside_home": inside_home, "expansion": expansion.snapshot()}

func restore(data: Variant) -> bool:
	# Validate the entire save before changing live state.
	if not data is Dictionary:
		return false
	for key in ["version", "name", "robe", "learned", "collected", "core", "beast_dead", "realm", "hp", "qi", "position"]:
		if not data.has(key):
			return false
	if not (data.version is int or data.version is float) or not is_finite(float(data.version)): return false
	if data.version != 1 and data.version != 2 and data.version != 3 and data.version != 4 and data.version != VERSION:
		return false
	if not data.name is String or data.name.strip_edges().is_empty() or data.name.length() > 16:
		return false
	for key in ["learned", "core", "beast_dead"]:
		if not data[key] is bool:
			return false
	for key in ["robe", "realm", "hp", "qi"]:
		if not (data[key] is int or data[key] is float) or not is_finite(float(data[key])):
			return false
	if data.robe != int(data.robe) or data.robe < 0 or data.robe >= ROBES.size():
		return false
	if data.realm != int(data.realm) or int(data.realm) not in [0, 1]:
		return false
	if not data.collected is Array or data.collected.size() > HERB_COUNT:
		return false
	var ids: Array[int] = []
	for id in data.collected:
		if not (id is int or id is float) or not is_finite(float(id)):
			return false
		if id != int(id) or id < 0 or id >= HERB_COUNT or int(id) in ids:
			return false
		ids.append(int(id))
	if data.version < 3 and data.core and not data.beast_dead:
		return false
	if data.realm == 1 and (not data.learned or (data.version < 3 and (not data.beast_dead or data.core))):
		return false
	if not data.position is Array or data.position.size() != 3:
		return false
	for n in data.position:
		if not (n is int or n is float) or not is_finite(float(n)) or absf(float(n)) > 100.0:
			return false
	if absf(float(data.position[0])) > Rules.LIMIT or absf(float(data.position[2])) > Rules.LIMIT or float(data.position[1]) < 0 or float(data.position[1]) > 5:
		return false
	var extra := {"herb_stock": ids.size() - (3 if data.realm == 1 else 0), "home_claimed": false,
		"vault_herbs": 0, "seeds": 0, "plots": [-1.0, -1.0, -1.0], "world_time": 0.0,
		"cultivation": 0, "runes": 0, "spitter_dead": false, "guardian_dead": false, "relic": false}
	extra["home_style"] = 0
	if data.version >= 2:
		for key in extra:
			if not data.has(key):
				return false
			extra[key] = data[key]
	for key in ["home_claimed", "spitter_dead", "guardian_dead", "relic"]:
		if not extra[key] is bool:
			return false
	for key in ["herb_stock", "vault_herbs", "seeds", "cultivation", "runes", "world_time", "home_style"]:
		if not (extra[key] is int or extra[key] is float) or not is_finite(float(extra[key])) or extra[key] < 0:
			return false
		if key != "world_time" and (extra[key] != int(extra[key]) or extra[key] > 100000):
			return false
	if extra.cultivation > 3 or extra.runes > 3 or extra.home_style > 2 or extra.world_time > 100000000:
		return false
	if not extra.plots is Array or extra.plots.size() != 3:
		return false
	for time in extra.plots:
		if not (time is int or time is float) or not is_finite(float(time)):
			return false
		if time != -1 and (time < 0 or time > extra.world_time + GROW_SECONDS + 0.1):
			return false
	if not extra.home_claimed and (extra.vault_herbs != 0 or extra.cultivation != 0 or extra.plots != [-1.0, -1.0, -1.0]):
		return false
	if extra.guardian_dead and extra.runes != 3:
		return false
	if (extra.cultivation > 0 or extra.runes > 0) and not data.learned:
		return false
	if extra.relic and (not extra.guardian_dead or data.realm != 1):
		return false
	var economy := {"beast_cores": 1 if data.core else 0, "coins": 30, "heal_potions": 0,
		"mana_potions": 0, "weapon_level": 0, "active_order": "", "orders_completed": 0,
		"surveyed": false, "pending_loot": [], "next_loot_id": 1, "monster_ready": {}, "herb_ready": {}}
	if data.version >= 3:
		for key in economy:
			if not data.has(key):
				return false
			economy[key] = data[key]
	else:
		for id in ids:
			economy.herb_ready["legacy_%d" % id] = extra.world_time + Rules.HERB_REGROW
	for key in ["beast_cores", "coins", "heal_potions", "mana_potions", "weapon_level", "orders_completed", "next_loot_id"]:
		if not (economy[key] is int or economy[key] is float) or not is_finite(float(economy[key])):
			return false
		if economy[key] != int(economy[key]) or economy[key] < 0 or economy[key] > 100000000:
			return false
	if economy.weapon_level > 8 or economy.next_loot_id < 1 or bool(data.core) != (economy.beast_cores > 0):
		return false
	if not economy.active_order is String or economy.active_order not in ["", "herbs", "hunt", "survey", "brew"] or not economy.surveyed is bool:
		return false
	if not economy.pending_loot is Array or economy.pending_loot.size() > 512:
		return false
	var loot_ids := []
	for item in economy.pending_loot:
		if not item is Dictionary:
			return false
		for key in ["uid", "item", "count", "position"]:
			if not item.has(key):
				return false
		if not (item.uid is int or item.uid is float) or not is_finite(float(item.uid)) or item.uid != int(item.uid) or item.uid < 1 or item.uid >= economy.next_loot_id or int(item.uid) in loot_ids:
			return false
		if not (item.count is int or item.count is float) or not is_finite(float(item.count)) or item.count != int(item.count) or item.count < 1 or item.count > 1000000 or (item.item not in C.NAMES and item.item != "gear"):
			return false
		if item.item == "gear" and (data.version < 5 or item.count != 1 or not C.GEAR.has(item.get("gear_id"))):
			return false
		if not item.position is Array or item.position.size() != 3:
			return false
		for coordinate in item.position:
			if not (coordinate is int or coordinate is float) or not is_finite(float(coordinate)) or absf(float(coordinate)) > Rules.LIMIT:
				return false
		if item.position[1] < 0 or item.position[1] > 5:
			return false
		loot_ids.append(int(item.uid))
	for key in ["monster_ready", "herb_ready"]:
		if not economy[key] is Dictionary or economy[key].size() > 100:
			return false
		for id in economy[key]:
			if not id is String:
				return false
			if key == "monster_ready" and id not in Rules.FIELD_IDS:
				return false
			if key == "herb_ready" and not id.begins_with("legacy_") and not id.begins_with("field_"):
				return false
			var time: Variant = economy[key][id]
			if not (time is int or time is float) or not is_finite(float(time)) or time < 0 or time > extra.world_time + 61:
				return false
	var limit: float = (140.0 if data.realm == 1 else 100.0)
	var home_storage := {"core": 0, "seed": 0, "heal": 0, "mana": 0}
	var in_room := false
	if data.version >= 4:
		if not data.get("vault_items") is Dictionary or not data.get("inside_home") is bool:
			return false
		if data.vault_items.size() != home_storage.size():
			return false
		for item in home_storage:
			var count: Variant = data.vault_items.get(item)
			if not (count is int or count is float) or not is_finite(float(count)) or count != int(count) or count < 0 or count > 100000:
				return false
			home_storage[item] = int(count)
		in_room = data.inside_home
		if in_room and (absf(float(data.position[0])) > 7.5 or absf(float(data.position[2])) > 8.5):
			return false
	if not extra.home_claimed and (in_room or home_storage.values().any(func(n): return n > 0)):
		return false
	var next_expansion = Expansion.new()
	if data.version >= 5 and not next_expansion.restore(data.get("expansion"), float(extra.world_time)): return false
	if not extra.home_claimed and next_expansion.vault.values().any(func(n): return n > 0): return false
	if next_expansion.secret_inside and (in_room or absf(float(data.position[0])) > 8 or float(data.position[2]) < -77.5 or float(data.position[2]) > -67): return false
	var gear_bonus: Dictionary = next_expansion.bonuses()
	if data.hp <= 0 or data.hp > limit + extra.cultivation * 5 + economy.weapon_level * 8 + gear_bonus.hp or data.qi < 0 or data.qi > limit + extra.cultivation * 10 + economy.weapon_level * 5 + gear_bonus.qi:
		return false
	expansion = next_expansion
	character_name = data.name
	robe = int(data.robe)
	learned = data.learned
	collected = ids
	beast_cores = int(economy.beast_cores)
	beast_dead = data.beast_dead
	realm = int(data.realm)
	hp = float(data.hp)
	qi = float(data.qi)
	herb_stock = int(extra.herb_stock)
	home_claimed = extra.home_claimed
	home_style = int(extra.home_style)
	vault_herbs = int(extra.vault_herbs)
	vault_items = home_storage
	inside_home = in_room
	seeds = int(extra.seeds)
	plots.assign(extra.plots)
	world_time = float(extra.world_time)
	cultivation = int(extra.cultivation)
	runes = int(extra.runes)
	spitter_dead = extra.spitter_dead
	guardian_dead = extra.guardian_dead
	relic = extra.relic
	coins = int(economy.coins)
	heal_potions = int(economy.heal_potions)
	mana_potions = int(economy.mana_potions)
	weapon_level = int(economy.weapon_level)
	active_order = economy.active_order
	orders_completed = int(economy.orders_completed)
	surveyed = economy.surveyed
	pending_loot = economy.pending_loot.duplicate(true)
	next_loot_id = int(economy.next_loot_id)
	monster_ready = economy.monster_ready.duplicate()
	herb_ready = economy.herb_ready.duplicate()
	return true
