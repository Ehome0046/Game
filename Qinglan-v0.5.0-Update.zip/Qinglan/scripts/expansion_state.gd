extends RefCounted
const C = preload("res://scripts/catalog.gd")
const MAX_GEAR := 60
var materials := {"redflower": 0, "dew": 0, "ore": 0, "focus": 0}
var vault := {"redflower": 0, "dew": 0, "ore": 0, "focus": 0}
var gear: Array = []
var next_gear := 1
var equipped := {"weapon": 0, "robe": 0, "charm": 0}
var recipes: Array = ["heal", "mana"]
var batches := 0
var kills := 0
var focus_until := 0.0
var node_ready := {}
var chest_ready := {}
var chest_visits := {}
var discoveries: Array = []
var secret_inside := false

func find_gear(uid: int) -> Dictionary:
 for item in gear:
  if int(item.uid) == uid: return item
 return {}

func bonuses() -> Dictionary:
 var result := {"attack": 0, "hp": 0, "qi": 0, "armor": 0}
 for uid in equipped.values():
  var item := find_gear(int(uid))
  if item.is_empty(): continue
  for stat in result: result[stat] += C.GEAR[item.id][stat]
 return result

func add_gear(id: String) -> int:
 if not C.GEAR.has(id) or gear.size() >= MAX_GEAR: return -1
 var uid := next_gear
 next_gear += 1
 gear.append({"uid": uid, "id": id})
 return uid

func cap_vitals(p: RefCounted) -> void:
 p.hp = minf(p.hp, p.max_hp())
 p.qi = minf(p.qi, p.max_qi())

func equip(uid: int, p: RefCounted) -> bool:
 var item := find_gear(uid)
 if item.is_empty(): return false
 var slot: String = C.GEAR[item.id].slot
 equipped[slot] = 0 if int(equipped[slot]) == uid else uid
 cap_vitals(p)
 return true

func remove(uid: int, p: RefCounted, sell := false) -> bool:
 var item := find_gear(uid)
 if item.is_empty(): return false
 var data: Dictionary = C.GEAR[item.id]
 for slot in equipped:
  if int(equipped[slot]) == uid: equipped[slot] = 0
 gear.erase(item)
 if sell: p.coins += data.price
 else: materials.ore += 1 + int(data.quality)
 cap_vitals(p)
 return true

func can_craft(id: String, p: RefCounted) -> bool:
 if id not in recipes or not C.RECIPES.has(id): return false
 var recipe: Dictionary = C.RECIPES[id]
 if recipe.has("gear") and gear.size() >= MAX_GEAR: return false
 for item in recipe.cost:
  if p.item_count(item) < int(recipe.cost[item]): return false
 if recipe.has("item") and p.item_count(recipe.item) + int(recipe.count) > 100000: return false
 return true

func craft(id: String, p: RefCounted) -> bool:
 if not can_craft(id, p): return false
 var recipe: Dictionary = C.RECIPES[id]
 for item in recipe.cost: p.add_item(item, -int(recipe.cost[item]))
 if recipe.has("gear"): add_gear(recipe.gear)
 else: p.add_item(recipe.item, int(recipe.count))
 batches += 1
 return true

func drop_gear(species: int) -> String:
 # Persistent sequence avoids rerolling the same death by loading a save.
 kills += 1
 if kills != 1 and kills % 3 != 0: return ""
 var quality := 2 if kills % 12 == 0 else (1 if kills % 3 == 0 else 0)
 var slot: String = C.SLOTS[posmod(floori(kills / 3.0) + species, 3)]
 for id in C.GEAR:
  if C.GEAR[id].slot == slot and C.GEAR[id].quality == quality: return id
 return ""

func snapshot() -> Dictionary:
 return {"materials": materials.duplicate(), "vault": vault.duplicate(), "gear": gear.duplicate(true), "next_gear": next_gear, "equipped": equipped.duplicate(),
 "recipes": recipes.duplicate(), "batches": batches, "kills": kills, "focus_until": focus_until, "node_ready": node_ready.duplicate(), "chest_ready": chest_ready.duplicate(),
 "chest_visits": chest_visits.duplicate(), "discoveries": discoveries.duplicate(), "secret_inside": secret_inside}

static func integer(value: Variant, low := 0, high := 100000000) -> bool:
 return (value is int or value is float) and is_finite(float(value)) and value == int(value) and value >= low and value <= high

func restore(data: Variant, world_time: float) -> bool:
 if not data is Dictionary: return false
 for key in snapshot():
  if not data.has(key): return false
 for key in ["materials", "vault"]:
  if not data[key] is Dictionary or data[key].size() != C.MATERIALS.size(): return false
  for item in C.MATERIALS:
   if not integer(data[key].get(item), 0, 100000): return false
 for key in ["next_gear", "batches", "kills"]:
  if not integer(data[key]): return false
 if data.next_gear < 1 or not data.gear is Array or data.gear.size() > MAX_GEAR: return false
 var ids := []
 for item in data.gear:
  if not item is Dictionary or not integer(item.get("uid"), 1) or item.uid >= data.next_gear or int(item.uid) in ids or not C.GEAR.has(item.get("id")): return false
  ids.append(int(item.uid))
 if not data.equipped is Dictionary or data.equipped.size() != 3: return false
 for slot in C.SLOTS:
  var uid: Variant = data.equipped.get(slot)
  if not integer(uid): return false
  if uid == 0: continue
  if int(uid) not in ids: return false
  var index := ids.find(int(uid))
  if C.GEAR[data.gear[index].id].slot != slot: return false
 if not data.recipes is Array or data.recipes.size() > C.RECIPES.size(): return false
 var unique := []
 for id in data.recipes:
  if not id is String or not C.RECIPES.has(id) or id in unique: return false
  unique.append(id)
 if "heal" not in unique or "mana" not in unique: return false
 if not (data.focus_until is int or data.focus_until is float) or not is_finite(float(data.focus_until)) or data.focus_until < 0 or data.focus_until > world_time + 120.1: return false
 for key in ["node_ready", "chest_ready", "chest_visits"]:
  if not data[key] is Dictionary or data[key].size() > 32: return false
  for id in data[key]:
   if not id is String: return false
   if key == "node_ready":
    if not id.is_valid_int() or int(id) < 0 or int(id) >= C.NODES.size(): return false
   elif not C.CHESTS.has(id): return false
   var value: Variant = data[key][id]
   if key == "chest_visits":
    if not integer(value): return false
   elif not (value is int or value is float) or not is_finite(float(value)) or value < 0 or value > world_time + 180.1: return false
 if not data.discoveries is Array or data.discoveries.size() > 3: return false
 unique.clear()
 for id in data.discoveries:
  if not id is String or not C.POIS.has(id) or id in unique: return false
  unique.append(id)
 if not data.secret_inside is bool: return false
 materials = data.materials.duplicate()
 vault = data.vault.duplicate()
 gear = data.gear.duplicate(true)
 next_gear = int(data.next_gear)
 equipped = data.equipped.duplicate()
 recipes = data.recipes.duplicate()
 batches = int(data.batches)
 kills = int(data.kills)
 focus_until = float(data.focus_until)
 node_ready = data.node_ready.duplicate()
 chest_ready = data.chest_ready.duplicate()
 chest_visits = data.chest_visits.duplicate()
 discoveries = data.discoveries.duplicate()
 secret_inside = data.secret_inside
 return true
