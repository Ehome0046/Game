extends Node3D

const Rules = preload("res://scripts/world_rules.gd")
var game: Node3D
var npcs: Array[Dictionary] = []
var popup: PanelContainer
var heading: Label
var speech: Label
var inventory: Label
var status: Label
var actions: GridContainer
var current := "elder"
var last_status := ""
var rumor := ""

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	build_npc("elder", "顾伯 · 村长", Vector3(3, 0, 22), "78775e")
	build_npc("healer", "沈娘 · 药师", Vector3(-5, 0, 26), "617769")
	build_npc("trader", "陆舟 · 行商", Vector3(7, 0, 28), "79634e")
	var v = game.valley
	v.box(Vector3(7, 0.5, 30), Vector3(4, 1, 1.4), v.wood, true)
	for x in [4.5, 9.5]:
		v.box(Vector3(x, 1.6, 30.3), Vector3(0.15, 3.2, 0.15), v.wood)
	v.box(Vector3(7, 3.2, 30.3), Vector3(5.5, 0.12, 2.3), v.material("696d50"))
	for i in range(4):
		v.box(Vector3(5.7 + i * 0.7, 1.1, 30), Vector3(0.45, 0.3, 0.5), v.material("b29d73"))
	v.box(Vector3(-7.5, 0.5, 28.5), Vector3(2, 1, 1.3), v.wood, true)
	for i in range(4):
		v.cylinder(Vector3(-8.1 + i * 0.4, 1.2, 28.5), 0.055, 0.1, 0.32, v.material("8daca5" if i % 2 == 0 else "b89677"))
	v.sign_text("青 岚 坊 市\n采药 / 猎妖 / 勘察 → 委托 → 交易补给", Vector3(3, 3.7, 27), 29, Color("dfc997"))
	v.sign_text("村南坊市 ↓\n顾伯接委托，沈娘买药，陆舟强化", Vector3(0, 2.4, 24), 24)
	popup = game.panel(Vector2(290, 65), Vector2(700, 580))
	var style: StyleBoxFlat = popup.get_theme_stylebox("panel").duplicate()
	style.bg_color = Color("0d1b18")
	popup.add_theme_stylebox_override("panel", style)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	popup.add_child(column)
	heading = game.label("", 28, Color("dfc997"))
	column.add_child(heading)
	speech = game.label("", 18)
	speech.custom_minimum_size.x = 640
	speech.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(speech)
	inventory = game.label("", 18, Color("c8d4b7"))
	column.add_child(inventory)
	actions = GridContainer.new()
	actions.columns = 2
	actions.add_theme_constant_override("h_separation", 12)
	actions.add_theme_constant_override("v_separation", 8)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(640, 208)
	column.add_child(scroll)
	scroll.add_child(actions)
	status = game.label("", 17, Color("e2c58c"))
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.custom_minimum_size.x = 640
	column.add_child(status)
	game.button("告辞 · 返回游戏", func(): game.set_paused(false), column)
	popup.hide()

func build_npc(id: String, title: String, at: Vector3, color: String) -> void:
	var v = game.valley
	var body := Node3D.new()
	add_child(body)
	body.position = at
	var solid := StaticBody3D.new()
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.28
	capsule.height = 1.7
	shape.shape = capsule
	shape.position.y = 0.85
	solid.add_child(shape)
	body.add_child(solid)
	var mat: StandardMaterial3D = v.material(color)
	var greeting_arm: MeshInstance3D
	v.cylinder(Vector3.UP * 0.85, 0.24, 0.34, 1.3, mat, body)
	var head := SphereMesh.new()
	head.radius = 0.17
	head.height = 0.37
	v.mesh_at(head, Vector3.UP * 1.65, v.material("c7ae91"), body)
	v.cylinder(Vector3.UP * 1.85, 0.1, 0.21, 0.2, v.material("303b33"), body)
	for x in [-0.32, 0.32]:
		var arm: MeshInstance3D = v.box(Vector3(x, 1.05, 0), Vector3(0.18, 0.65, 0.2), mat, false, body)
		arm.rotation.z = signf(x) * 0.15
		if x > 0: greeting_arm = arm
	v.box(Vector3(0, 0.95, -0.02), Vector3(0.6, 0.08, 0.5), v.material("a88d63"), false, body)
	v.sign_text(title + " · E交谈", at + Vector3.UP * 2.5, 26, Color("e0d1ad"))
	npcs.append({"id": id, "title": title, "node": body, "position": at, "arm": greeting_arm})
	game.valley.interactions.append({"kind": "npc", "id": -1, "npc": id, "position": at, "label": "与" + title + "交谈"})

func hide_popup() -> void:
	popup.hide()

func open_dialog(id: String) -> void:
	current = id
	for npc in npcs:
		if npc.id == id:
			var offset: Vector3 = game.traveler.position - npc.position
			npc.node.rotation.y = atan2(-offset.x, -offset.z)
			var tween := create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
			tween.tween_property(npc.arm, "rotation:x", -0.7, 0.35)
			tween.tween_property(npc.arm, "rotation:x", 0, 0.5)
	rumor = ""
	last_status = ""
	game.set_paused(true)
	game.pause_panel.hide()
	popup.show()
	render()

func accessible() -> bool:
	if not popup.visible or not game.paused:
		return false
	for npc in npcs:
		if npc.id == current:
			return game.traveler.position.distance_to(npc.position) < 3.2
	return false

func add_action(text: String, callback: Callable, disabled := false) -> void:
	var button: Button = game.button(text, callback, actions)
	button.custom_minimum_size.x = 310
	button.disabled = disabled

func objective() -> String:
	var p = game.progress
	match p.active_order:
		"herbs": return "采药委托：灵草 %d / 3，交给顾伯得 35 金币" % p.herbs()
		"hunt": return "猎妖委托：兽丹 %d / 2，交给顾伯得 65 金币" % p.beast_cores
		"brew": return "药品委托：养元丹 %d / 2，交给顾伯得 26 金币" % p.heal_potions
		"survey": return "勘察委托：%s，回顾伯处得 45 金币" % ("已勘察界碑" if p.surveyed else "去东北石谷界碑按 E")
	return "村南顾伯可接采药、猎妖、勘察委托，可反复领取。"

func render() -> void:
	for child in actions.get_children():
		actions.remove_child(child)
		child.queue_free()
	var p = game.progress
	inventory.text = "金币 %d   灵草 %d   兽丹 %d   灵种 %d\n养元丹 %d   回灵散 %d   飞剑强化 %d / 8   完成委托 %d" % [p.coins, p.herbs(), p.beast_cores, p.seeds, p.heal_potions, p.mana_potions, p.weapon_level, p.orders_completed]
	inventory.text += "\n赤霞花 %d   凝露草 %d   灵铁 %d   聚气丹 %d" % [p.item_count("redflower"), p.item_count("dew"), p.item_count("ore"), p.item_count("focus")]
	if current == "elder":
		heading.text = "顾伯 · 村长委托"
		speech.text = "采药、猎妖、勘察，或把炼好的药送来。交付后可以继续领取。\n" + objective()
		if p.active_order.is_empty():
			add_action("采药：交 3 灵草 / 35 金币", accept.bind("herbs"))
			add_action("猎妖：交 2 兽丹 / 65 金币", accept.bind("hunt"))
			add_action("勘察：石谷界碑 / 45 金币", accept.bind("survey"))
			add_action("药品：交 2 养元丹 / 26 金币", accept.bind("brew"))
		else:
			add_action("交付当前委托", complete, not p.order_ready())
			add_action("放弃当前委托", cancel)
		add_action("闲谈：新手从哪里开始", talk.bind("北面残卷学御剑，猎妖后拾取装备，B 穿戴；T 找药谷、矿洞、秘境。洞府丹炉制作药品，药品委托可反复交付。"))
	elif current == "healer":
		heading.text = "沈娘 · 药材铺"
		speech.text = "赤霞花与凝露草可在落霞药谷采集，回洞府丹炉炼药。养元丹 / 回灵散按 4 / 5 使用，聚气丹按 6；成药可出售。"
		add_action("买养元丹 · 15 金币", buy.bind("heal"), p.coins < 15)
		add_action("买回灵散 · 12 金币", buy.bind("mana"), p.coins < 12)
		add_action("买灵草 · 12 金币", buy.bind("herb"), p.coins < 12)
		add_action("买灵种 · 8 金币", buy.bind("seed"), p.coins < 8)
		add_action("卖灵草 · 得 5 金币", sell.bind("herb"), p.herbs() == 0)
		add_action("买赤霞花 · 18 金币", buy.bind("redflower"), p.coins < 18)
		add_action("买凝露草 · 18 金币", buy.bind("dew"), p.coins < 18)
		add_action("卖养元丹 · 得 9 金币", sell.bind("heal"), p.heal_potions == 0)
		add_action("卖回灵散 · 得 7 金币", sell.bind("mana"), p.mana_potions == 0)
		add_action("卖赤霞花 · 得 8 金币", sell.bind("redflower"), p.item_count("redflower") == 0)
		add_action("卖凝露草 · 得 8 金币", sell.bind("dew"), p.item_count("dew") == 0)
		add_action("卖聚气丹 · 得 35 金币", sell.bind("focus"), p.item_count("focus") == 0)
		add_action("闲谈：灵田如何经营", talk.bind("认领洞府会送三枚灵种。灵田游玩 90 秒成熟，收获两株灵草并回收一枚灵种；用来接委托或出售，可持续经营。"))
	else:
		heading.text = "陆舟 · 行商与飞剑淬炼"
		speech.text = "兽丹收购价 22 金币。飞剑每次淬炼提升伤害 3、生命上限 8、灵力上限 5。初次突破记得留一枚兽丹。"
		add_action("卖兽丹 · 得 22 金币", sell.bind("core"), p.beast_cores == 0)
		add_action("飞剑淬炼 · %d 金币" % p.upgrade_cost(), upgrade, p.weapon_level >= 8 or p.coins < p.upgrade_cost())
		add_action("卖灵草 · 得 5 金币", sell.bind("herb"), p.herbs() == 0)
		add_action("卖灵铁 · 得 6 金币", sell.bind("ore"), p.item_count("ore") == 0)
		add_action("查看装备 / 出售", open_equipment)
		add_action("闲谈：妖兽猎场", talk.bind("南坡林地有狼群，东南兽径多山豕；西北瘴泽要躲毒弹，东北石谷的石妖更结实。击败后在地上拾取兽丹和金币，离开刷新点再回来。"))
	if not rumor.is_empty():
		speech.text = rumor
	status.text = last_status

func changed(ok: bool, success: String) -> void:
	last_status = success if ok else "条件不足，请检查金币、物品或当前委托。"
	if ok:
		game.traveler.play_interaction("trade", game.traveler.position)
		game.save_game(false)
	render()

func buy(item: String) -> void:
	if accessible():
		changed(game.progress.buy(item), "交易完成，物品已收入行囊。")

func sell(item: String) -> void:
	if accessible():
		changed(game.progress.sell(item), "交易完成，金币已到账。")

func upgrade() -> void:
	if accessible():
		changed(game.progress.upgrade_weapon(), "飞剑淬炼成功！伤害、生命与灵力上限提升。")

func accept(kind: String) -> void:
	if accessible():
		changed(game.progress.accept_order(kind), "委托已接取。完成后回顾伯处交付；交付后可再接。")

func complete() -> void:
	if accessible():
		changed(game.progress.complete_order(), "委托完成，金币已到账！可以选择下一份委托。")

func cancel() -> void:
	if accessible():
		game.progress.active_order = ""
		game.progress.surveyed = false
		game.save_game(false)
		last_status = "委托已放弃，已有物品保留。"
		render()

func open_equipment() -> void:
	if accessible(): game.workshop.open_gear()

func talk(text: String) -> void:
	rumor = text
	render()

func _process(_delta: float) -> void:
	if not game.playing or game.paused:
		return
	for npc in npcs:
		var delta: Vector3 = game.traveler.position - npc.position
		if delta.length() < 5:
			npc.node.rotation.y = atan2(-delta.x, -delta.z)
