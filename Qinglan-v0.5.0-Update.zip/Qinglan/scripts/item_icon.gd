extends Control
## Small original vector icons shared by inventory and the HUD.
var item := "herb"

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0, size / 64.0)
	match item:
		"herb", "redflower", "dew":
			draw_line(Vector2(22, 55), Vector2(40, 12), Color("a2c9a2"), 4, true)
			for i in range(3):
				var at := Vector2(28 + i * 4, 40 - i * 11)
				draw_colored_polygon(PackedVector2Array([at, at + Vector2(-18, -3), at + Vector2(-15, -16), at + Vector2(2, -5)]), Color("6fbc8c"))
				draw_colored_polygon(PackedVector2Array([at, at + Vector2(20, -4), at + Vector2(21, -15), at + Vector2(4, -8)]), Color("b5d2a2"))
			if item != "herb":
				draw_circle(Vector2(41, 11), 8, Color("de9e85") if item == "redflower" else Color("a0d8db"))
		"ore":
			draw_colored_polygon(PackedVector2Array([Vector2(12, 48), Vector2(19, 20), Vector2(32, 8), Vector2(45, 23), Vector2(53, 49)]), Color("81acb5"))
			draw_line(Vector2(32, 13), Vector2(29, 47), Color("d9e8d8"), 3, true)
		"robe":
			draw_colored_polygon(PackedVector2Array([Vector2(22, 10), Vector2(10, 20), Vector2(5, 39), Vector2(17, 44), Vector2(21, 29), Vector2(18, 58), Vector2(47, 58), Vector2(43, 29), Vector2(48, 44), Vector2(59, 39), Vector2(54, 20), Vector2(42, 10), Vector2(32, 24)]), Color("85ad96"))
			draw_line(Vector2(19, 37), Vector2(45, 37), Color("ddc793"), 5, true)
		"charm":
			draw_arc(Vector2(32, 23), 17, PI, TAU, 24, Color("d4b981"), 3, true)
			draw_circle(Vector2(32, 35), 16, Color("85bcb5"))
			draw_line(Vector2(32, 30), Vector2(32, 60), Color("d4b981"), 3, true)
		"core":
			draw_circle(Vector2(32, 32), 23, Color("274e52"))
			draw_arc(Vector2(32, 32), 25, 0, TAU, 48, Color("ceb584"), 2, true)
			draw_colored_polygon(PackedVector2Array([Vector2(32, 10), Vector2(48, 31), Vector2(32, 54), Vector2(16, 31)]), Color("81d8c6"))
			draw_colored_polygon(PackedVector2Array([Vector2(32, 10), Vector2(32, 54), Vector2(16, 31)]), Color("4a9c96"))
			draw_line(Vector2(25, 29), Vector2(33, 18), Color("dbf3d7"), 3, true)
		"seed":
			for at in [Vector2(23, 38), Vector2(42, 37), Vector2(32, 21)]:
				draw_circle(at, 10, Color("b89b61"))
				draw_arc(at, 7, 0.8, 4.0, 16, Color("edd8a2"), 2, true)
		"heal", "mana", "focus":
			var tint := Color("c97169") if item == "heal" else (Color("a69bd0") if item == "focus" else Color("6ba9d8"))
			draw_style_box(bottle_style(Color("cad4bc")), Rect2(15, 20, 34, 36))
			draw_style_box(bottle_style(tint), Rect2(19, 32, 26, 20))
			draw_rect(Rect2(25, 10, 14, 13), Color("c7c9b6"))
			draw_rect(Rect2(23, 7, 18, 7), Color("ba9b64"))
			draw_line(Vector2(33, 36), Vector2(33, 47), Color("ffe9c7"), 3, true)
			draw_line(Vector2(28, 41), Vector2(38, 41), Color("ffe9c7"), 3, true)
		"coins":
			draw_circle(Vector2(32, 32), 24, Color("b48942"))
			draw_arc(Vector2(32, 32), 20, 0, TAU, 40, Color("f1d899"), 3, true)
			draw_rect(Rect2(26, 26, 12, 12), Color("30413b"))
			draw_line(Vector2(16, 23), Vector2(22, 16), Color("fff1bf"), 3, true)
		"sword":
			draw_colored_polygon(PackedVector2Array([Vector2(47, 6), Vector2(45, 27), Vector2(26, 46), Vector2(18, 38)]), Color("b3ddd5"))
			draw_line(Vector2(22, 42), Vector2(46, 12), Color("f3e8c5"), 2, true)
			draw_line(Vector2(14, 34), Vector2(32, 51), Color("c9a96c"), 5, true)
			draw_line(Vector2(22, 43), Vector2(10, 57), Color("8c734f"), 6, true)
		"fire":
			draw_colored_polygon(PackedVector2Array([Vector2(33, 4), Vector2(48, 28), Vector2(52, 44), Vector2(39, 58), Vector2(21, 55), Vector2(12, 40), Vector2(24, 23), Vector2(24, 38)]), Color("d58b56"))
			draw_colored_polygon(PackedVector2Array([Vector2(32, 26), Vector2(41, 46), Vector2(31, 56), Vector2(22, 46)]), Color("f6d995"))
		"shield":
			draw_colored_polygon(PackedVector2Array([Vector2(32, 6), Vector2(53, 15), Vector2(49, 42), Vector2(32, 58), Vector2(15, 42), Vector2(11, 15)]), Color("518a80"))
			draw_arc(Vector2(32, 30), 14, 0, TAU, 32, Color("c5dbc0"), 2, true)
			draw_line(Vector2(32, 13), Vector2(32, 49), Color("c5dbc0"), 2, true)

func bottle_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(7)
	return style
