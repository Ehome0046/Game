extends Control

const Icon = preload("res://scripts/item_icon.gd")
var game: Node3D
var hp_bar: ProgressBar
var qi_bar: ProgressBar
var hp_text: Label
var qi_text: Label
var name_text: Label
var gold_text: Label
var stock_text: Label
var action_bar: ProgressBar
var action_text: Label
var input_text: Label
var slots: Array[Dictionary] = []

func style(color: String, border := "657d70") -> StyleBoxFlat:
	var box := StyleBoxFlat.new()
	box.bg_color = Color(color)
	box.border_color = Color(border)
	box.set_border_width_all(1)
	box.set_corner_radius_all(5)
	return box

func box_at(at: Vector2, dimensions: Vector2, color := "152622") -> Panel:
	var panel := Panel.new()
	panel.position = at
	panel.size = dimensions
	panel.add_theme_stylebox_override("panel", style(color))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)
	return panel

func text_at(text: String, at: Vector2, font_size: int, parent: Node = self, color := Color("e5dfc6")) -> Label:
	var label: Label = game.label(text, font_size, color)
	label.position = at
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(label)
	return label

func icon_at(item: String, at: Vector2, dimensions: Vector2, parent: Node = self) -> Control:
	var icon := Icon.new()
	icon.item = item
	icon.position = at
	icon.size = dimensions
	parent.add_child(icon)
	return icon

func bar(at: Vector2, color: String) -> ProgressBar:
	var result := ProgressBar.new()
	result.position = at
	result.size = Vector2(274, 21)
	result.show_percentage = false
	result.mouse_filter = Control.MOUSE_FILTER_IGNORE
	result.add_theme_stylebox_override("background", style("0b1716", "485c54"))
	result.add_theme_stylebox_override("fill", style(color, color))
	add_child(result)
	return result

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	box_at(Vector2(28, 24), Vector2(392, 139))
	box_at(Vector2(39, 39), Vector2(72, 72), "25423c")
	icon_at("sword", Vector2(48, 45), Vector2(53, 53))
	text_at("修 行 者", Vector2(43, 114), 14)
	name_text = text_at("", Vector2(125, 32), 23)
	name_text.size.x = 274
	name_text.clip_text = true
	name_text.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	hp_bar = bar(Vector2(125, 72), "a75551")
	qi_bar = bar(Vector2(125, 103), "4d8fae")
	hp_text = text_at("", Vector2(135, 71), 14)
	qi_text = text_at("", Vector2(135, 102), 14)
	gold_text = text_at("", Vector2(64, 172), 20)
	box_at(Vector2(28, 167), Vector2(152, 36))
	move_child(get_child(get_child_count() - 1), 0)
	icon_at("coins", Vector2(34, 171), Vector2(27, 27))
	stock_text = text_at("", Vector2(193, 175), 15)
	for i in range(6):
		var panel := box_at(Vector2(373 + i * 88, 614), Vector2(78, 66))
		icon_at(["sword", "fire", "shield", "heal", "mana", "focus"][i], Vector2(21, 7), Vector2(39, 39), panel)
		text_at(["1 / Q", "2 / R", "3 / F", "4", "5", "6"][i], Vector2(5, 3), 12, panel)
		var amount := text_at("", Vector2(7, 46), 12, panel)
		slots.append({"panel": panel, "label": amount})
	action_bar = bar(Vector2(475, 528), "a6b987")
	action_bar.size.x = 330
	action_text = text_at("", Vector2(475, 500), 17)
	input_text = text_at("鼠标控制 · 右键进入 / F8 兼容 / F10 释放", Vector2(845, 689), 12)

func refresh(delta: float) -> void:
	visible = game.playing and not game.paused
	if not visible:
		return
	var p = game.progress
	name_text.text = p.character_name + " · " + ("炼气一层" if p.realm else "凡人")
	hp_bar.max_value = p.max_hp()
	qi_bar.max_value = p.max_qi()
	hp_bar.value = lerpf(hp_bar.value, p.hp, minf(1, delta * 14))
	qi_bar.value = lerpf(qi_bar.value, p.qi, minf(1, delta * 14))
	hp_text.text = "生命  %d / %d" % [p.hp, p.max_hp()]
	qi_text.text = "灵力  %d / %d" % [p.qi, p.max_qi()]
	gold_text.text = "%d" % p.coins
	stock_text.text = "灵草 %d  ·  兽丹 %d  ·  飞剑 +%d" % [p.herbs(), p.beast_cores, p.weapon_level]
	slots[0].label.text = "御剑 · 连击"
	slots[1].label.text = "未传承" if not p.relic else ("火弹 · 就绪" if game.fire_cooldown <= 0 else "%.1f 秒" % game.fire_cooldown)
	slots[2].label.text = "未习得" if not p.learned else ("护体 · 就绪" if game.shield_cooldown <= 0 else "%.1f 秒" % game.shield_cooldown)
	slots[3].label.text = "养元丹 × %d" % p.heal_potions
	slots[4].label.text = "回灵散 × %d" % p.mana_potions
	slots[5].label.text = ("聚气 %ds" % ceili(p.expansion.focus_until - p.world_time)) if p.expansion.focus_until > p.world_time else "聚气丹 × %d" % p.expansion.materials.focus
	action_bar.visible = game.room.meditating or game.workshop.active
	action_text.visible = game.room.meditating or game.workshop.active
	if game.room.meditating:
		action_bar.max_value = game.room.rest_duration
		action_bar.value = game.room.rest_elapsed
		action_text.text = ("修炼" if game.room.training else "调息") + ("完成 · E 起身 / G 继续修炼" if game.room.rest_done else "中 · E 或移动取消")
	if game.workshop.active:
		action_bar.max_value = game.workshop.duration
		action_bar.value = game.workshop.elapsed
		action_text.text = "炼制中 · E 或移动取消"
	input_text.text = ("兼容" if game.compat_mouse else "标准") + " · " + ("已锁定" if Input.mouse_mode != Input.MOUSE_MODE_VISIBLE else "点击画面进入控制") + " · F8 切换 / F10 释放"
