extends RefCounted
## Original item and recipe definitions; shared by state, world and interface.
const MATERIALS := ["redflower", "dew", "ore", "focus"]
const NAMES := {"herb": "灵草", "core": "兽丹", "coins": "金币", "seed": "灵种", "heal": "养元丹", "mana": "回灵散", "redflower": "赤霞花", "dew": "凝露草", "ore": "灵铁", "focus": "聚气丹"}
const SLOTS := ["weapon", "robe", "charm"]
const SLOT_NAMES := {"weapon": "飞剑", "robe": "衣服", "charm": "护符"}
const QUALITY := ["凡品", "灵品", "玄品"]
const COLORS := ["c4c9bb", "86c697", "85b7df"]
const GEAR := {
 "twig_blade": {"name": "竹纹飞剑", "slot": "weapon", "quality": 0, "attack": 3, "hp": 0, "qi": 0, "armor": 0, "price": 12},
 "iron_blade": {"name": "灵铁飞剑", "slot": "weapon", "quality": 1, "attack": 7, "hp": 0, "qi": 0, "armor": 0, "price": 55},
 "jade_blade": {"name": "青霄飞剑", "slot": "weapon", "quality": 2, "attack": 13, "hp": 0, "qi": 0, "armor": 0, "price": 95},
 "linen_robe": {"name": "行山布衣", "slot": "robe", "quality": 0, "attack": 0, "hp": 8, "qi": 0, "armor": 1, "price": 12, "tint": "7b745c"},
 "moss_robe": {"name": "青竹法衣", "slot": "robe", "quality": 1, "attack": 0, "hp": 18, "qi": 0, "armor": 2, "price": 40, "tint": "3f6e58"},
 "cloud_robe": {"name": "流云法衣", "slot": "robe", "quality": 2, "attack": 0, "hp": 30, "qi": 0, "armor": 4, "price": 75, "tint": "527f98"},
 "wood_charm": {"name": "安神木符", "slot": "charm", "quality": 0, "attack": 1, "hp": 0, "qi": 10, "armor": 0, "price": 12},
 "jade_charm": {"name": "凝露玉佩", "slot": "charm", "quality": 1, "attack": 2, "hp": 0, "qi": 20, "armor": 0, "price": 40},
 "moon_charm": {"name": "望月灵符", "slot": "charm", "quality": 2, "attack": 4, "hp": 0, "qi": 35, "armor": 0, "price": 75}
}
const RECIPES := {
 "heal": {"name": "养元丹 × 2", "station": "alchemy", "cost": {"herb": 2, "redflower": 1}, "seconds": 5.0, "item": "heal", "count": 2},
 "mana": {"name": "回灵散 × 2", "station": "alchemy", "cost": {"herb": 2, "dew": 1}, "seconds": 5.0, "item": "mana", "count": 2},
 "focus": {"name": "聚气丹 × 1", "station": "alchemy", "cost": {"herb": 2, "core": 1, "dew": 1}, "seconds": 7.0, "item": "focus", "count": 1},
 "iron_blade": {"name": "灵铁飞剑", "station": "forge", "cost": {"ore": 4, "core": 1}, "seconds": 8.0, "gear": "iron_blade"}
}
const POIS := {"grove": Vector3(-55, 0, 16), "mine": Vector3(56, 0, 22), "shrine": Vector3(11, 0, -60)}
const POI_NAMES := {"grove": "落霞药谷", "mine": "青石矿洞", "shrine": "望月秘境入口"}
const CHESTS := {"grove": Vector3(-61, 0, 10), "mine": Vector3(56, 0, 8), "shrine": Vector3(0, 0, -76)}
const NODES := [
 {"at": Vector3(-50, 0, 18), "item": "redflower"}, {"at": Vector3(-57, 0, 13), "item": "redflower"}, {"at": Vector3(-63, 0, 19), "item": "redflower"},
 {"at": Vector3(-52, 0, 9), "item": "dew"}, {"at": Vector3(-58, 0, 23), "item": "dew"}, {"at": Vector3(-65, 0, 12), "item": "dew"},
 {"at": Vector3(53, 0, 11), "item": "ore"}, {"at": Vector3(59, 0, 10), "item": "ore"}, {"at": Vector3(53, 0, 17), "item": "ore"}, {"at": Vector3(59, 0, 17), "item": "ore"}
]

static func description(id: String) -> String:
 var item: Dictionary = GEAR[id]
 return "%s · %s\n伤害 +%d  生命 +%d  灵力 +%d  护甲 +%d" % [item.name, QUALITY[item.quality], item.attack, item.hp, item.qi, item.armor]

static func recipe_cost(id: String) -> String:
 var parts: Array[String] = []
 for item in RECIPES[id].cost: parts.append("%s × %d" % [NAMES[item], RECIPES[id].cost[item]])
 return " + ".join(parts)
