#!/usr/bin/env python3
"""Exercise actual X11 mouse/focus/close events in an isolated game copy.
Requires DISPLAY, libX11 and libXtst. This does not test Windows drivers.
"""
import ctypes as C
import ctypes.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

if not os.environ.get('DISPLAY'):
    raise SystemExit('Set DISPLAY to an available X11 server')
x = C.CDLL(ctypes.util.find_library('X11'))
t = C.CDLL(ctypes.util.find_library('Xtst'))
D, W, I, U = C.c_void_p, C.c_ulong, C.c_int, C.c_uint

def bind(lib, name, args, result=I):
    fn = getattr(lib, name)
    fn.argtypes, fn.restype = args, result
    return fn

open_display = bind(x, 'XOpenDisplay', [C.c_char_p], D)
root_window = bind(x, 'XDefaultRootWindow', [D], W)
focus = bind(x, 'XSetInputFocus', [D, W, I, W])
flush = bind(x, 'XFlush', [D])
create = bind(x, 'XCreateSimpleWindow', [D, W, I, I, U, U, U, W, W], W)
map_window = bind(x, 'XMapWindow', [D, W])
resize = bind(x, 'XResizeWindow', [D, W, U, U])
destroy = bind(x, 'XDestroyWindow', [D, W])
keysym = bind(x, 'XKeysymToKeycode', [D, W], U)
atom = bind(x, 'XInternAtom', [D, C.c_char_p, I], W)
motion = bind(t, 'XTestFakeRelativeMotionEvent', [D, I, I, W])
absolute = bind(t, 'XTestFakeMotionEvent', [D, I, I, I, W])
mouse = bind(t, 'XTestFakeButtonEvent', [D, U, I, W])
keyboard = bind(t, 'XTestFakeKeyEvent', [D, U, I, W])

class Client(C.Structure):
    _fields_ = [('type', I), ('serial', W), ('send_event', I), ('display', D),
                ('window', W), ('message_type', W), ('format', I), ('data', C.c_long * 5)]
class Event(C.Union):
    _fields_ = [('client', Client), ('pad', C.c_long * 24)]
send = bind(x, 'XSendEvent', [D, W, I, C.c_long, C.POINTER(Event)])
display = open_display(None)
if not display:
    raise SystemExit('Unable to open DISPLAY')
root = root_window(display)
# A real window manager registers these before applications start. A bare
# Xorg test server has no WM; Godot looks up WM_DELETE_WINDOW with only_if_exists.
# Register it now so the first test window receives the same close protocol.
wm_protocols = atom(display, b'WM_PROTOCOLS', 0)
wm_delete = atom(display, b'WM_DELETE_WINDOW', 0)

def tap(symbol):
    code = keysym(display, symbol)
    keyboard(display, code, 1, 0)
    keyboard(display, code, 0, 0)
    flush(display)

def click(button=1):
    mouse(display, button, 1, 0)
    mouse(display, button, 0, 0)
    flush(display)

checks = 0
with tempfile.TemporaryDirectory(prefix='qinglan-native-input-') as tmp:
    project = Path(tmp)/'Game'
    source = Path(__file__).resolve().parents[1]
    shutil.copytree(source, project, ignore=shutil.ignore_patterns('.git', '.godot', '.local', 'dist', '__pycache__', 'godot'))
    (project/'tests/window_probe.gd').write_text('''extends SceneTree
const Game = preload("res://scripts/game.gd")
var game
var elapsed := 0.0
var interval := 0.0
func _initialize():
 call_deferred("start")
func start():
 root.title = "Qinglan Input Check"
 game = Game.new()
 root.add_child(game)
 game.begin_new()
 game.test_mode = false
func _process(delta):
 elapsed += delta
 if elapsed > 50: quit(2)
 if game == null: return false
 interval += delta
 if interval > 0.04:
  interval = 0
  var f = FileAccess.open("res://.local/window-probe.json", FileAccess.WRITE)
  f.store_string(JSON.stringify({"window":DisplayServer.window_get_native_handle(DisplayServer.WINDOW_HANDLE),"width":root.size.x,"exiting":game.exiting,"yaw":game.traveler.yaw,"pitch":game.traveler.pitch,"paused":game.paused,"mode":Input.mouse_mode,"compat":game.compat_mouse,"focus_pause":game.paused_for_focus}))
 return false
''', encoding='utf-8')
    state_path = project/'.local/window-probe.json'
    def state():
        try: return json.loads(state_path.read_text())
        except (OSError, ValueError): return {}
    def wait_for(condition, description):
        global checks
        deadline = time.monotonic()+8
        while time.monotonic() < deadline:
            value = state()
            if value and condition(value):
                checks += 1
                print('PASS: '+description, flush=True)
                return value
            if process.poll() is not None: break
            time.sleep(0.04)
        raise AssertionError(description+': '+str(state()))
    with (Path(tmp)/'run.log').open('w+') as log:
        process = subprocess.Popen(['godot','--path',str(project),'--max-fps','60','--audio-driver','Dummy','--log-file',str(Path(tmp)/'engine.log'),'--script','res://tests/window_probe.gd','--','--test'], stdout=log, stderr=log)
        dummy = None
        try:
            initial = wait_for(lambda s: True, 'native game window initializes')
            window = int(initial['window'])
            assert window, 'Godot X11 window not found'
            focus(display, window, 2, 0)
            flush(display)
            absolute(display, -1, 640, 360, 0)
            click()
            a = wait_for(lambda s: not s['paused'] and s['mode']==2, 'real click captures native pointer')
            motion(display, 45, -15, 0)
            flush(display)
            wait_for(lambda s: s['yaw'] < a['yaw']-.02 and s['pitch'] > a['pitch']+.01, 'real OS relative mouse turns right and up')
            tap(0xffc7)  # F10
            wait_for(lambda s: s['paused'] and s['mode']==0, 'real F10 releases pointer and pauses')
            tap(0xffc5)  # F8
            wait_for(lambda s: s['compat'] and s['paused'], 'compatibility mode can be selected while paused')
            tap(0xff1b)  # Escape
            a = wait_for(lambda s: not s['paused'] and s['mode']==4, 'Escape captures confined compatibility pointer')
            motion(display, 35, 0, 0)
            flush(display)
            wait_for(lambda s: s['yaw'] < a['yaw']-.02, 'real compatibility mouse changes view')
            resize(display, window, 960, 540)
            flush(display)
            a = wait_for(lambda s: s['width']==960 and s['mode']==4, 'compatibility mouse survives window resize')
            time.sleep(0.35)
            b = state()
            assert abs(a['yaw']-b['yaw']) < .01, 'resize must not cause idle camera drift'
            checks += 1
            print('PASS: resized compatibility view remains still without mouse movement',flush=True)
            motion(display, 35, -15, 0)
            flush(display)
            wait_for(lambda s: s['yaw'] < b['yaw']-.02 and s['pitch'] > b['pitch']+.01, 'real compatibility input works with viewport scaling')
            dummy = create(display, root, 0, 0, 100, 100, 0, 0, 0)
            map_window(display, dummy)
            flush(display)
            focus(display, dummy, 2, 0)
            flush(display)
            wait_for(lambda s: s['paused'] and s['mode']==0 and s['focus_pause'], 'OS focus loss automatically pauses and releases cursor')
            focus(display, window, 2, 0)
            flush(display)
            absolute(display, -1, 640, 360, 0)
            click()
            wait_for(lambda s: not s['paused'] and s['mode']==4, 'first actual click after focus return restores control')
            event = Event()
            event.client.type, event.client.display, event.client.window = 33, display, window
            event.client.message_type, event.client.format = wm_protocols, 32
            event.client.data[0] = wm_delete
            send(display, window, 0, 0, C.byref(event))
            flush(display)
            assert process.wait(timeout=8)==0
            assert (project/'.local/saves/journey.json').is_file()
            checks += 1
            print('PASS: OS window close saves and exits cleanly',flush=True)
            log.seek(0)
            output = log.read()
            assert not any(s in output for s in ['SCRIPT ERROR:', 'ERROR:']), output
        except Exception:
            log.flush()
            log.seek(0)
            print(log.read(), flush=True)
            print('Last input probe state:', state(), flush=True)
            if state_path.exists(): print('State age:', time.time()-state_path.stat().st_mtime, flush=True)
            raise
        finally:
            if dummy: destroy(display,dummy)
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=8)
            flush(display)
print(f'RESULT: {checks} native OS input checks, 0 failures')
