extends SceneTree
const Game = preload("res://scripts/game.gd")
const Progress = preload("res://scripts/progress.gd")
const C = preload("res://scripts/catalog.gd")
var checks := 0
var failures := 0
var capture_dir := ""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="): capture_dir = arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func frames(count: int) -> void:
 for i in range(count): await physics_frame
func check(ok: bool, text: String) -> void:
 checks += 1
 if ok: print("PASS: " + text)
 else:
  failures += 1
  push_error("FAIL: " + text)
func capture(name: String) -> void:
 if capture_dir.is_empty(): return
 await process_frame
 await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)
func key(code: Key) -> void:
 var event := InputEventKey.new()
 event.keycode = code
 event.physical_keycode = code
 event.pressed = true
 root.push_input(event, true)
func approach(game: Node3D, kind: String) -> void:
 for point in game.room.points:
  if point.kind == kind:
   game.traveler.position = point.position + Vector3.UP * 0.1
   game.traveler.velocity = Vector3.ZERO
   return
func run() -> void:
 var state = Progress.new()
 check(not state.expansion.craft("heal", state) and state.herbs() == 0, "missing recipe ingredients do not partially spend resources")
 state.herb_stock = 10
 state.beast_cores = 3
 state.expansion.materials.redflower = 3
 state.expansion.materials.dew = 4
 state.expansion.materials.ore = 8
 check(not state.expansion.craft("focus", state) and state.beast_cores == 3, "locked discovery recipe cannot be crafted even with ingredients")
 check(state.expansion.craft("mana", state) and state.mana_potions == 2 and state.expansion.materials.dew == 3 and state.herbs() == 8, "mana recipe consumes exact ingredients and creates two usable potions")
 state.expansion.recipes.append("focus")
 check(state.expansion.craft("focus", state) and state.item_count("focus") == 1 and state.beast_cores == 2, "unlocked focus recipe uses beast core and rare herb")
 var game = Game.new()
 root.add_child(game)
 game.begin_new()
 var p = game.progress
 p.claim_home()
 p.learned = true
 p.herb_stock = 10
 p.beast_cores = 3
 p.expansion.materials.redflower = 4
 p.expansion.materials.dew = 3
 game.traveler.position = game.adventure.HOME
 game.interact()
 await frames(3)
 approach(game, "alchemy")
 game.interact()
 await frames(3)
 check(game.paused and game.workshop.recipe_panel.visible and not game.workshop.craft_button.disabled, "actual indoor furnace opens affordable recipe interface")
 await capture("25-alchemy-recipes")
 game.workshop.start_chosen()
 await frames(35)
 check(game.workshop.active and game.traveler.busy and p.herbs() == 10 and p.heal_potions == 0, "brewing plays before consuming ingredients or awarding outputs")
 check(game.traveler.interaction_kind == "craft" and absf(game.traveler.left_arm.rotation.x) > 0.05, "brewing drives both-arm infusion pose")
 game.set_paused(true)
 var timer: float = game.workshop.elapsed
 await frames(15)
 check(game.workshop.elapsed == timer, "pause freezes brewing progress")
 game.set_paused(false)
 key(KEY_E)
 check(not game.workshop.active and p.herbs() == 10 and p.expansion.materials.redflower == 4, "E cancellation leaves ingredients untouched")
 game.interact()
 game.workshop.start_chosen()
 game.traveler.yaw = 0.8
 await frames(40)
 await capture("26-brewing-action")
 await frames(275)
 check(not game.workshop.active and p.herbs() == 8 and p.expansion.materials.redflower == 3 and p.heal_potions == 2, "completed real-time brewing produces one batch and deducts exact materials")
 await frames(25)
 check(p.heal_potions == 2 and p.expansion.batches == 1, "finished furnace does not duplicate rewards on later frames")
 p.hp = 35
 key(KEY_4)
 check(p.hp == 95 and p.heal_potions == 1, "crafted healing potion is usable by existing hotkey")
 game.interact()
 game.workshop.start_chosen()
 Input.action_press("forward")
 await frames(3)
 Input.action_release("forward")
 check(not game.workshop.active and not game.traveler.busy and p.herbs() == 8, "moving cancels active recipe and restores movement without material loss")
 approach(game, "forge")
 game.interact()
 check(game.workshop.recipe_panel.visible and game.workshop.craft_button.disabled, "forge shows exploration-locked blueprint")
 p.expansion.recipes.append("iron_blade")
 p.expansion.materials.ore = 4
 game.workshop.render_recipe()
 check(not game.workshop.craft_button.disabled, "discovered blueprint enables affordable forging")
 await capture("27-forge-blueprint")
 game.workshop.start_chosen()
 await frames(10)
 game.workshop.elapsed = game.workshop.duration - 0.03
 await frames(5)
 check(p.expansion.gear.size() == 1 and p.expansion.gear[0].id == "iron_blade" and p.expansion.materials.ore == 0 and p.beast_cores == 2, "forge completion creates real owned sword and consumes iron and core")
 p.expansion.materials.focus = 2
 key(KEY_6)
 var until: float = p.expansion.focus_until
 check(p.damage_bonus() == 8 and p.item_count("focus") == 1 and until > p.world_time + 119, "6 applies timed damage buff using one focus pill")
 key(KEY_6)
 check(p.item_count("focus") == 1 and p.expansion.focus_until == until, "active focus buff cannot waste a second pill")
 check(game.save_game(false) and game.continue_game() and game.progress.damage_bonus() == 8 and game.progress.item_count("focus") == 1, "alchemy inventory and remaining active buff survive save reload")
 p = game.progress
 p.world_time = p.expansion.focus_until + 0.1
 check(p.damage_bonus() == 0 and p.use_potion("focus") and p.damage_bonus() == 8, "buff expires with active world time and can be used again")
 p.expansion.materials.redflower = 2
 check(p.transfer_item("redflower", true, 2) and p.item_count("redflower") == 0 and p.item_count("redflower", true) == 2, "new herbs transfer into existing home chest")
 check(not p.expansion.can_craft("heal", p), "vault ingredients are not silently spent by furnace")
 p.transfer_item("redflower", false, 2)
 p.heal_potions = 3
 game.room.leave()
 game.traveler.position = Vector3(3, 0.1, 23.5)
 game.interact()
 game.town.accept("brew")
 var money: int = p.coins
 game.town.complete()
 check(p.coins == money + 26 and p.heal_potions == 1 and p.active_order.is_empty(), "new repeatable medicine order consumes two potions and pays once")
 game.town.complete()
 check(p.coins == money + 26, "repeat turn-in cannot duplicate medicine commission money")
 var economy = Progress.new()
 economy.buy("heal")
 economy.buy("heal")
 economy.accept_order("brew")
 economy.complete_order()
 check(economy.coins < 30, "buying potions then submitting cannot create a village-only money loop")
 game.set_paused(false)
 game.traveler.position = Vector3(-5, 0.1, 27.5)
 game.interact()
 var gold: int = p.coins
 var flowers: int = p.item_count("redflower")
 game.town.sell("redflower")
 check(p.coins == gold + 8 and p.item_count("redflower") == flowers - 1, "apothecary buys gathered rare herbs through actual nearby dialogue")
 gold = p.coins
 var dew: int = p.item_count("dew")
 game.town.buy("dew")
 check(p.coins == gold - 18 and p.item_count("dew") == dew + 1, "apothecary supplies missing alchemy ingredient at displayed price")
 await frames(3)
 await capture("32-apothecary-market")
 game.queue_free()
 await process_frame
 print("RESULT: %d checks, %d failures" % [checks, failures])
 quit(1 if failures else 0)
