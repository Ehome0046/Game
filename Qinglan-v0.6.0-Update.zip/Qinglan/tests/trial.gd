extends SceneTree
const Game = preload("res://scripts/game.gd")
const C = preload("res://scripts/catalog.gd")
var checks := 0
var failures := 0
var capture_dir := ""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="): capture_dir = arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func frames(count: int) -> void:
 for i in range(count): await physics_frame
func check(ok: bool, text: String) -> void:
 checks += 1
 if ok: print("PASS: "+text)
 else:
  failures += 1
  push_error("FAIL: "+text)
func capture(name: String) -> void:
 if capture_dir.is_empty(): return
 await process_frame
 await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func collect(game: Node3D) -> void:
 for item in game.progress.pending_loot.duplicate(true):
  game.traveler.position = Vector3(item.position[0],0.1,item.position[2])
  game.traveler.velocity = Vector3.ZERO
  game.interact()
func run() -> void:
 var game = Game.new()
 root.add_child(game)
 game.begin_new()
 var p = game.progress
 p.learned = true
 p.realm = 1
 p.hp = p.max_hp()
 p.qi = p.max_qi()
 p.beast_cores = 2
 game.traveler.position = C.POIS.shrine + Vector3.UP*0.1
 game.interact()
 await frames(3)
 check(p.expansion.secret_inside and p.expansion.trial_paid and p.beast_cores==1,"new trial charges one core and records an unclaimed paid attempt")
 check(not game.trial.active() and game.trial.seal_count()==0,"guardian starts dormant until all three seals are activated")
 game.traveler.position = C.CHESTS.shrine + Vector3(0,0.1,0.85)
 var drops: int = p.pending_loot.size()
 game.interact()
 check(p.pending_loot.size()==drops and "focus" not in p.expansion.recipes,"sealed chest cannot bypass the shrine encounter")
 game.traveler.position = game.trial.SEALS[0]+Vector3.UP*0.1
 game.interact()
 check(game.trial.seal_count()==1,"E activates a real in-world trial seal")
 game.interact()
 check(game.trial.seal_count()==1,"same seal cannot count twice")
 game.expedition.leave_shrine()
 var cores: int = p.beast_cores
 game.expedition.enter_shrine()
 check(p.beast_cores==cores and game.trial.seal_count()==1,"returning to an unfinished paid attempt preserves seals and does not charge again")
 for i in [1,2]:
  game.traveler.position = game.trial.SEALS[i]+Vector3.UP*0.1
  game.interact()
  await frames(2)
 check(game.trial.active() and game.trial.seal_count()==3,"third distinct seal awakens actual collidable guardian")
 game.traveler.position = game.trial.body.position+Vector3(0,0.1,1.4)
 game.traveler.velocity = Vector3.ZERO
 game.trial.cooldown = 0
 await frames(3)
 var hp: float = p.hp
 check(game.trial.warning.visible and p.hp==hp,"guardian attack is telegraphed before any damage")
 game.traveler.position = Vector3(6,0.1,-72)
 game.traveler.velocity = Vector3.ZERO
 await frames(65)
 check(p.hp==hp,"moving out of indicated attack avoids its damage")
 game.trial.windup = -1
 game.trial.cooldown = 0
 game.traveler.position = game.trial.body.position+Vector3(0,0.1,1.4)
 game.traveler.velocity = Vector3.ZERO
 await frames(65)
 check(p.hp<hp,"remaining within guardian attack range deals real damage")
 p.hp = p.max_hp()
 p.qi = p.max_qi()
 game.traveler.position = Vector3(-4,0.1,-69.5)
 game.traveler.velocity = Vector3.ZERO
 game.traveler.yaw = 0
 game.attack_cooldown = 0
 game.combo_window = 0
 await frames(2)
 await capture("34-awakened-moon-guardian")
 for i in range(9):
  if p.expansion.trial_defeated: break
  game.cast_sword()
  await frames(35)
 check(p.expansion.trial_defeated and p.expansion.trial_victories==1 and not game.trial.body.visible,"actual sword combat defeats guardian and records one victory")
 check("ward" in p.expansion.recipes and p.pending_loot.any(func(item):return item.item=="moonshard"),"victory unlocks defensive recipe and leaves physical promotion material")
 drops = p.pending_loot.size()
 game.trial.hit(10000)
 check(p.expansion.trial_victories==1 and p.pending_loot.size()==drops,"dead guardian cannot repeatedly award victory or loot")
 await capture("35-trial-loot-and-victory")
 check(game.save_game(false) and game.continue_game() and game.progress.expansion.trial_defeated and not game.trial.active(),"victory and unclaimed material survive reload without respawning guardian")
 p = game.progress
 collect(game)
 check(p.item_count("moonshard")==2,"E collects actual guardian crystal drop into crafting inventory")
 game.traveler.position = C.CHESTS.shrine+Vector3(0,0.1,0.85)
 game.interact()
 check(not p.expansion.trial_paid and "focus" in p.expansion.recipes and p.expansion.chest_visits.shrine==1,"victory unseals original chest and finishes paid attempt only after reward")
 collect(game)
 game.expedition.leave_shrine()
 cores = p.beast_cores
 check(not game.expedition.enter_shrine() and p.beast_cores==cores,"treasure recovery timer blocks a new attempt without charging")
 p.world_time = float(p.expansion.chest_ready.shrine)+0.1
 game.expedition.enter_shrine()
 check(p.expansion.trial_paid and p.expansion.trial_runes==0 and not p.expansion.trial_defeated,"next paid run resets seals and encounter after cooldown")
 p.expansion.trial_runes = 7
 game.trial.sync()
 p.hp = 1
 game.traveler.invincible = 0
 game.take_damage(999)
 check(not p.expansion.secret_inside and p.expansion.trial_paid and p.expansion.trial_runes==7,"defeat exits safely but preserves paid retry and activated seals")
 p.beast_cores = 0
 game.traveler.position = C.POIS.shrine+Vector3.UP*0.1
 check(game.expedition.enter_shrine() and p.beast_cores==0 and game.trial.hp==game.trial.MAX_HP,"zero-core player can retry an unfinished attempt with restored enemy health")
 game.expedition.leave_shrine()
 game.traveler.position = Vector3(3,0.1,23.5)
 game.interact()
 game.town.research()
 check(p.expansion.research_stage==0,"village research does not pay before its collection and production goals")
 p.expansion.discoveries.append("grove")
 p.expansion.batches = 1
 game.town.research()
 check(p.expansion.research_stage==1,"actual elder dialogue claims a completed research stage")
 await frames(3)
 await capture("36-elder-research-roadmap")
 game.set_paused(false)
 p.claim_home()
 game.traveler.position = game.adventure.HOME
 game.interact()
 game.traveler.position = game.workshop.stations.alchemy+Vector3.UP*0.1
 p.herb_stock = 4
 p.expansion.materials.redflower = 2
 p.expansion.materials.ore = 2
 game.interact()
 game.workshop.select_recipe("ward")
 check(not game.workshop.craft_button.disabled,"victory recipe is actually available at the home furnace")
 await frames(3)
 await capture("37-advanced-pill-recipe")
 game.workshop.start_chosen()
 await frames(20)
 game.workshop.elapsed = game.workshop.duration-0.03
 await frames(5)
 check(p.item_count("ward")==2 and p.herbs()==2 and p.item_count("ore")==1,"furnace produces defensive pills from trial-unlocked recipe with exact cost")
 check(game.save_game(false) and game.continue_game() and game.progress.item_count("ward")==2 and game.progress.expansion.trial_paid,"new medicine and unfinished trial both survive ordinary save reload")
 game.queue_free()
 await process_frame
 print("RESULT: %d checks, %d failures" % [checks,failures])
 quit(1 if failures else 0)
