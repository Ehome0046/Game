extends SceneTree
const Game = preload("res://scripts/game.gd")
const Progress = preload("res://scripts/progress.gd")
const C = preload("res://scripts/catalog.gd")
var checks := 0
var failures := 0
var capture_dir := ""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="): capture_dir = arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func frames(count: int) -> void:
 for i in range(count): await physics_frame
func check(ok: bool, text: String) -> void:
 checks += 1
 if ok: print("PASS: " + text)
 else:
  failures += 1
  push_error("FAIL: " + text)
func capture(name: String) -> void:
 if capture_dir.is_empty(): return
 await process_frame
 await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)
func click(button: Button) -> void:
 var event := InputEventMouseButton.new()
 event.position = button.get_global_rect().get_center()
 event.button_index = MOUSE_BUTTON_LEFT
 event.pressed = true
 root.push_input(event, true)
 event = event.duplicate()
 event.pressed = false
 root.push_input(event, true)
func key(code: Key) -> void:
 var event := InputEventKey.new()
 event.keycode = code
 event.physical_keycode = code
 event.pressed = true
 root.push_input(event, true)
func run() -> void:
 var game = Game.new()
 root.add_child(game)
 game.begin_new()
 game.progress.learned = true
 var p = game.progress
 p.add_gear_loot("jade_blade", Vector3(0, 0, 20))
 game.frontier.sync_loot()
 game.traveler.position = Vector3(0, 0.1, 20)
 game.interact()
 check(p.expansion.gear.size() == 1 and p.pending_loot.is_empty(), "E picks physical equipment into unique owned gear")
 var blade: int = p.expansion.gear[0].uid
 var robe: int = p.expansion.add_gear("cloud_robe")
 var charm: int = p.expansion.add_gear("moon_charm")
 await frames(3)
 key(KEY_B)
 check(game.paused and game.workshop.gear_panel.visible, "B opens equipment menu through real input")
 await frames(3)
 click(game.workshop.gear_buttons[blade])
 await frames(2)
 click(game.workshop.equip_button)
 await frames(2)
 check(int(p.expansion.equipped.weapon) == blade and p.damage_bonus() == 13, "gear UI equips blade and changes actual damage bonus")
 game.workshop.select_gear(robe)
 game.workshop.equip_selected()
 game.workshop.select_gear(charm)
 game.workshop.equip_selected()
 check(p.max_hp() == 130 and p.max_qi() == 135 and p.expansion.bonuses().armor == 4, "robe and charm add health, mana and armor")
 check(game.traveler.cloth.albedo_color == Color(C.GEAR.cloud_robe.tint) and game.traveler.charm.visible and game.effects.weapon_scale > 1, "equipped items change robe, ornament and flying sword appearance")
 check(game.workshop.salvage_button.disabled and game.workshop.sell_button.disabled, "worn equipment is protected from accidental salvage or sale")
 await capture("23-equipment-bag")
 game.set_paused(false)
 p.hp = 100
 game.take_damage(20)
 check(p.hp == 84, "armor reduces actual incoming damage")
 game.traveler.position = game.valley.beast.position + Vector3(0, 0.1, 5)
 game.traveler.yaw = 0
 game.attack_cooldown = 0
 await frames(3)
 var hp: float = game.beast_hp
 check(game.cast_sword(), "equipped flying sword launches into actual encounter")
 await frames(35)
 check(is_equal_approx(hp - game.beast_hp, 45), "real projectile includes equipped blade and charm damage")
 var copied: Dictionary = p.snapshot(Vector3(0, 0.1, 18))
 var restored = Progress.new()
 check(restored.restore(JSON.parse_string(JSON.stringify(copied))) and restored.expansion.equipped.weapon == blade and restored.max_hp() == 130, "all gear and derived stats survive JSON roundtrip")
 copied.expansion.gear.append(copied.expansion.gear[0].duplicate(true))
 check(not restored.restore(copied) and restored.expansion.gear.size() == 3, "duplicate gear identities reject atomically")
 copied = p.snapshot(Vector3.ZERO)
 copied.expansion.equipped.weapon = robe
 check(not restored.restore(copied), "wrong-slot gear cannot equip through malformed save")
 copied = p.snapshot(Vector3.ZERO)
 copied.expansion.materials.ore = -1
 check(not restored.restore(copied), "negative new material count rejects without losing live gear")
 game.traveler.position = Vector3(7, 0.1, 29)
 game.workshop.open_gear()
 game.workshop.select_gear(robe)
 game.workshop.equip_selected()
 p.hp = p.max_hp()
 var money: int = p.coins
 game.workshop.sell_selected()
 check(p.expansion.find_gear(robe).is_empty() and p.coins == money + 75 and p.hp <= p.max_hp(), "merchant sells owned unequipped gear once and keeps vitals valid")
 game.workshop.sell_selected()
 check(p.coins == money + 75, "stale sale cannot duplicate money")
 game.set_paused(false)
 game.traveler.position = Vector3(0, 0.1, 18)
 game.workshop.open_gear()
 game.workshop.select_gear(charm)
 game.workshop.equip_selected()
 var ore: int = p.expansion.materials.ore
 game.workshop.salvage_selected()
 check(p.expansion.find_gear(charm).is_empty() and p.expansion.materials.ore == ore + 3, "salvage consumes exactly one item and recovers its grade of iron")
 game.set_paused(false)
 var small = Progress.new()
 for i in range(small.expansion.MAX_GEAR): small.expansion.add_gear("twig_blade")
 var loot: int = small.add_gear_loot("jade_blade", Vector3.ZERO)
 check(not small.pickup_loot(loot) and small.pending_loot.size() == 1, "full gear bag preserves uncollected physical equipment")
 small.expansion.remove(int(small.expansion.gear[0].uid), small)
 check(small.pickup_loot(loot) and not small.pickup_loot(loot), "freed slot accepts pending gear once without duplication")
 var legacy := {"version": 4, "name": "旧洞府主人", "robe": 1, "learned": true, "collected": [0,1,2,3], "core": true, "beast_dead": true, "realm": 1, "hp": 135, "qi": 125, "position": [-3.4,0.1,-2.4],
 "herb_stock": 5, "home_claimed": true, "home_style": 2, "vault_herbs": 9, "vault_items": {"core": 2,"seed": 1,"heal": 3,"mana": 2}, "inside_home": true,
 "seeds": 4, "plots": [90,-1,-1], "world_time": 20, "cultivation": 1, "runes": 3, "spitter_dead": true, "guardian_dead": true, "relic": true,
 "beast_cores": 3, "coins": 345, "heal_potions": 2, "mana_potions": 4, "weapon_level": 2, "active_order": "hunt", "orders_completed": 6, "surveyed": false,
 "pending_loot": [{"uid":1,"item":"core","count":2,"position":[-25,0.2,23]}], "next_loot_id":2, "monster_ready":{}, "herb_ready":{}}
 var original := JSON.stringify(legacy)
 var file := FileAccess.open(Game.SAVE, FileAccess.WRITE)
 file.store_string(original)
 file.close()
 check(game.continue_game() and game.progress.coins == 345 and game.progress.vault_herbs == 9 and game.progress.vault_items.core == 2 and game.progress.pending_loot.size() == 1, "genuine v4 schema migrates coins, old chest and uncollected loot")
 check(FileAccess.get_file_as_string(Game.SAVE + ".v4.bak") == original and game.progress.inside_home and game.traveler.position.y > 29, "v4 backup is exact and indoor location is preserved")
 check(game.progress.expansion.gear.is_empty() and game.progress.expansion.recipes == ["heal","mana"], "migration initializes crafting without granting or deleting old equipment resources")
 await frames(10)
 game.traveler.yaw = 0.5
 await frames(3)
 await capture("24-furnished-workshop")
 game.queue_free()
 await process_frame
 print("RESULT: %d checks, %d failures" % [checks, failures])
 quit(1 if failures else 0)
