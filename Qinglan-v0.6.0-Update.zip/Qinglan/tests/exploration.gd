extends SceneTree
const Game = preload("res://scripts/game.gd")
const Progress = preload("res://scripts/progress.gd")
const C = preload("res://scripts/catalog.gd")
var checks := 0
var failures := 0
var capture_dir := ""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="): capture_dir = arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func frames(count: int) -> void:
 for i in range(count): await physics_frame
func check(ok: bool, text: String) -> void:
 checks += 1
 if ok: print("PASS: " + text)
 else:
  failures += 1
  push_error("FAIL: " + text)
func capture(name: String) -> void:
 if capture_dir.is_empty(): return
 await process_frame
 await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)
func collect(game: Node3D) -> void:
 for item in game.progress.pending_loot.duplicate(true):
  game.traveler.position = Vector3(item.position[0], 0.1, item.position[2])
  game.traveler.velocity = Vector3.ZERO
  game.interact()
func walk(game: Node3D, target: Vector3, limit := 250) -> void:
 game.traveler.yaw = 0
 for i in range(limit):
  var offset: Vector3 = target - game.traveler.position
  offset.y = 0
  if offset.length() < 1.0: break
  var direction: Vector3 = offset.normalized()
  Input.action_press("right", maxf(direction.x, 0))
  Input.action_press("left", maxf(-direction.x, 0))
  Input.action_press("forward", maxf(-direction.z, 0))
  Input.action_press("back", maxf(direction.z, 0))
  await frames(1)
 for action in ["right", "left", "forward", "back"]: Input.action_release(action)
func run() -> void:
 var game = Game.new()
 root.add_child(game)
 game.begin_new()
 game.progress.learned = true
 var p = game.progress
 game.traveler.position = Vector3(56, 0.1, 25)
 game.traveler.yaw = 0
 game.expedition.target_index = 1
 await frames(4)
 await capture("28-mine-entrance")
 await walk(game, Vector3(56, 0.1, 10), 245)
 check(game.traveler.position.distance_to(Vector3(56, 0.1, 10)) < 1.5, "player physically enters mine along rails without hitting entrance or braces")
 game.interact()
 check("iron_blade" in p.expansion.recipes and p.pending_loot.any(func(item): return item.item == "gear"), "real mine chest unlocks blueprint and drops physical equipment")
 var count: int = p.pending_loot.size()
 check(not game.expedition.open_chest("mine") and p.pending_loot.size() == count, "opened treasure cannot be looted again before recovery")
 collect(game)
 check(p.expansion.gear.size() == 1 and p.item_count("ore") == 4, "mine rewards can be picked up and used for crafting")
 game.traveler.position = C.NODES[6].at + Vector3.UP * 0.1
 game.traveler.velocity = Vector3.ZERO
 game.interact()
 check(p.item_count("ore") == 5 and not game.expedition.harvest("6"), "mining produces iron once and respects its cooldown")
 p.world_time += 91
 game.interact()
 check(p.item_count("ore") == 6, "ore vein renews after active world time")
 game.traveler.position = C.NODES[0].at + Vector3.UP * 0.1
 game.interact()
 game.traveler.position = C.NODES[3].at + Vector3.UP * 0.1
 game.interact()
 check(p.item_count("redflower") == 1 and p.item_count("dew") == 1, "distinct visible herbs yield distinct alchemy ingredients")
 game.traveler.position = Vector3(-54, 0.1, 24)
 game.traveler.yaw = 0
 game.expedition.target_index = 0
 await frames(18)
 await capture("29-herb-valley")
 check("grove" in p.expansion.discoveries and "mine" in p.expansion.discoveries, "nearby exploration landmarks are discovered and tracked")
 game.traveler.position = C.CHESTS.grove + Vector3(0, 0.1, 0.85)
 game.interact()
 check(p.expansion.chest_visits.grove == 1 and p.pending_loot.size() >= 3, "hidden herb valley chest has actual renewable rewards")
 collect(game)
 game.traveler.position = C.POIS.shrine + Vector3.UP * 0.1
 check(not game.expedition.enter_shrine() and p.beast_cores == 0, "portal rejects an uninitiated player without charging materials")
 p.realm = 1
 check(not game.expedition.enter_shrine(), "cultivation alone cannot bypass required beast core")
 p.beast_cores = 2
 check(game.expedition.enter_shrine() and p.expansion.secret_inside and p.beast_cores == 1, "portal consumes one core and moves player inside sealed secret area")
 check(not game.expedition.enter_shrine() and p.beast_cores == 1, "repeat portal event cannot double charge entry")
 await walk(game, Vector3(0, 0.1, -74.6), 85)
 await frames(3)
 await capture("30-moon-shrine")
 # The dedicated trial suite checks the actual fight; prepare its completed gate here.
 p.expansion.trial_runes = 7
 game.trial.sync()
 game.trial.hit(10000)
 game.traveler.position = C.CHESTS.shrine+Vector3(0,0.1,0.85)
 game.traveler.velocity = Vector3.ZERO
 game.interact()
 check("focus" in p.expansion.recipes and p.pending_loot.any(func(item): return item.get("gear_id", "") == "moon_charm"), "secret chest unlocks advanced pill recipe and rare charm")
 collect(game)
 check(game.save_game(false) and game.continue_game() and game.progress.expansion.secret_inside and game.traveler.position.z < -67, "save reload preserves a safe playable secret area location")
 p = game.progress
 var money: int = p.coins
 var amount: int = p.beast_cores
 game.traveler.position = Vector3(0, 0.1, -68.8)
 game.interact()
 check(not p.expansion.secret_inside and game.traveler.position.distance_to(C.POIS.shrine) < 2, "return portal exits the secret area to its original approach")
 check(not game.expedition.enter_shrine() and p.beast_cores == amount and p.coins == money, "cooling secret chest blocks pointless entry without charging another core")
 p.world_time = float(p.expansion.chest_ready.shrine) + 0.1
 check(game.expedition.enter_shrine(), "recovered secret treasure permits another exploration run")
 game.expedition.leave_shrine()
 p.claim_home()
 game.traveler.position = game.adventure.HOME
 game.interact()
 await frames(3)
 check(not game.expedition.ambience_active and not game.expedition.wind.playing and not game.expedition.water_sound.playing, "outdoor ambient sound pauses indoors")
 game.room.leave()
 await frames(2)
 check(game.expedition.ambience_active and game.expedition.wind.stream.data.size() == 88200, "outdoor sound resumes using compact generated looping data")
 if DisplayServer.get_name() != "headless":
  check(game.expedition.wind.playing and game.expedition.water_sound.playing, "native ambient players actually play their generated streams")
 game.set_paused(true)
 await frames(2)
 check(not game.expedition.ambience_active and not game.expedition.wind.playing, "pause menu also suspends outdoor ambience")
 game.set_paused(false)
 var fixture: Dictionary = p.snapshot(Vector3(0, 0.1, -72))
 fixture.expansion.secret_inside = false
 check(p.restore(fixture), "legacy free exploration position remains a valid save")
 game.start_game(Vector3(0, 0.1, -72))
 check(game.traveler.position.distance_to(C.POIS.shrine) < 2, "old outdoor position inside new sealed geometry recovers outside gate")
 game.navigation.open_map()
 game.navigation.map_view.region_view = true
 await frames(2)
 await capture("31-exploration-map")
 check(game.navigation.map_view.bounds() == 80 and C.POIS.size() == 3, "new points fit existing regional map")
 game.queue_free()
 await process_frame
 print("RESULT: %d checks, %d failures" % [checks, failures])
 quit(1 if failures else 0)
