extends SceneTree
const Game = preload("res://scripts/game.gd")
const Progress = preload("res://scripts/progress.gd")
var checks := 0
var failures := 0
var capture_dir := ""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="): capture_dir = arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func frames(count: int) -> void:
 for i in range(count): await physics_frame
func check(ok: bool, text: String) -> void:
 checks += 1
 if ok: print("PASS: "+text)
 else:
  failures += 1
  push_error("FAIL: "+text)
func capture(name: String) -> void:
 if capture_dir.is_empty(): return
 await process_frame
 await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func click(button: Button) -> void:
 var event := InputEventMouseButton.new()
 event.position = button.get_global_rect().get_center()
 event.button_index = MOUSE_BUTTON_LEFT
 event.pressed = true
 root.push_input(event,true)
 event = event.duplicate()
 event.pressed = false
 root.push_input(event,true)
func run() -> void:
 var p = Progress.new()
 var uid: int = p.expansion.add_gear("twig_blade")
 p.coins = 10
 p.expansion.materials.ore = 5
 check(not p.expansion.refine(uid,p) and p.coins==10 and p.expansion.materials.ore==5 and p.expansion.find_gear(uid).level==0,"unaffordable refinement leaves money, ore and item untouched")
 p.coins = 3000
 p.expansion.materials.ore = 60
 p.expansion.materials.moonshard = 8
 p.beast_cores = 8
 p.expansion.equip(uid,p)
 check(p.expansion.refine(uid,p) and p.coins==2980 and p.expansion.materials.ore==59 and p.damage_bonus()==5,"first refinement consumes displayed cost and raises actual weapon bonus")
 for i in range(4): p.expansion.refine(uid,p)
 var gold: int = p.coins
 check(p.expansion.find_gear(uid).level==5 and not p.expansion.refine(uid,p) and p.coins==gold,"maximum refinement cannot overcharge or exceed five")
 check(p.expansion.promote(uid,p) and p.expansion.find_gear(uid).id=="iron_blade" and p.expansion.find_gear(uid).level==5 and p.damage_bonus()==17,"promotion preserves unique identity and refinement while raising quality")
 check(p.expansion.promote(uid,p) and p.expansion.find_gear(uid).id=="jade_blade" and p.damage_bonus()==23,"second quality promotion upgrades the equipped weapon")
 gold = p.coins
 check(not p.expansion.promote(uid,p) and p.coins==gold,"top quality cannot consume promotion materials again")
 var robe: int = p.expansion.add_gear("linen_robe")
 var charm: int = p.expansion.add_gear("wood_charm")
 p.expansion.equip(robe,p)
 p.expansion.equip(charm,p)
 p.expansion.refine(robe,p)
 p.expansion.refine(charm,p)
 check(p.max_hp()==112 and p.max_qi()==115,"robe and charm refinement affect their own primary attributes")
 var restored = Progress.new()
 check(restored.restore(JSON.parse_string(JSON.stringify(p.snapshot(Vector3.ZERO)))) and restored.expansion.find_gear(uid).level==5 and restored.damage_bonus()==24,"refined equipped gear survives JSON persistence")
 var bad: Dictionary = p.snapshot(Vector3.ZERO)
 bad.expansion.gear[0].level = 6
 check(not restored.restore(bad) and restored.expansion.find_gear(uid).level==5,"invalid refinement save rejects atomically")
 p.hp = p.max_hp()
 p.expansion.equip(robe,p)
 check(p.hp<=p.max_hp(),"removing refined armor keeps current health within cap")
 var craft = Progress.new()
 craft.herb_stock = 10
 craft.expansion.materials.redflower = 6
 craft.expansion.materials.dew = 4
 craft.beast_cores = 3
 for i in range(3): craft.expansion.craft("heal",craft)
 check("elixir" in craft.expansion.recipes,"three completed batches unlock full-recovery recipe")
 check(craft.expansion.craft("elixir",craft) and craft.item_count("elixir")==1,"learned advanced recipe creates a usable full-recovery pill")
 check(not craft.use_potion("elixir") and craft.item_count("elixir")==1,"full recovery pill is not wasted at full health and mana")
 craft.hp = 20
 craft.qi = 12
 check(craft.use_potion("elixir") and craft.hp==craft.max_hp() and craft.qi==craft.max_qi(),"advanced pill restores both actual resource pools")
 craft.expansion.materials.ward = 2
 check(craft.use_potion("ward") and craft.armor_bonus()==3 and not craft.use_potion("ward") and craft.item_count("ward")==1,"ward buff consumes once and cannot be stacked by repeated use")
 craft.world_time = craft.expansion.ward_until+0.1
 check(craft.armor_bonus()==0,"ward armor expires with active world time")
 var rewards = Progress.new()
 check(not rewards.expansion.claim_research(rewards),"uncompleted research cannot pay rewards")
 rewards.expansion.discoveries = ["grove"]
 rewards.expansion.batches = 1
 check(rewards.expansion.claim_research(rewards) and rewards.coins==70,"first exploration-production milestone pays exactly forty coins")
 check(not rewards.expansion.claim_research(rewards) and rewards.coins==70,"claim cannot skip the next unfinished research step")
 for id in ["twig_blade","linen_robe","wood_charm"]:
  var item: int = rewards.expansion.add_gear(id)
  rewards.expansion.equip(item,rewards)
 rewards.expansion.discoveries.append("mine")
 check(rewards.expansion.claim_research(rewards) and rewards.coins==130 and rewards.item_count("ore")==2,"equipped exploration milestone pays coins and crafting iron")
 rewards.expansion.trial_victories = 1
 check(rewards.expansion.claim_research(rewards) and rewards.coins==230 and rewards.item_count("moonshard")==2,"trial research milestone pays rare promotion material")
 check(not rewards.expansion.claim_research(rewards) and rewards.coins==230,"finished research chain cannot be farmed repeatedly")
 var game = Game.new()
 root.add_child(game)
 game.begin_new()
 p = game.progress
 p.claim_home()
 p.learned = true
 p.coins = 2000
 p.expansion.materials.ore = 30
 p.expansion.materials.moonshard = 5
 uid = p.expansion.add_gear("twig_blade")
 p.expansion.equip(uid,p)
 game.traveler.position = game.adventure.HOME
 game.interact()
 game.traveler.position = game.workshop.stations.forge + Vector3.UP*0.1
 game.workshop.open_gear()
 await frames(4)
 click(game.workshop.refine_button)
 await frames(3)
 check(p.expansion.find_gear(uid).level==1 and p.coins==1980,"actual forge-side UI refines the selected owned item")
 click(game.workshop.promote_button)
 await frames(3)
 check(p.expansion.find_gear(uid).id=="iron_blade" and p.expansion.find_gear(uid).uid==uid and p.damage_bonus()==9,"actual promotion UI preserves and upgrades equipped sword")
 await capture("33-refinement-and-promotion")
 game.set_paused(false)
 game.room.leave()
 game.traveler.position = Vector3(0,0.1,18)
 game.workshop.open_gear()
 gold = p.coins
 game.workshop.refine_selected()
 check(game.workshop.refine_button.disabled and p.coins==gold,"remote equipment menu cannot refine away from forge or merchant")
 game.set_paused(false)
 p.expansion.materials.ward = 1
 var event := InputEventKey.new()
 event.keycode = KEY_7
 event.physical_keycode = KEY_7
 event.pressed = true
 root.push_input(event,true)
 p.hp = 100
 game.take_damage(20)
 check(p.hp==83 and p.item_count("ward")==0,"7 uses defensive pill and reduces real incoming damage")
 p.expansion.materials.elixir = 1
 p.qi = 10
 event = InputEventKey.new()
 event.keycode = KEY_8
 event.physical_keycode = KEY_8
 event.pressed = true
 root.push_input(event,true)
 check(p.hp==p.max_hp() and p.qi==p.max_qi() and p.item_count("elixir")==0,"8 uses full-recovery potion through gameplay input")
 var legacy := {"version":5,"name":"旧寻宝者","robe":1,"learned":true,"collected":[0,1,2,3],"core":true,"beast_dead":true,"realm":1,"hp":150,"qi":120,"position":[0,0.1,-74.6],
 "herb_stock":6,"home_claimed":true,"home_style":1,"vault_herbs":4,"vault_items":{"core":2,"seed":1,"heal":2,"mana":3},"inside_home":false,"seeds":3,"plots":[90,-1,-1],"world_time":20,"cultivation":0,"runes":3,"spitter_dead":true,"guardian_dead":true,"relic":true,
 "beast_cores":3,"coins":222,"heal_potions":2,"mana_potions":3,"weapon_level":1,"active_order":"brew","orders_completed":4,"surveyed":false,"pending_loot":[],"next_loot_id":1,"monster_ready":{},"herb_ready":{},
 "expansion":{"materials":{"redflower":2,"dew":3,"ore":4,"focus":1},"vault":{"redflower":1,"dew":2,"ore":3,"focus":0},"gear":[{"uid":7,"id":"iron_blade"},{"uid":9,"id":"moss_robe"}],"next_gear":10,"equipped":{"weapon":7,"robe":9,"charm":0},"recipes":["heal","mana","focus","iron_blade"],"batches":4,"kills":6,"focus_until":40,"node_ready":{},"chest_ready":{},"chest_visits":{},"discoveries":["grove","mine","shrine"],"secret_inside":true}}
 var original := JSON.stringify(legacy)
 var file := FileAccess.open(Game.SAVE,FileAccess.WRITE)
 file.store_string(original)
 file.close()
 check(game.continue_game() and game.progress.coins==222 and game.progress.expansion.find_gear(7).level==0 and game.progress.expansion.materials.ore==4,"genuine v5 save migrates owned gear, counters, currency and ingredients")
 check(FileAccess.get_file_as_string(Game.SAVE+".v5.bak")==original,"v5 migration retains byte-exact original backup")
 check(game.progress.expansion.secret_inside and game.progress.expansion.trial_defeated and game.progress.expansion.trial_runes==7 and not game.trial.active(),"old save already inside shrine is not forced into a newly spawned fight")
 check("elixir" in game.progress.expansion.recipes and game.progress.item_count("moonshard")==0,"existing mastery grants new recipe while initializing new materials safely")
 check(game.save_game(false) and game.continue_game() and game.progress.expansion.find_gear(9).level==0,"migrated state saves and reloads under current schema")
 game.queue_free()
 await process_frame
 print("RESULT: %d checks, %d failures" % [checks,failures])
 quit(1 if failures else 0)
