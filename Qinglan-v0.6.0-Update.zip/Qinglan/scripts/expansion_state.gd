extends RefCounted
const C = preload("res://scripts/catalog.gd")
const MAX_GEAR := 60
var materials := {"redflower": 0, "dew": 0, "ore": 0, "focus": 0, "moonshard": 0, "ward": 0, "elixir": 0}
var vault := {"redflower": 0, "dew": 0, "ore": 0, "focus": 0, "moonshard": 0, "ward": 0, "elixir": 0}
var gear: Array = []
var next_gear := 1
var equipped := {"weapon": 0, "robe": 0, "charm": 0}
var recipes: Array = ["heal", "mana"]
var batches := 0
var kills := 0
var focus_until := 0.0
var node_ready := {}
var chest_ready := {}
var chest_visits := {}
var discoveries: Array = []
var secret_inside := false
var ward_until := 0.0
var trial_paid := false
var trial_runes := 0
var trial_defeated := false
var trial_victories := 0
var research_stage := 0

func find_gear(uid: int) -> Dictionary:
 for item in gear:
  if int(item.uid) == uid: return item
 return {}

func gear_stats(item: Dictionary) -> Dictionary:
 var data: Dictionary = C.GEAR[item.id]
 var result := {"attack": int(data.attack), "hp": int(data.hp), "qi": int(data.qi), "armor": int(data.armor)}
 var level := int(item.get("level", 0))
 match data.slot:
  "weapon": result.attack += level * 2
  "robe":
   result.hp += level * 4
   result.armor += floori(level / 2.0)
  "charm":
   result.qi += level * 5
   result.attack += floori(level / 2.0)
 return result

func bonuses() -> Dictionary:
 var result := {"attack": 0, "hp": 0, "qi": 0, "armor": 0}
 for uid in equipped.values():
  var item := find_gear(int(uid))
  if item.is_empty(): continue
  var stats := gear_stats(item)
  for stat in result: result[stat] += stats[stat]
 return result

func add_gear(id: String) -> int:
 if not C.GEAR.has(id) or gear.size() >= MAX_GEAR: return -1
 var uid := next_gear
 next_gear += 1
 gear.append({"uid": uid, "id": id, "level": 0})
 return uid

func cap_vitals(p: RefCounted) -> void:
 p.hp = minf(p.hp, p.max_hp())
 p.qi = minf(p.qi, p.max_qi())

func equip(uid: int, p: RefCounted) -> bool:
 var item := find_gear(uid)
 if item.is_empty(): return false
 var slot: String = C.GEAR[item.id].slot
 equipped[slot] = 0 if int(equipped[slot]) == uid else uid
 cap_vitals(p)
 return true

func refine_cost(uid: int) -> Dictionary:
 var item := find_gear(uid)
 if item.is_empty() or int(item.level) >= 5: return {}
 var level := int(item.level)
 var cost := {"coins": 20 + level * 30, "ore": level + 1}
 if level >= 3: cost.core = 1
 return cost

func promote_cost(uid: int) -> Dictionary:
 var item := find_gear(uid)
 if item.is_empty(): return {}
 var quality := int(C.GEAR[item.id].quality)
 if quality >= 2: return {}
 return {"coins": 180 * (quality + 1), "ore": 4 * (quality + 1), "moonshard": quality + 1}

func can_pay(cost: Dictionary, p: RefCounted) -> bool:
 if cost.is_empty(): return false
 for item in cost:
  if (p.coins if item == "coins" else p.item_count(item)) < int(cost[item]): return false
 return true

func pay(cost: Dictionary, p: RefCounted) -> void:
 for item in cost: p.add_item(item, -int(cost[item]))

func refine(uid: int, p: RefCounted) -> bool:
 var cost := refine_cost(uid)
 if not can_pay(cost, p): return false
 pay(cost, p)
 find_gear(uid).level += 1
 return true

func promote(uid: int, p: RefCounted) -> bool:
 var item := find_gear(uid)
 var cost := promote_cost(uid)
 if not can_pay(cost, p): return false
 var data: Dictionary = C.GEAR[item.id]
 var next := ""
 for id in C.GEAR:
  if C.GEAR[id].slot == data.slot and C.GEAR[id].quality == data.quality + 1: next = id
 if next.is_empty(): return false
 pay(cost, p)
 item.id = next
 return true

func unlock_mastery() -> void:
 if batches >= 3 and "elixir" not in recipes: recipes.append("elixir")

func research_text(p: RefCounted) -> String:
 match research_stage:
  0: return "研习一：发现落霞药谷，并完成一次制作。奖励 40 金币。"
  1: return "研习二：发现矿洞，并穿戴飞剑、衣服、护符。奖励 60 金币、2 灵铁。"
  2: return "研习三：击败一次望月守卫。奖励 100 金币、2 月华晶。"
 return "三段研习已完成。继续温养装备、炼丹与反复挑战秘境。"

func claim_research(p: RefCounted) -> bool:
 match research_stage:
  0:
   if "grove" not in discoveries or batches < 1: return false
   p.coins += 40
  1:
   if "mine" not in discoveries or equipped.values().any(func(uid): return int(uid) == 0) or materials.ore > 99998: return false
   p.coins += 60
   materials.ore += 2
  2:
   if trial_victories < 1 or materials.moonshard > 99998: return false
   p.coins += 100
   materials.moonshard += 2
  _: return false
 research_stage += 1
 return true

func remove(uid: int, p: RefCounted, sell := false) -> bool:
 var item := find_gear(uid)
 if item.is_empty(): return false
 var data: Dictionary = C.GEAR[item.id]
 if not sell and int(materials.ore) + 1 + int(data.quality) > 100000: return false
 for slot in equipped:
  if int(equipped[slot]) == uid: equipped[slot] = 0
 gear.erase(item)
 if sell: p.coins += data.price
 else: materials.ore += 1 + int(data.quality)
 cap_vitals(p)
 return true

func can_craft(id: String, p: RefCounted) -> bool:
 if id not in recipes or not C.RECIPES.has(id): return false
 var recipe: Dictionary = C.RECIPES[id]
 if recipe.has("gear") and gear.size() >= MAX_GEAR: return false
 for item in recipe.cost:
  if p.item_count(item) < int(recipe.cost[item]): return false
 if recipe.has("item") and p.item_count(recipe.item) + int(recipe.count) > 100000: return false
 return true

func craft(id: String, p: RefCounted) -> bool:
 if not can_craft(id, p): return false
 var recipe: Dictionary = C.RECIPES[id]
 for item in recipe.cost: p.add_item(item, -int(recipe.cost[item]))
 if recipe.has("gear"): add_gear(recipe.gear)
 else: p.add_item(recipe.item, int(recipe.count))
 batches += 1
 unlock_mastery()
 return true

func drop_gear(species: int) -> String:
 # Persistent sequence avoids rerolling the same death by loading a save.
 kills += 1
 if kills != 1 and kills % 3 != 0: return ""
 var quality := 2 if kills % 12 == 0 else (1 if kills % 3 == 0 else 0)
 var slot: String = C.SLOTS[posmod(floori(kills / 3.0) + species, 3)]
 for id in C.GEAR:
  if C.GEAR[id].slot == slot and C.GEAR[id].quality == quality: return id
 return ""

func snapshot() -> Dictionary:
 return {"materials": materials.duplicate(), "vault": vault.duplicate(), "gear": gear.duplicate(true), "next_gear": next_gear, "equipped": equipped.duplicate(),
 "recipes": recipes.duplicate(), "batches": batches, "kills": kills, "focus_until": focus_until, "node_ready": node_ready.duplicate(), "chest_ready": chest_ready.duplicate(),
 "chest_visits": chest_visits.duplicate(), "discoveries": discoveries.duplicate(), "secret_inside": secret_inside, "ward_until": ward_until,
 "trial_paid": trial_paid, "trial_runes": trial_runes, "trial_defeated": trial_defeated, "trial_victories": trial_victories, "research_stage": research_stage}

static func integer(value: Variant, low := 0, high := 100000000) -> bool:
 return (value is int or value is float) and is_finite(float(value)) and value == int(value) and value >= low and value <= high

func restore(data: Variant, world_time: float, save_version := 6) -> bool:
 if not data is Dictionary: return false
 var added := ["ward_until", "trial_paid", "trial_runes", "trial_defeated", "trial_victories", "research_stage"]
 for key in snapshot():
  if save_version < 6 and key in added: continue
  if not data.has(key): return false
 for key in ["materials", "vault"]:
  var expected: Array = C.MATERIALS if save_version >= 6 else ["redflower", "dew", "ore", "focus"]
  if not data[key] is Dictionary or data[key].size() != expected.size(): return false
  for item in expected:
   if not integer(data[key].get(item), 0, 100000): return false
 for key in ["next_gear", "batches", "kills"]:
  if not integer(data[key]): return false
 if data.next_gear < 1 or not data.gear is Array or data.gear.size() > MAX_GEAR: return false
 var ids := []
 for item in data.gear:
  if not item is Dictionary or not integer(item.get("uid"), 1) or item.uid >= data.next_gear or int(item.uid) in ids or not C.GEAR.has(item.get("id")): return false
  if save_version >= 6 and not integer(item.get("level"), 0, 5): return false
  ids.append(int(item.uid))
 if not data.equipped is Dictionary or data.equipped.size() != 3: return false
 for slot in C.SLOTS:
  var uid: Variant = data.equipped.get(slot)
  if not integer(uid): return false
  if uid == 0: continue
  if int(uid) not in ids: return false
  var index := ids.find(int(uid))
  if C.GEAR[data.gear[index].id].slot != slot: return false
 if not data.recipes is Array or data.recipes.size() > C.RECIPES.size(): return false
 var unique := []
 for id in data.recipes:
  if not id is String or not C.RECIPES.has(id) or id in unique: return false
  unique.append(id)
 if "heal" not in unique or "mana" not in unique: return false
 if not (data.focus_until is int or data.focus_until is float) or not is_finite(float(data.focus_until)) or data.focus_until < 0 or data.focus_until > world_time + 120.1: return false
 for key in ["node_ready", "chest_ready", "chest_visits"]:
  if not data[key] is Dictionary or data[key].size() > 32: return false
  for id in data[key]:
   if not id is String: return false
   if key == "node_ready":
    if not id.is_valid_int() or int(id) < 0 or int(id) >= C.NODES.size(): return false
   elif not C.CHESTS.has(id): return false
   var value: Variant = data[key][id]
   if key == "chest_visits":
    if not integer(value): return false
   elif not (value is int or value is float) or not is_finite(float(value)) or value < 0 or value > world_time + 180.1: return false
 if not data.discoveries is Array or data.discoveries.size() > 3: return false
 unique.clear()
 for id in data.discoveries:
  if not id is String or not C.POIS.has(id) or id in unique: return false
  unique.append(id)
 if not data.secret_inside is bool: return false
 var next_ward := 0.0
 var next_paid := false
 var next_runes := 0
 var next_defeated := false
 var next_victories := 0
 var next_research := 0
 if save_version >= 6:
  if not (data.ward_until is int or data.ward_until is float) or not is_finite(float(data.ward_until)) or data.ward_until < 0 or data.ward_until > world_time + 180.1: return false
  if not data.trial_paid is bool or not data.trial_defeated is bool or not integer(data.trial_runes, 0, 7) or not integer(data.trial_victories) or not integer(data.research_stage, 0, 3): return false
  if data.trial_defeated and data.trial_runes != 7: return false
  next_ward = float(data.ward_until)
  next_paid = data.trial_paid
  next_runes = int(data.trial_runes)
  next_defeated = data.trial_defeated
  next_victories = int(data.trial_victories)
  next_research = int(data.research_stage)
 elif data.secret_inside:
  next_runes = 7
  next_defeated = true
  next_paid = float(data.chest_ready.get("shrine", 0)) <= world_time
 materials = materials.duplicate()
 vault = vault.duplicate()
 for item in C.MATERIALS:
  materials[item] = int(data.materials.get(item, 0))
  vault[item] = int(data.vault.get(item, 0))
 gear = data.gear.duplicate(true)
 for item in gear: item.level = int(item.get("level", 0)) if save_version >= 6 else 0
 ward_until = next_ward
 trial_paid = next_paid
 trial_runes = next_runes
 trial_defeated = next_defeated
 trial_victories = next_victories
 research_stage = next_research
 next_gear = int(data.next_gear)
 equipped = data.equipped.duplicate()
 recipes = data.recipes.duplicate()
 batches = int(data.batches)
 kills = int(data.kills)
 focus_until = float(data.focus_until)
 node_ready = data.node_ready.duplicate()
 chest_ready = data.chest_ready.duplicate()
 chest_visits = data.chest_visits.duplicate()
 discoveries = data.discoveries.duplicate()
 secret_inside = data.secret_inside
 unlock_mastery()
 return true
