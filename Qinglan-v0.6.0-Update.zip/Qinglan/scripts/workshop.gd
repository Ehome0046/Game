extends Node3D
const C = preload("res://scripts/catalog.gd")
const Icon = preload("res://scripts/item_icon.gd")
var game: Node3D
var gear_panel: PanelContainer
var recipe_panel: PanelContainer
var stats: Label
var gear_detail: Label
var bag_grid: GridContainer
var equip_slots: VBoxContainer
var gear_buttons := {}
var selected := 0
var equip_button: Button
var salvage_button: Button
var sell_button: Button
var refine_button: Button
var promote_button: Button
var recipe_list: VBoxContainer
var recipe_detail: Label
var craft_button: Button
var station := "alchemy"
var chosen := "heal"
var active := false
var elapsed := 0.0
var duration := 5.0
var active_recipe := ""
var motion_clock := 0.0
var flame: MeshInstance3D
var station_targets := {"alchemy": Vector3(-5.4, 30.7, 2.6), "forge": Vector3(5.5, 30.8, 3)}
var stations := {"alchemy": Vector3(-5.4, 30, 1.2), "forge": Vector3(5.5, 30, 1.7)}

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 build_stations()
 build_gear_panel()
 build_recipe_panel()

func build_stations() -> void:
 var v = game.valley
 var brass: Material = v.material("8c7b52")
 var at := Vector3(-5.4, 0, 2.6)
 v.box(at + Vector3.UP * 0.25, Vector3(1.5, 0.5, 1.4), v.stone, true, game.room)
 v.cylinder(at + Vector3.UP * 0.9, 0.52, 0.44, 0.85, brass, game.room)
 v.cylinder(at + Vector3.UP * 1.4, 0.13, 0.64, 0.22, brass, game.room)
 for x in [-0.65, 0.65]:
  v.box(at + Vector3(x, 1.0, 0), Vector3(0.2, 0.45, 0.22), brass, false, game.room)
 flame = v.cylinder(at + Vector3(0, 0.6, 0.5), 0.06, 0.16, 0.5, v.material("d78e4b", true), game.room)
 v.box(Vector3(5.5, 0.75, 3), Vector3(2.3, 0.18, 1.4), v.wood, true, game.room)
 for x in [4.6, 6.4]: v.box(Vector3(x, 0.35, 3), Vector3(0.2, 0.7, 1.1), v.wood, false, game.room)
 v.box(Vector3(5.5, 1.1, 3), Vector3(0.9, 0.6, 0.55), v.material("5f7476"), false, game.room)
 v.box(Vector3(6.2, 0.92, 2.8), Vector3(0.12, 0.12, 0.85), brass, false, game.room).rotation.y = 0.6
 game.room.point("alchemy", Vector3(-5.4, 0, 1.2), "丹炉 · 炼制药品")
 game.room.point("forge", Vector3(5.5, 0, 1.7), "炼器案 · 制作飞剑")
 game.room.sign_at("丹 炉 · E", at + Vector3.UP * 2.2)
 game.room.sign_at("炼 器 · E", Vector3(5.5, 2, 3))

func opaque(panel: PanelContainer) -> void:
 var style: StyleBoxFlat = panel.get_theme_stylebox("panel").duplicate()
 style.bg_color = Color("13231f")
 panel.add_theme_stylebox_override("panel", style)

func build_gear_panel() -> void:
 gear_panel = game.panel(Vector2(90, 35), Vector2(1100, 640))
 opaque(gear_panel)
 var column := VBoxContainer.new()
 column.add_theme_constant_override("separation", 12)
 gear_panel.add_child(column)
 column.add_child(game.label("行 装 · 飞 剑 / 法 衣 / 护 符", 27, Color("dfc997")))
 var row := HBoxContainer.new()
 row.add_theme_constant_override("separation", 24)
 column.add_child(row)
 var left := VBoxContainer.new()
 left.custom_minimum_size.x = 310
 row.add_child(left)
 stats = game.label("", 17)
 left.add_child(stats)
 equip_slots = VBoxContainer.new()
 equip_slots.add_theme_constant_override("separation", 10)
 left.add_child(equip_slots)
 var right := VBoxContainer.new()
 right.custom_minimum_size.x = 690
 row.add_child(right)
 right.add_child(game.label("随身装备 · 点击查看；穿戴不额外占一份物品", 16))
 var scroll := ScrollContainer.new()
 scroll.custom_minimum_size = Vector2(690, 268)
 right.add_child(scroll)
 bag_grid = GridContainer.new()
 bag_grid.columns = 2
 bag_grid.add_theme_constant_override("h_separation", 8)
 bag_grid.add_theme_constant_override("v_separation", 8)
 scroll.add_child(bag_grid)
 gear_detail = game.label("", 16)
 gear_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 gear_detail.custom_minimum_size = Vector2(1000, 120)
 column.add_child(gear_detail)
 var actions := HBoxContainer.new()
 actions.add_theme_constant_override("separation", 12)
 column.add_child(actions)
 equip_button = game.button("穿戴 / 卸下", equip_selected, actions)
 refine_button = game.button("温养 +1", refine_selected, actions)
 promote_button = game.button("提升品质", promote_selected, actions)
 salvage_button = game.button("分解", salvage_selected, actions)
 sell_button = game.button("卖给陆舟", sell_selected, actions)
 for button in [equip_button, refine_button, promote_button, salvage_button, sell_button]: button.custom_minimum_size.x = 156
 game.button("返回 · B / Esc", func(): game.set_paused(false), actions).custom_minimum_size.x = 156
 column.add_child(game.label("陆舟身边可以出售装备；分解回收灵铁。背包最多 60 件，装满时地面装备会保留。", 15))
 gear_panel.hide()

func build_recipe_panel() -> void:
 recipe_panel = game.panel(Vector2(205, 28), Vector2(870, 660))
 opaque(recipe_panel)
 var column := VBoxContainer.new()
 column.add_theme_constant_override("separation", 14)
 recipe_panel.add_child(column)
 column.add_child(game.label("洞 府 工 坊 · 丹 方 与 制 作", 27, Color("dfc997")))
 var scroll := ScrollContainer.new()
 scroll.custom_minimum_size = Vector2(790, 185)
 column.add_child(scroll)
 recipe_list = VBoxContainer.new()
 recipe_list.custom_minimum_size.x = 775
 recipe_list.add_theme_constant_override("separation", 8)
 scroll.add_child(recipe_list)
 recipe_detail = game.label("", 18)
 recipe_detail.custom_minimum_size = Vector2(790, 140)
 recipe_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 column.add_child(recipe_detail)
 craft_button = game.button("开始炼制", start_chosen, column)
 game.button("返回房间", func(): game.set_paused(false), column)
 recipe_panel.hide()

func hide_panels() -> void:
 gear_panel.hide()
 recipe_panel.hide()

func clear_children(node: Node) -> void:
 for child in node.get_children():
  node.remove_child(child)
  child.queue_free()

func open_gear() -> void:
 if active:
  game.notify("正在炼制，先按 E 取消或等待完成。")
  return
 game.set_paused(true)
 game.pause_panel.hide()
 gear_panel.show()
 render_gear()

func render_gear() -> void:
 var p = game.progress
 var state = p.expansion
 var bonus: Dictionary = state.bonuses()
 stats.text = "生命上限 %d · 灵力上限 %d\n装备伤害 +%d · 护甲 %d\n飞剑淬炼 +%d · 装备 %d / 60\n\n当前穿戴" % [p.max_hp(), p.max_qi(), bonus.attack, bonus.armor, p.weapon_level, state.gear.size()]
 clear_children(equip_slots)
 for slot in C.SLOTS:
  var item: Dictionary = state.find_gear(int(state.equipped[slot]))
  var title: String = C.GEAR[item.id].name if not item.is_empty() else "未穿戴"
  var button: Button = game.button(C.SLOT_NAMES[slot] + " · " + title, select_gear.bind(int(state.equipped[slot])), equip_slots)
  button.disabled = item.is_empty()
 clear_children(bag_grid)
 gear_buttons.clear()
 if state.find_gear(selected).is_empty(): selected = int(state.gear[0].uid) if not state.gear.is_empty() else 0
 for item in state.gear:
  var data: Dictionary = C.GEAR[item.id]
  var worn: bool = int(state.equipped[data.slot]) == int(item.uid)
  var title: String = ("◆ " if selected == int(item.uid) else "") + data.name + " +%d" % int(item.level) + " · " + C.QUALITY[data.quality] + (" [已装备]" if worn else "")
  var button: Button = game.button(title, select_gear.bind(int(item.uid)), bag_grid)
  button.custom_minimum_size = Vector2(330, 52)
  button.add_theme_color_override("font_color", Color(C.COLORS[data.quality]))
  gear_buttons[int(item.uid)] = button
 var item: Dictionary = state.find_gear(selected)
 var available := not item.is_empty()
 equip_button.disabled = not available
 salvage_button.disabled = not available or (available and int(state.equipped[C.GEAR[item.id].slot]) == selected)
 refine_button.tooltip_text = "每级提升主属性，最多五级：飞剑伤害 +2；衣服生命 +4；护符灵力 +5。"
 promote_button.tooltip_text = "提升一个品质，保留当前温养等级。"
 refine_button.disabled = not available or not at_refiner() or not state.can_pay(state.refine_cost(selected), p)
 promote_button.disabled = not available or not at_refiner() or not state.can_pay(state.promote_cost(selected), p)
 sell_button.disabled = not available or not near_trader() or (available and int(state.equipped[C.GEAR[item.id].slot]) == selected)
 if available:
  var data: Dictionary = C.GEAR[item.id]
  var bonus_stats: Dictionary = state.gear_stats(item)
  gear_detail.text = "%s · %s · 温养 +%d / 5\n伤害 +%d  生命 +%d  灵力 +%d  护甲 +%d" % [data.name, C.QUALITY[data.quality], item.level, bonus_stats.attack, bonus_stats.hp, bonus_stats.qi, bonus_stats.armor]
  gear_detail.text += "\n温养：%s；升品：%s" % [cost_text(state.refine_cost(selected)), cost_text(state.promote_cost(selected))]
  gear_detail.text += "\n分解得 %d 灵铁 · 售价 %d 金币 · 温养 / 升品需在炼器案或陆舟身旁。" % [1 + int(data.quality), data.price]
  if selection_is_worn(): gear_detail.text += "\n先卸下该装备，才能分解或出售。"
 else: gear_detail.text = "还没有装备。猎妖后 E 拾取战利品；矿洞和秘境宝箱也有装备，矿洞图谱可解锁制作。"

func cost_text(cost: Dictionary) -> String:
 if cost.is_empty(): return "已到上限"
 var parts: Array[String] = []
 for item in cost: parts.append("%d%s" % [cost[item], C.NAMES[item]])
 return " + ".join(parts)

func at_refiner() -> bool:
 return near_trader() or (game.progress.inside_home and game.traveler.position.distance_to(stations.forge)<2.7)

func refine_selected() -> void:
 if not gear_panel.visible or not game.paused or not at_refiner(): return
 if game.progress.expansion.refine(selected, game.progress):
  game.apply_equipment()
  game.traveler.play_interaction("craft", game.traveler.position)
  game.save_game(false)
 render_gear()

func promote_selected() -> void:
 if not gear_panel.visible or not game.paused or not at_refiner(): return
 if game.progress.expansion.promote(selected, game.progress):
  game.apply_equipment()
  game.traveler.play_interaction("craft", game.traveler.position)
  game.save_game(false)
 render_gear()

func select_gear(uid: int) -> void:
 selected = uid
 render_gear()

func near_trader() -> bool:
 return not game.progress.inside_home and game.traveler.position.distance_to(Vector3(7, 0, 28)) < 3.2

func equip_selected() -> void:
 if not gear_panel.visible or not game.paused: return
 if game.progress.expansion.equip(selected, game.progress):
  game.apply_equipment()
  game.traveler.play_interaction("equip", game.traveler.position)
  game.save_game(false)
  render_gear()

func selection_is_worn() -> bool:
 var item: Dictionary = game.progress.expansion.find_gear(selected)
 return not item.is_empty() and int(game.progress.expansion.equipped[C.GEAR[item.id].slot]) == selected

func salvage_selected() -> void:
 if not gear_panel.visible or not game.paused: return
 if selection_is_worn(): return
 if game.progress.expansion.remove(selected, game.progress):
  game.apply_equipment()
  game.save_game(false)
  render_gear()

func sell_selected() -> void:
 if not gear_panel.visible or not game.paused or not near_trader(): return
 if selection_is_worn(): return
 if game.progress.expansion.remove(selected, game.progress, true):
  game.apply_equipment()
  game.save_game(false)
  render_gear()

func near_station() -> bool:
 return game.progress.inside_home and game.traveler.position.distance_to(stations[station]) < 2.7

func open_recipe(kind: String) -> void:
 if active or kind not in stations: return
 station = kind
 if not near_station(): return
 chosen = "iron_blade" if station == "forge" else "heal"
 game.set_paused(true)
 game.pause_panel.hide()
 recipe_panel.show()
 render_recipe()

func select_recipe(id: String) -> void:
 chosen = id
 render_recipe()

func render_recipe() -> void:
 clear_children(recipe_list)
 var p = game.progress
 for id in C.RECIPES:
  if C.RECIPES[id].station != station: continue
  var known: bool = id in p.expansion.recipes
  game.button(("◆ " if id == chosen else "") + C.RECIPES[id].name + ("" if known else " [未获得配方]"), select_recipe.bind(id), recipe_list)
 var recipe: Dictionary = C.RECIPES[chosen]
 var owned: Array[String] = []
 for item in recipe.cost: owned.append("%s %d" % [C.NAMES[item], p.item_count(item)])
 recipe_detail.text = "材料：" + C.recipe_cost(chosen) + "\n随身：" + " · ".join(owned) + "\n过程：%d 秒，完成时结算；E 或移动取消，不扣材料。" % recipe.seconds
 recipe_detail.text += "\n制作熟练 %d 批 · 三批解锁凝元丹。" % p.expansion.batches
 if chosen not in p.expansion.recipes:
  recipe_detail.text += {"iron_blade":"\n图谱藏在青石矿洞宝箱。", "focus":"\n丹方藏在望月秘境宝箱。", "ward":"\n击败望月守卫后领悟护元丹方。", "elixir":"\n完成三次制作后，自动领悟凝元丹方。"}.get(chosen, "")
 elif chosen == "ward": recipe_detail.text += "\n7 使用：游玩 180 秒护甲 +3，已有药效时不消耗。"
 elif chosen == "elixir": recipe_detail.text += "\n8 使用：生命与灵力全恢复；全满时不消耗。"
 elif chosen == "focus": recipe_detail.text += "\n聚气丹：按 6 使用，游玩 120 秒内伤害 +8，已有药效时不消耗。"
 craft_button.disabled = not p.expansion.can_craft(chosen, p)
 craft_button.text = "开始制作" if station == "forge" else "开始炼丹"

func start_chosen() -> void:
 if not recipe_panel.visible or not game.paused or not near_station() or not game.progress.expansion.can_craft(chosen, game.progress): return
 game.set_paused(false)
 game.room.stop_rest()
 active_recipe = chosen
 duration = C.RECIPES[chosen].seconds
 elapsed = 0
 active = true
 motion_clock = 0
 game.traveler.busy = true
 game.traveler.invincible = 0
 game.traveler.play_interaction("craft", station_targets[station])
 game.notify("开始%s，完成后结算材料；E 或移动取消。" % C.RECIPES[chosen].name)

func cancel(feedback := true) -> void:
 active = false
 game.traveler.busy = false
 flame.scale = Vector3.ONE
 if feedback: game.notify("炼制已取消，材料保留。")

func _process(delta: float) -> void:
 if not active or not game.playing or game.paused: return
 if not near_station() or Input.get_vector("left", "right", "forward", "back").length_squared() > 0.1:
  cancel()
  return
 elapsed += delta
 motion_clock -= delta
 flame.scale.y = 1.0 + sin(elapsed * 7) * 0.18
 if motion_clock <= 0:
  motion_clock = 0.8
  game.traveler.play_interaction("craft", station_targets[station])
  game.effects.ring(station_targets[station] + Vector3.UP * 0.4, Color("dab881"), 0.35)
 if elapsed >= duration:
  active = false
  game.traveler.busy = false
  flame.scale = Vector3.ONE
  if game.progress.expansion.craft(active_recipe, game.progress):
   game.notify("制作完成：" + C.RECIPES[active_recipe].name + "。成品已收入背包，可自用或到坊市出售。")
   game.apply_equipment()
   game.save_game(false)
  else: game.notify("材料或背包空间不足，未扣除材料。")
