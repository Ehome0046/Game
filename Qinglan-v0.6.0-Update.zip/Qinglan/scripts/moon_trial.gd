extends Node3D
## A repeatable shrine encounter with saved seals and a non-respawning victory.
const ORIGIN := Vector3(0, 0, -73)
const SEALS := [Vector3(-6, 0, -73.5), Vector3(6, 0, -73.5), Vector3(-5.5, 0, -68.5)]
const MAX_HP := 300.0
var game: Node3D
var body: CharacterBody3D
var model: Node3D
var arms: Array[Node3D] = []
var health_label: Label3D
var warning: MeshInstance3D
var seals: Array[MeshInstance3D] = []
var hp := MAX_HP
var windup := -1.0
var cooldown := 1.8
var heavy := false
var mark := ORIGIN
var awake := false
var seal_materials: Array[Material] = []

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_PAUSABLE
 var v = game.valley
 seal_materials = [v.material("537b7a"), v.material("bad8c2", true)]
 for i in range(SEALS.size()):
  v.cylinder(SEALS[i] + Vector3.UP * 0.4, 0.5, 0.65, 0.8, v.stone, self)
  var title: Label3D = v.sign_text("望月阵石 %d · E" % (i+1), SEALS[i]+Vector3.UP*1.7, 22)
  title.reparent(self,false)
  seals.append(v.cylinder(SEALS[i] + Vector3.UP * 0.86, 0.23, 0.23, 0.1, v.material("537b7a"), self))
  game.valley.interactions.append({"kind":"trial_seal", "id":i, "position":SEALS[i], "label":"唤醒望月阵石 %d / 3" % (i+1)})
 body = CharacterBody3D.new()
 body.collision_layer = 0
 body.collision_mask = 1
 add_child(body)
 body.position = ORIGIN
 var shape := CollisionShape3D.new()
 var capsule := CapsuleShape3D.new()
 capsule.radius = 0.5
 capsule.height = 2.2
 shape.shape = capsule
 shape.position.y = 1.1
 body.add_child(shape)
 model = Node3D.new()
 body.add_child(model)
 var armor: Material = v.material("5d8185")
 v.box(Vector3(0,1.2,0),Vector3(1.3,1.4,0.8),armor,false,model)
 v.box(Vector3(0,2.2,0),Vector3(0.65,0.6,0.65),armor,false,model)
 v.box(Vector3(0,2.25,-0.35),Vector3(0.4,0.09,0.05),v.material("d0d9b8",true),false,model)
 v.box(Vector3(0,1.3,-0.44),Vector3(0.35,0.55,0.08),v.material("a3c7bf",true),false,model)
 for side in [-1.0,1.0]:
  var arm := Node3D.new()
  model.add_child(arm)
  arm.position = Vector3(side*0.83,1.8,0)
  v.box(Vector3(0,-0.5,0),Vector3(0.42,1.2,0.5),armor,false,arm)
  arms.append(arm)
  v.box(Vector3(side*0.36,0.35,0),Vector3(0.4,0.7,0.5),armor,false,model)
 var ring := TorusMesh.new()
 ring.inner_radius = 0.85
 ring.outer_radius = 0.92
 var crest: MeshInstance3D = v.mesh_at(ring,Vector3(0,2.4,0.4),v.material("a6c7bf",true),model)
 crest.rotation.x = PI/2
 var warning_ring := TorusMesh.new()
 warning_ring.inner_radius = 2.8
 warning_ring.outer_radius = 2.95
 warning = v.mesh_at(warning_ring,ORIGIN+Vector3.UP*0.14,v.material("d5a86b",true),self)
 warning.hide()
 health_label = v.sign_text("望月守卫", ORIGIN + Vector3.UP*3.2,28)
 health_label.reparent(self,false)
 reset()

func active() -> bool:
 var p = game.progress
 return not p.inside_home and p.expansion.secret_inside and p.expansion.trial_paid and p.expansion.trial_runes == 7 and not p.expansion.trial_defeated

func seal_count() -> int:
 var value: int = game.progress.expansion.trial_runes
 return int(bool(value & 1)) + int(bool(value & 2)) + int(bool(value & 4))

func reset() -> void:
 hp = MAX_HP
 windup = -1
 cooldown = 1.8
 awake = false
 if not is_instance_valid(body): return
 body.position = ORIGIN
 body.velocity = Vector3.ZERO
 warning.hide()
 sync()

func sync() -> void:
 var p = game.progress
 var in_shrine: bool = p.expansion.secret_inside and not p.inside_home
 for i in range(seals.size()):
  seals[i].material_override = seal_materials[1 if p.expansion.trial_runes & (1<<i) else 0]
 visible = in_shrine
 body.visible = in_shrine and not p.expansion.trial_defeated
 body.collision_layer = 2 if active() else 0
 health_label.visible = body.visible
 if body.visible:
  health_label.text = ("望月守卫 %d / 300" % hp) if active() else "望月守卫 · 阵石 %d / 3" % seal_count()
 if not active(): warning.hide()

func activate_seal(index: int) -> bool:
 var p = game.progress
 if not p.expansion.secret_inside or not p.expansion.trial_paid or index<0 or index>=3 or game.traveler.position.distance_to(SEALS[index])>=2.7: return false
 if p.expansion.trial_runes & (1<<index):
  game.notify("这块阵石已经唤醒。")
  return false
 p.expansion.trial_runes |= 1<<index
 game.effects.ring(SEALS[index]+Vector3.UP,Color("a9d7c7"),0.7)
 game.notify("三石共鸣，望月守卫苏醒。注意地面预警！" if p.expansion.trial_runes==7 else "阵石已唤醒：%d / 3。" % seal_count())
 sync()
 return true

func hit(damage: float) -> void:
 if not active() or damage<=0: return
 hp = maxf(0,hp-damage)
 if hp<=0:
  var state = game.progress.expansion
  state.trial_defeated = true
  state.trial_victories += 1
  if "ward" not in state.recipes: state.recipes.append("ward")
  game.frontier.drop(body.position,[{"item":"moonshard","count":2}])
  game.notify("望月守卫已败！拾取月华晶，再开宝箱。护元丹方已领悟，可回炉制作。")
  sync()
  game.save_game(false)

func _physics_process(delta: float) -> void:
 if not game.playing or game.paused: return
 if not active():
  if awake:
   awake = false
   hp = MAX_HP
   windup = -1
   body.position = ORIGIN
   body.velocity = Vector3.ZERO
  sync()
  return
 awake = true
 cooldown -= delta
 var offset: Vector3 = game.traveler.position-body.position
 offset.y = 0
 body.velocity = Vector3(0,-8,0)
 if windup>=0:
  windup -= delta
  var pose := sin((1.0-maxf(windup,0)/1.0)*PI/2)
  for arm in arms: arm.rotation.x = -pose*1.8
  if windup<0:
   warning.hide()
   var distance: float = game.traveler.position.distance_to(mark if heavy else body.position)
   if distance < (3.0 if heavy else 2.7): game.take_damage(30 if heavy else 22)
   game.effects.ring((mark if heavy else body.position)+Vector3.UP*0.15,Color("b8d5ce"),1.8)
 elif cooldown<=0 and offset.length()<4.8:
  heavy = hp<MAX_HP/2
  windup = 1.0
  cooldown = 2.8 if heavy else 2.2
  mark = game.traveler.position if heavy else body.position
  warning.position = Vector3(mark.x,0.15,mark.z)
  warning.show()
 elif offset.length()>1.9:
  body.velocity += offset.normalized()*1.65
 for arm in arms:
  if windup<0: arm.rotation.x = move_toward(arm.rotation.x,0,delta*5)
 body.move_and_slide()
 body.position.x = clampf(body.position.x,-7.5,7.5)
 body.position.z = clampf(body.position.z,-77,-67.5)
 if offset.length_squared()>0.01: body.rotation.y = atan2(-offset.x,-offset.z)
 health_label.position = body.position + Vector3.UP*3.2
 health_label.text = ("月华震荡 · 躲开金圈" if heavy else "石掌蓄力 · 空格闪避") if windup>=0 else "望月守卫 %d / 300" % hp
