shader_type spatial;
render_mode diffuse_burley;
varying vec3 at;
void vertex() { at = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
 float ripple = sin(at.x * 5.0 + at.z * 2.0 - TIME * 1.1) * sin(at.z * 8.0 + TIME * 1.6);
 float glint = pow(max(0.0, ripple), 8.0);
 ALBEDO = mix(vec3(0.12, 0.28, 0.27), vec3(0.35, 0.51, 0.46), ripple * 0.25 + 0.35) + glint * 0.13;
 ROUGHNESS = 0.28;
 METALLIC = 0.22;
 NORMAL_MAP = vec3(0.5 + ripple * 0.08, 0.5 + sin(at.z * 7.0 - TIME) * 0.05, 1.0);
}
