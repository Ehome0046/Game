shader_type spatial;
render_mode cull_disabled;
void vertex() { VERTEX.x += sin(TIME * 1.2 + MODEL_MATRIX[3].x * 0.6 + MODEL_MATRIX[3].z) * VERTEX.y * 0.08; }
void fragment() { ALBEDO = mix(vec3(0.15, 0.25, 0.15), vec3(0.37, 0.44, 0.25), clamp(UV.y, 0.0, 1.0)); ROUGHNESS = 0.95; }
