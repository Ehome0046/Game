#!/usr/bin/env python3
"""Build a portable project ZIP without saves, caches, Git metadata or test data."""
from pathlib import Path
import argparse
import re
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("--with-engine", action="store_true")
parser.add_argument("--update-only", action="store_true", help="Overlay files for an existing portable installation")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
destination = root / "dist"
destination.mkdir(exist_ok=True)
if args.with_engine and args.update_only:
    parser.error("--with-engine and --update-only are mutually exclusive")
suffix = "Windows-Portable" if args.with_engine else ("Update" if args.update_only else "Source")
version = re.search(r'^config/version="([0-9.]+)"$', (root / "project.godot").read_text(encoding="utf-8"), re.MULTILINE)
if not version:
    raise SystemExit("Missing application version in project.godot")
version = version.group(1)
output = destination / f"Qinglan-v{version}-{suffix}.zip"
files = [root / name for name in ["README.md", ".gitignore", "Start-Game.cmd", "project.godot"]]
for folder in ["docs", "scenes", "scripts", "shaders", "tests", "third_party"]:
    files.extend(p for p in (root / folder).rglob("*") if p.is_file())
files.extend([root / "tools/check.py", root / "tools/check_window_input.py", root / "tools/package.py"])
if args.with_engine:
    engine = root / "tools/godot/Godot.exe"
    if not engine.is_file():
        raise SystemExit("Missing tools/godot/Godot.exe; see Windows quickstart")
    for license_name in ["LICENSE.txt", "COPYRIGHT.txt", "ORIGIN.md"]:
        if not (root / "third_party/godot" / license_name).is_file():
            raise SystemExit("Missing Godot license/provenance: " + license_name)
    files.extend([engine, root / "tools/godot/_sc_"])
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        content = path.read_bytes()
        if path.suffix == ".cmd":
            content = content.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        archive.writestr("Qinglan/" + path.relative_to(root).as_posix(), content)
    engine_note = ("便携包已附带 Godot 引擎，无需安装。" if args.with_engine else
                   ("这是小更新包，请覆盖原有 Qinglan 文件夹，保留 tools\\godot 和 .local。" if args.update_only else
                    "此为源码包，先按 docs\\windows-quickstart.md 准备便携 Godot 引擎。"))
    archive.writestr("Qinglan/开始前必读.txt", f"""青岚问道 v{version} · 山行与修行（玩法原型）

1. 将整个 Qinglan 文件夹解压到 D:\\GameDev 下，不要放到 C 盘。
2. {engine_note} 双击 Start-Game.cmd 启动。
3. 继续旧存档。U 修行，静心台 / 室内蒲团旁可突破二、三层；选剑修或法修、研习功法。B 图标换装、属性对比、一键推荐。
4. 野外宝箱 E 开格子，上格取物、下格存材料，Shift 整叠，可全部取出；未取物品随存档保留。室内 P 仍可自由布置。
5. 洞府门口 E 入室，丹炉 E 炼丹、炼器案 E 制作。完成才扣材料，E 或移动取消；门口 E 出门。
6. 4 养元丹、5 回灵散、6 聚气丹、7 护元丹、8 凝元丹。完成三批制作解锁凝元丹，击败守卫解锁护元丹。
7. 鼠标即时转镜头，右移向右转，上移抬头；右键恢复锁定，滚轮缩放。F8 切兼容模式，F10 释放指针。
8. 北面残卷 E 学御剑；Q/1 普通御剑，按住左键蓄力、松开发射；R/2 火弹、F/3 护体、空格翻滚、F5 保存。及时护体可格挡并反击。
9. 这是采用简单占位模型的玩法原型，不是最终写实画面。Windows 本机尚待实测。

鼠标进不去时先 Alt+Tab 选中游戏，点一下画面或右键；F8 切换兼容方式，Esc 继续。暂停页可保存并退出。
村南顾伯接重复委托和三段研习奖励；沈娘卖药与收药，陆舟收装备 / 灵铁并强化。WASD 移动。草药 45 秒、矿石 90 秒、宝箱 180 秒恢复，暂停与离线不计时。
安家：M 地图、N 洞府引路；村口南侧绕过房屋，向西过桥到无主石室门前按 E。无需先通关遗府。
山坡有真实高差，东部石径可登高。J 查看宗门剧情，村东林照 E 交谈。\n认领后 H 脱战回府，箱子 E 储物、蒲团 E 调息/G 修炼；灵田 E 播种或收获。B 装备，T 药谷 / 矿洞 / 秘境指引，M 区域总览。
切换窗口时自动暂停，回来后点击继续修行。Tab/Esc 行囊与暂停。

存档：.local\\saves。请不要误删；创建新角色前会询问是否覆盖。
旧存档会自动迁移，原 v1～v7 文件分别保留对应备份；v7 为 journey.json.v7.bak。
本次地形、动作、修行与装备：docs\\update-0.8.md；此前宗门、妖兽与布置：docs\\update-0.7.md；此前温养、试炼与研习：docs\\update-0.6.md；此前装备、丹器与探索：docs\\update-0.5.md；洞府与鼠标恢复：docs\\update-0.4.md；循环玩法：docs\\update-0.3.md；洞府指引：docs\\update-0.2.2.md；遗府洞府：docs\\update-0.2.md。
""".encode("utf-8-sig"))
    if not archive.testzip() is None:
        raise SystemExit("ZIP CRC check failed")
with zipfile.ZipFile(output) as archive:
    names = archive.namelist()
    if any("/.local/" in n or "/.git/" in n or "/.godot/" in n for n in names):
        raise SystemExit("Unexpected private data or cache in artifact")
    print(f"{output}: {output.stat().st_size / 1024**2:.1f} MiB, {len(names)} files")
