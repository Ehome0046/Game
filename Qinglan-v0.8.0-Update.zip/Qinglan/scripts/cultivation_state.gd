extends RefCounted
const C=preload("res://scripts/catalog.gd")
const E=preload("res://scripts/expansion_state.gd")
var insight:=0
var path:=""
var ranks:={"sword":0,"fire":0,"shield":0}
var chests:={}
func snapshot() -> Dictionary:
 return {"insight":insight,"path":path,"ranks":ranks.duplicate(),"chests":chests.duplicate(true)}
func restore(data: Variant,realm: int) -> bool:
 if not data is Dictionary or not E.integer(data.get("insight"),0,100000) or data.get("path") not in ["","sword","spell"]:return false
 if not data.get("ranks") is Dictionary or data.ranks.size()!=3 or not data.get("chests") is Dictionary or data.chests.size()>3:return false
 for key in ranks:
  if not E.integer(data.ranks.get(key),0,mini(3,realm)):return false
 for key in data.chests:
  if not C.CHESTS.has(key) or not data.chests[key] is Array or data.chests[key].size()>18:return false
  var types:=[]
  for item in data.chests[key]:
   if not item is Dictionary or not E.integer(item.get("count"),1,100000):return false
   if item.get("item")=="gear":
    if not C.GEAR.has(item.get("gear_id")) or item.count!=1:return false
   elif not C.NAMES.has(item.get("item")) or item.item in types:return false
   types.append(item.item)
 insight=int(data.insight);path=data.path;ranks=data.ranks.duplicate();chests=data.chests.duplicate(true)
 for key in ranks:ranks[key]=int(ranks[key])
 for key in chests:
  for item in chests[key]:item.count=int(item.count)
 return true
func gain(amount: int) -> void:
 insight=clampi(insight+maxi(0,amount),0,100000)
func upgrade(kind: String,p: RefCounted) -> bool:
 if not ranks.has(kind) or p.realm<1 or ranks[kind]>=p.realm or ranks[kind]>=3 or (kind=="fire" and not p.relic):return false
 var price: int=25+int(ranks[kind])*25
 if insight<price:return false
 insight-=price;ranks[kind]+=1;return true
func breakthrough_cost(realm: int) -> Dictionary:
 if realm==1:return {"insight":100,"herb":6,"core":3}
 if realm==2:return {"insight":240,"ore":6,"core":6}
 return {}
func ascend(p: RefCounted) -> bool:
 var cost:=breakthrough_cost(p.realm)
 if cost.is_empty() or not p.learned or p.expansion.gear.size()>=p.expansion.MAX_GEAR or (p.realm==2 and not p.relic):return false
 for item in cost:
  if (insight if item=="insight" else p.item_count(item))<cost[item]:return false
 for item in cost:
  if item=="insight":insight-=cost[item]
  else:p.add_item(item,-cost[item])
 p.realm+=1
 p.expansion.add_gear(("moon_charm" if path=="spell" else "jade_blade") if p.realm==2 else "cloud_robe")
 p.hp=p.max_hp();p.qi=p.max_qi()
 return true
func realm_name(realm: int) -> String:
 return ["凡人","炼气一层","炼气二层","炼气三层"][clampi(realm,0,3)]
func attack_bonus(kind: String) -> float:
 return int(ranks.get(kind,0))*(3 if kind=="sword" else 5)+(6 if path=="sword" and kind=="sword" else (8 if path=="spell" and kind=="fire" else 0))
