extends Control
const Icon=preload("res://scripts/item_icon.gd")
var game: Node3D
var card: PanelContainer
var title: Label
var detail: Label
var icon: Control
var flash: ColorRect
var left:=0.0
var hurt:=0.0
var audio_player: AudioStreamPlayer
var cues:={}
func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS;mouse_filter=Control.MOUSE_FILTER_IGNORE;set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 flash=ColorRect.new();flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);flash.color=Color(0.7,0.12,0.08,0);flash.mouse_filter=Control.MOUSE_FILTER_IGNORE;add_child(flash)
 card=game.panel(Vector2(455,164),Vector2(370,91));card.mouse_filter=Control.MOUSE_FILTER_IGNORE
 var row:=HBoxContainer.new();row.add_theme_constant_override("separation",14);card.add_child(row)
 icon=Icon.new();icon.custom_minimum_size=Vector2(46,46);row.add_child(icon)
 var col:=VBoxContainer.new();row.add_child(col)
 title=game.label("",20,Color("e7d19b"));col.add_child(title)
 detail=game.label("",15);detail.custom_minimum_size.x=240;detail.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;col.add_child(detail);card.hide()
 audio_player=AudioStreamPlayer.new();audio_player.volume_db=-15;add_child(audio_player)
 for pair in [["hit",180],["gain",620],["open",360]]:
  var stream:=AudioStreamWAV.new();stream.format=AudioStreamWAV.FORMAT_16_BITS;stream.mix_rate=22050
  var bytes:=PackedByteArray();bytes.resize(4410)
  for i in range(2205):bytes.encode_s16(i*2,int(sin(TAU*float(pair[1])*i/22050)*pow(1-i/2205.0,2)*13000))
  stream.data=bytes;cues[pair[0]]=stream
func show_event(text: String,description: String,item: String="core",sound: String="gain") -> void:
 title.text=text;detail.text=description;icon.item=item;icon.queue_redraw();left=2.5;card.visible=not game.paused
 play_cue(sound)
func play_cue(sound: String) -> void:
 if not game.test_mode and audio_player and cues.has(sound):audio_player.stream=cues[sound];audio_player.play()
func hit(damage: float) -> void:
 hurt=0.24;game.traveler.play_hurt()
 show_event("受到伤害 −%d"%roundi(damage),"生命 %d / %d · 空格闪避 / F 护体"%[game.progress.hp,game.progress.max_hp()],"heal","hit")
func reset() -> void:
 left=0;hurt=0;card.hide();flash.color.a=0
 if audio_player:audio_player.stop()
func _process(delta: float) -> void:
 left=maxf(0,left-delta);hurt=maxf(0,hurt-delta)
 card.visible=game.playing and left>0 and not game.paused
 flash.color.a=0.13*hurt/0.24 if game.playing and not game.paused else 0.0
func _exit_tree() -> void:
 if audio_player:audio_player.stop();audio_player.stream=null
