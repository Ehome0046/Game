extends Node
const C=preload("res://scripts/catalog.gd")
const Icon=preload("res://scripts/item_icon.gd")
var game: Node3D
var popup: PanelContainer
var slots: Array[Button]=[]
var bag: Array[Button]=[]
var heading: Label
var status: Label
var current:=""
var lid_tween: Tween
func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 popup=game.panel(Vector2(255,35),Vector2(770,650))
 var col:=VBoxContainer.new();col.add_theme_constant_override("separation",8);popup.add_child(col)
 heading=game.label("野外宝箱",26,Color("dfc997"));col.add_child(heading)
 col.add_child(game.label("点击上格取物，下格存入 · Shift 整叠 · 装备取出后 B 换装",16))
 slots=grid(col,true);col.add_child(game.label("随身材料与补给",18));bag=grid(col,false)
 status=game.label("",16);status.custom_minimum_size.x=700;status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;col.add_child(status)
 var row:=HBoxContainer.new();row.add_theme_constant_override("separation",12);col.add_child(row)
 game.button("全部取出",take_all,row);game.button("关上箱子 · Esc",func():game.set_paused(false),row);popup.hide()
func grid(parent: Node,chest: bool) -> Array[Button]:
 var panel:=GridContainer.new();panel.columns=9;panel.add_theme_constant_override("h_separation",8);panel.add_theme_constant_override("v_separation",8);parent.add_child(panel)
 var result: Array[Button]=[]
 for i in range(18):
  var button:=Button.new();button.custom_minimum_size=Vector2(65,65);panel.add_child(button)
  var style:=StyleBoxFlat.new();style.bg_color=Color("1f342e");style.border_color=Color("647468");style.set_border_width_all(2);style.set_corner_radius_all(3)
  button.add_theme_stylebox_override("normal",style);button.add_theme_stylebox_override("disabled",style)
  var hover: StyleBoxFlat=style.duplicate();hover.bg_color=Color("3b5143");hover.border_color=Color("d9bc81");button.add_theme_stylebox_override("hover",hover)
  var image:=Icon.new();image.position=Vector2(11,3);image.size=Vector2(42,42);button.add_child(image)
  var count: Label=game.label("",14);count.position=Vector2(3,44);count.size.x=58;count.horizontal_alignment=HORIZONTAL_ALIGNMENT_RIGHT;count.mouse_filter=Control.MOUSE_FILTER_IGNORE;button.add_child(count)
  button.pressed.connect(take.bind(i) if chest else deposit.bind(i));result.append(button)
 return result
func accessible() -> bool:
 return popup.visible and game.paused and C.CHESTS.has(current) and game.traveler.position.distance_to(C.CHESTS[current]+Vector3(0,0,0.85))<2.7
func generate_contents(id: String) -> Array:
 var p=game.progress
 var first: bool=int(p.expansion.chest_visits.get(id,0))==0
 var items: Array=[]
 if id=="grove":
  items=[{"item":"redflower","count":2},{"item":"dew","count":2},{"item":"coins","count":10}]
  if first:items.append({"item":"gear","gear_id":"linen_robe","count":1})
 elif id=="mine":
  items=[{"item":"ore","count":4},{"item":"coins","count":15}]
  if first:items.append({"item":"gear","gear_id":"iron_blade","count":1})
  if "iron_blade" not in p.expansion.recipes:p.expansion.recipes.append("iron_blade")
 else:
  p.expansion.trial_paid=false
  items=[{"item":"core","count":1},{"item":"dew","count":2},{"item":"coins","count":25},{"item":"gear","gear_id":"moon_charm" if first else ("jade_blade" if int(p.expansion.chest_visits.get(id,0))%3==2 else "moss_robe"),"count":1}]
  if "focus" not in p.expansion.recipes:p.expansion.recipes.append("focus")
 p.expansion.chest_visits[id]=int(p.expansion.chest_visits.get(id,0))+1;p.expansion.chest_ready[id]=p.world_time+180
 return items
func open(id: String) -> bool:
 if not C.CHESTS.has(id) or game.traveler.position.distance_to(C.CHESTS[id]+Vector3(0,0,0.85))>=2.7:return false
 var p=game.progress
 if id=="shrine" and (not p.expansion.secret_inside or not p.expansion.trial_defeated):game.notify("先击败望月守卫，再开宝箱。");return false
 if game.adventure.in_combat():game.notify("先脱离战斗，再打开宝箱。");return false
 if p.growth.chests.get(id,[]).is_empty():
  if p.world_time<float(p.expansion.chest_ready.get(id,0)):game.notify("空箱正在恢复，还需游玩 %d 秒。"%ceili(p.expansion.chest_ready[id]-p.world_time));return false
  p.growth.chests[id]=generate_contents(id)
 current=id;game.set_paused(true);game.pause_panel.hide();popup.show();heading.text=C.POI_NAMES[id] + " · 宝箱"
 render();animate_lid(-1.15);game.save_game(false);game.feedback.show_event("宝箱已打开","点击格子取物，未取物品会保留。","coins","open")
 return true
func animate_lid(angle: float) -> void:
 if current.is_empty():return
 if lid_tween:lid_tween.kill()
 lid_tween=create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
 lid_tween.tween_property(game.expedition.chests[current].lid,"rotation:x",angle,0.3)
func close() -> void:
 if not popup.visible:return
 popup.hide();animate_lid(0)
func render() -> void:
 var items: Array=game.progress.growth.chests.get(current,[])
 for i in range(18):
  var button: Button=slots[i];var exists:=i<items.size()
  button.disabled=not exists;button.get_child(0).visible=exists;button.get_child(1).text=""
  if exists:
   var item: Dictionary=items[i];var name: String=C.GEAR[item.gear_id].name if item.item=="gear" else C.NAMES[item.item]
   button.get_child(0).item=("sword" if C.GEAR[item.gear_id].slot=="weapon" else C.GEAR[item.gear_id].slot) if item.item=="gear" else item.item
   button.get_child(0).queue_redraw();button.get_child(1).text=str(item.count);button.tooltip_text=name+" · 点击取出"
  var bag_button: Button=bag[i];var kind: String=game.room.ITEMS[i] if i<game.room.ITEMS.size() else ""
  var count: int=game.progress.item_count(kind);bag_button.disabled=count==0;bag_button.get_child(0).visible=not kind.is_empty()
  if not kind.is_empty():bag_button.get_child(0).item=kind;bag_button.get_child(0).queue_redraw();bag_button.get_child(0).modulate.a=1.0 if count else 0.15
  bag_button.get_child(1).text=str(count) if count else "";bag_button.tooltip_text=C.NAMES.get(kind,"")+" · 点击存入"
 status.text="金币直接入钱袋；装备收入 B 背包。未取物品随存档保留，清空后等待宝箱恢复。"
func take(index: int,all := false) -> bool:
 if not accessible():return false
 var items: Array=game.progress.growth.chests[current]
 if index<0 or index>=items.size():return false
 var item: Dictionary=items[index];var p=game.progress
 var amount: int=int(item.count) if all or Input.is_key_pressed(KEY_SHIFT) else 1
 if item.item=="gear":
  if p.expansion.add_gear(item.gear_id)<0:status.text="装备背包已满，先按 B 整理；物品仍在箱内。";return false
 else:
  if (p.coins+amount>100000000 if item.item=="coins" else p.item_count(item.item)+amount>100000):return false
  p.add_item(item.item,amount)
 item.count-=amount
 if item.count<=0:items.remove_at(index)
 game.traveler.play_interaction("storage",C.CHESTS[current]);game.save_game(false);render();return true
func take_all() -> void:
 if not accessible():return
 var obtained:=0
 for i in range(game.progress.growth.chests[current].size()-1,-1,-1):
  if take(i,true):obtained+=1
 if obtained>0:game.feedback.show_event("已收取 %d 项"%obtained,"B 换装 · U 修行；剩余物品保留。","coins")
 else:status.text="没有可取物品，或背包已满；箱内物品会保留。"
func deposit(index: int) -> void:
 if not accessible() or index<0 or index>=game.room.ITEMS.size():return
 var kind: String=game.room.ITEMS[index];var p=game.progress
 var amount: int=p.item_count(kind) if Input.is_key_pressed(KEY_SHIFT) else 1
 if amount<1 or p.item_count(kind)<amount:return
 var items: Array=p.growth.chests[current];var found: Dictionary={}
 for item in items:
  if item.item==kind:found=item
 if found.is_empty():
  if items.size()>=18:return
  items.append({"item":kind,"count":amount})
 else:
  if int(found.count)+amount>100000:return
  found.count+=amount
 p.add_item(kind,-amount);game.save_game(false);render()
