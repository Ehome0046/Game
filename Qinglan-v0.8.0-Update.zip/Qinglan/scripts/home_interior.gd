extends Node3D
## An isolated, persistent home interior above the outdoor world.
const C = preload("res://scripts/catalog.gd")
const Icon = preload("res://scripts/item_icon.gd")
const OFFSET := Vector3(0, 30, 0)
const ENTRY := Vector3(0, 0.1, 3.5)
const CUSHION := Vector3(-3.4, 0.15, -2.4)
const CHEST := Vector3(4.8, 0, -3.0)
const ITEMS := ["herb", "core", "seed", "heal", "mana", "redflower", "dew", "ore", "focus", "moonshard", "ward", "elixir"]
const TITLES := C.NAMES
var game: Node3D
var points: Array[Dictionary] = []
var lid: Node3D
var storage_panel: PanelContainer
var storage_label: Label
var chest_slots: Array[Button] = []
var bag_slots: Array[Button] = []
var meditating := false
var training := false
var rest_elapsed := 0.0
var rest_duration := 4.0
var rest_done := false
var mist: Array[MeshInstance3D] = []
var lamps: Array[OmniLight3D] = []
var banner: MeshInstance3D
var ceiling_parts: Array[Node3D] = []
var roof: MeshInstance3D
var cushion_group: Node3D
var chest_group: Node3D
var current_cushion := CUSHION
var current_chest := CHEST
var lid_tween: Tween

func _ready() -> void:
	position = OFFSET
	process_mode = Node.PROCESS_MODE_ALWAYS
	build_room()
	build_storage()
	hide()

func inside() -> bool:
	return game.progress.inside_home

func material(color: String, stone := false) -> ShaderMaterial:
	var mat := ShaderMaterial.new()
	mat.shader = preload("res://shaders/interior.gdshader")
	mat.set_shader_parameter("base_color", Color(color))
	mat.set_shader_parameter("stone", stone)
	return mat

func box(at: Vector3, dimensions: Vector3, mat: Material, solid := false, parent: Node3D = self) -> MeshInstance3D:
	return game.valley.box(at, dimensions, mat, solid, parent)

func sign_at(text: String, at: Vector3) -> void:
	var label: Label3D = game.valley.sign_text(text, at, 30, Color("e5d6ac"))
	label.reparent(self, false)
	label.pixel_size = 0.006
	label.visibility_range_begin = 1.5

func point(kind: String, at: Vector3, title: String) -> void:
	points.append({"kind": kind, "position": at + OFFSET, "label": title, "id": -1})

func build_room() -> void:
	var v = game.valley
	var timber: Material = v.material("614733")
	var plaster: Material = v.material("b9aa8a")
	var rock := material("66716a", true)
	box(Vector3(0, -0.3, 0), Vector3(16, 0.6, 18), material("75563b"), true)
	for x in [-8.0, 8.0]:
		box(Vector3(x, 2.7, 0), Vector3(0.4, 5.4, 18.5), plaster, true)
		box(Vector3(x * 0.97, 0.5, 0), Vector3(0.16, 1, 18), timber)
		for z in [-8.0, -3.0, 2.0, 8.0]:
			box(Vector3(x * 0.97, 2.5, z), Vector3(0.3, 5, 0.35), timber)
		box(Vector3(x * 0.97, 4.9, 0), Vector3(0.25, 0.4, 18), timber)
	for z in [-9.0, 9.0]:
		box(Vector3(0, 2.7, z), Vector3(16, 5.4, 0.4), plaster, true)
		box(Vector3(0, 4.9, z * 0.97), Vector3(16, 0.4, 0.25), timber)
	roof = box(Vector3(0, 5.5, 0), Vector3(16.4, 0.35, 18.5), timber, true)
	ceiling_parts.append(roof)
	for x in [-5.0, 0.0, 5.0]:
		ceiling_parts.append(box(Vector3(x, 5.15, 0), Vector3(0.3, 0.4, 18), timber))
	# A moon window with a wooden lattice and cool light.
	box(Vector3(0, 2.9, -8.74), Vector3(3.8, 2.7, 0.08), v.material("8baca5"))
	for x in [-1.9, -0.95, 0.0, 0.95, 1.9]:
		box(Vector3(x, 2.9, -8.64), Vector3(0.09, 2.85, 0.1), timber)
	for y in [1.6, 2.4, 3.2, 4.2]:
		box(Vector3(0, y, -8.6), Vector3(3.9, 0.09, 0.12), timber)
	# Entrance, steps, rug, scroll shelf and desk.
	box(Vector3(0, 1.4, 8.7), Vector3(2.5, 2.8, 0.12), timber)
	for x in [-0.65, 0.65]:
		box(Vector3(x, 1.4, 8.6), Vector3(0.07, 2.8, 0.08), v.material("a18652"))
	box(Vector3(0, 0.04, 5.5), Vector3(3, 0.06, 3), v.material("60564a"))
	point("exit_home", Vector3(0, 0, 7), "离开洞府 · 返回庭院")
	sign_at("出门 · E 返回庭院", Vector3(0, 3.3, 8.3))
	for x in [-6.4, -3.7]:
		box(Vector3(x, 1.5, -7.7), Vector3(0.14, 3, 1), timber)
	for y in [0.2, 1.1, 2.0, 2.9]:
		box(Vector3(-5.05, y, -7.7), Vector3(2.9, 0.13, 1.1), timber)
		for i in range(5):
			var scroll: MeshInstance3D = v.cylinder(Vector3(-6.05 + i * 0.48, y + 0.3, -7.65), 0.1, 0.1, 0.5, v.material("c9b88c" if i % 2 else "8eaa99"), self)
			scroll.rotation.z = 0.13 * (i % 3 - 1)
	box(Vector3(3.5, 0.85, -7), Vector3(3.4, 0.16, 1.5), timber, true)
	for x in [2.1, 4.9]:
		box(Vector3(x, 0.42, -7), Vector3(0.16, 0.84, 1.2), timber)
	box(Vector3(3.3, 0.96, -6.9), Vector3(1.5, 0.04, 0.7), v.material("d8c99f"))
	for x in [2.6, 4.0]:
		var scroll: MeshInstance3D = v.cylinder(Vector3(x, 1.0, -6.9), 0.07, 0.07, 0.75, timber, self)
		scroll.rotation.x = PI / 2
	banner = box(Vector3(5.4, 2.8, -8.7), Vector3(1.3, 2.5, 0.05), v.material("496e61"))
	sign_at("静 心 养 气", Vector3(5.4, 2.9, -8.55))
	point("decor", Vector3(3.4, 0, -6), "切换陈设与灯色")
	var group_start := get_child_count()
	# Woven cushion and mat; room to see the cross-legged pose.
	box(CUSHION + Vector3(0, -0.12, 0), Vector3(3.3, 0.05, 3.3), v.material("4d6557"))
	for i in range(6):
		v.cylinder(CUSHION + Vector3.UP * (i * 0.015), 0.79 - i * 0.015, 0.8 - i * 0.015, 0.035, v.material("b4a47a" if i % 2 else "95855f"), self)
	point("bed", CUSHION, "E 盘坐调息 · G 修炼 · 移动起身")
	cushion_group = group_recent(group_start, CUSHION)
	group_start = get_child_count()
	# Chest with hinged lid, feet, metal bands and lock.
	box(CHEST + Vector3.UP * 0.55, Vector3(1.9, 0.85, 1.1), timber, true)
	for x in [-0.72, 0.72]:
		box(CHEST + Vector3(x, 0.35, 0), Vector3(0.12, 1, 1.16), v.material("af9459"))
	lid = Node3D.new()
	add_child(lid)
	lid.position = CHEST + Vector3(0, 1.0, -0.55)
	box(Vector3(0, 0.05, 0.55), Vector3(2.0, 0.16, 1.16), timber, false, lid)
	for x in [-0.72, 0.72]:
		box(Vector3(x, 0.15, 0.55), Vector3(0.12, 0.05, 1.16), v.material("af9459"), false, lid)
	box(CHEST + Vector3(0, 0.85, 0.6), Vector3(0.22, 0.28, 0.08), v.material("d5b979"))
	point("storage", CHEST + Vector3(0, 0, 1.5), "打开洞府储物箱")
	sign_at("储物箱 · E", CHEST + Vector3(0, 2.1, 0))
	chest_group = group_recent(group_start, CHEST)
	# Pots, an incense burner and lamps add scale and softer light.
	for at in [Vector3(-6.5, 0, 4), Vector3(6.5, 0, 4)]:
		v.cylinder(at + Vector3.UP * 0.5, 0.3, 0.5, 1, v.material("61766b"), self)
		for i in range(4):
			var stem: MeshInstance3D = v.cylinder(at + Vector3(0, 1.35, 0), 0.035, 0.05, 1.6, v.leaf, self)
			stem.rotation.z = (i - 1.5) * 0.16
	for at in [Vector3(-5.5, 2.9, -1), Vector3(5.5, 2.9, 2)]:
		var paper: StandardMaterial3D = v.material("d9bd7e", true)
		paper.emission_energy_multiplier = 0.25
		# Bracket, ceiling chain and lantern frame make the support visible.
		box(Vector3(at.x, 5.3, at.z), Vector3(0.6, 0.2, 0.6), timber)
		v.cylinder(Vector3(at.x, 4.29, at.z), 0.025, 0.025, 1.95, v.material("7c7864"), self)
		for side in [-1.0, 1.0]:
			box(at + Vector3(side * 0.2, 0, 0), Vector3(0.035, 0.72, 0.035), timber)
		v.cylinder(at, 0.23, 0.18, 0.65, paper, self)
		v.cylinder(at - Vector3.UP * 0.36, 0.22, 0.24, 0.08, timber, self)
		v.cylinder(at + Vector3.UP * 0.4, 0.3, 0.23, 0.12, timber, self)
		var light := OmniLight3D.new()
		light.position = at
		light.light_color = Color("ffce8d")
		light.omni_range = 13
		light.light_energy = 1.4
		light.shadow_enabled = true
		add_child(light)
		lamps.append(light)
	var moon := OmniLight3D.new()
	moon.position = Vector3(0, 3, -6.5)
	moon.light_color = Color("8fc9cf")
	moon.omni_range = 11
	moon.light_energy = 0.9
	add_child(moon)
	for i in range(3):
		var ring := TorusMesh.new()
		ring.inner_radius = 0.9 + i * 0.27
		ring.outer_radius = ring.inner_radius + 0.025
		var halo: MeshInstance3D = v.mesh_at(ring, CUSHION + Vector3.UP * (0.3 + i * 0.3), v.material("9fc6ac", true), self)
		mist.append(halo)
		halo.hide()

func group_recent(first: int, at: Vector3) -> Node3D:
	var children := get_children().slice(first)
	var group := Node3D.new()
	add_child(group)
	group.position = at
	for child in children: child.reparent(group, true)
	return group

func update_anchors() -> void:
	current_cushion = cushion_group.position
	current_chest = chest_group.position
	for item in points:
		if item.kind == "bed": item.position = OFFSET + current_cushion
		if item.kind == "storage": item.position = OFFSET + current_chest + Vector3(0, 0, 1.5).rotated(Vector3.UP, chest_group.rotation.y)

func apply_style() -> void:
	var index: int = game.progress.home_style
	banner.material_override = game.valley.material(["496e61", "8d6147", "67758a"][index])
	for lamp in lamps:
		lamp.light_color = [Color("f3d7a3"), Color("ffc17f"), Color("b7d4ed")][index]

func restore(at := ENTRY) -> void:
	meditating = false
	game.traveler.sitting = false
	game.traveler.busy = false
	game.valley.visible = not inside()
	game.frontier.visible = not inside()
	game.town.visible = not inside()
	visible = inside()
	# Every interior collision is disabled outside, including for ray casts.
	process_mode = Node.PROCESS_MODE_ALWAYS
	for shape in find_children("*", "CollisionShape3D", true, false):
		shape.set_deferred("disabled", not inside())
	var environment: Environment = game.valley.environment
	environment.fog_enabled = not inside()
	if inside():
		game.traveler.position = OFFSET + at
		game.traveler.spring.spring_length = 4.6
		game.traveler.pitch = -0.2
	if is_instance_valid(game.furnishings): game.furnishings.restore()
	apply_style()
	close_storage()

func enter() -> bool:
	if not game.progress.home_claimed or game.adventure.in_combat():
		game.notify("先认领洞府，并在脱离战斗后入室。")
		return false
	game.progress.inside_home = true
	game.effects.clear()
	game.frontier.clear_hazards()
	game.feedback.reset()
	game.feedback.show_event("进入洞府", "E 储物 / 调息 · P 自由布置", "robe", "open")
	restore()
	game.traveler.velocity = Vector3.ZERO
	game.traveler.play_interaction("enter", OFFSET + Vector3(0, 0, -4))
	game.save_game(false)
	game.notify("进入自己的洞府。箱子 E 储物，蒲团 E 调息 / G 修炼；P 自由布置，门口 E 出门。")
	return true

func leave() -> void:
	stop_rest()
	game.progress.inside_home = false
	restore()
	game.traveler.position = game.adventure.HOME
	game.traveler.velocity = Vector3.ZERO
	game.traveler.spring.spring_length = 5.7
	game.traveler.play_interaction("enter", game.traveler.position + Vector3.FORWARD)
	game.save_game(false)
	game.notify("回到洞府庭院，灵田在屋外北侧。")

func build_storage() -> void:
	storage_panel = game.panel(Vector2(255, 45), Vector2(770, 625))
	var style: StyleBoxFlat = storage_panel.get_theme_stylebox("panel").duplicate()
	style.bg_color = Color("14221f")
	style.content_margin_top = 18
	style.content_margin_bottom = 18
	storage_panel.add_theme_stylebox_override("panel", style)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	storage_panel.add_child(column)
	column.add_child(game.label("洞 府 储 物", 27, Color("dfc997")))
	column.add_child(game.label("点击物品格转移 1 个 · Shift 点击转移全部 · 鼠标悬停查看物品", 16))
	column.add_child(game.label("箱 子", 18, Color("b2c7b5")))
	chest_slots = build_grid(column, true)
	column.add_child(game.label("随 身 背 包", 18, Color("b2c7b5")))
	bag_slots = build_grid(column, false)
	storage_label = game.label("", 16)
	column.add_child(storage_label)
	game.button("关上箱子 · 返回房间", func(): game.set_paused(false), column)
	storage_panel.hide()

func build_grid(parent: Node, in_vault: bool) -> Array[Button]:
	var grid := GridContainer.new()
	grid.columns = 9
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	parent.add_child(grid)
	var buttons: Array[Button] = []
	for i in range(18):
		var slot := Button.new()
		slot.custom_minimum_size = Vector2(65, 65)
		var box_style := StyleBoxFlat.new()
		box_style.bg_color = Color("1f342e")
		box_style.border_color = Color("647468")
		box_style.set_border_width_all(2)
		box_style.set_corner_radius_all(3)
		slot.add_theme_stylebox_override("normal", box_style)
		var hover: StyleBoxFlat = box_style.duplicate()
		hover.bg_color = Color("3b5143")
		hover.border_color = Color("d9bc81")
		slot.add_theme_stylebox_override("hover", hover)
		slot.add_theme_stylebox_override("disabled", box_style)
		grid.add_child(slot)
		if i < ITEMS.size():
			var icon := Icon.new()
			icon.item = ITEMS[i]
			icon.position = Vector2(13, 5)
			icon.size = Vector2(40, 40)
			slot.add_child(icon)
			var count: Label = game.label("", 15)
			count.name = "Count"
			count.position = Vector2(3, 42)
			count.size.x = 58
			count.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			count.mouse_filter = Control.MOUSE_FILTER_IGNORE
			slot.add_child(count)
			slot.tooltip_text = TITLES[ITEMS[i]] + (" · 点击取出" if in_vault else " · 点击存入")
			slot.pressed.connect(transfer.bind(ITEMS[i], not in_vault))
			buttons.append(slot)
		else:
			slot.disabled = true
	return buttons

func open_storage() -> void:
	if not inside() or not nearby("storage"):
		return
	stop_rest()
	game.traveler.play_interaction("storage", OFFSET + current_chest)
	game.set_paused(true)
	game.pause_panel.hide()
	storage_panel.show()
	if lid_tween: lid_tween.kill()
	lid_tween = create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	lid_tween.tween_property(lid, "rotation:x", -1.2, 0.4).set_trans(Tween.TRANS_SINE)
	update_storage()

func close_storage() -> void:
	var was_open := storage_panel.visible
	storage_panel.hide()
	if lid_tween: lid_tween.kill()
	if was_open and visible:
		game.traveler.play_interaction("storage", OFFSET + current_chest)
		lid_tween = create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
		lid_tween.tween_property(lid, "rotation:x", 0.0, 0.3).set_trans(Tween.TRANS_SINE)
	else:
		lid.rotation.x = 0

func update_storage() -> void:
	for i in range(ITEMS.size()):
		for pair in [[chest_slots[i], true], [bag_slots[i], false]]:
			var count: int = game.progress.item_count(ITEMS[i], pair[1])
			pair[0].get_node("Count").text = str(count) if count else ""
			pair[0].get_child(0).modulate.a = 1.0 if count else 0.14
			pair[0].disabled = count == 0
	storage_label.text = "物品按种类堆叠；金币留在钱袋。修炼 / 委托只消耗随身物品。"

func transfer(item: String, to_vault: bool) -> void:
	if not storage_panel.visible or not game.paused or not inside() or not nearby("storage"):
		return
	var amount: int = game.progress.item_count(item, not to_vault) if Input.is_key_pressed(KEY_SHIFT) else 1
	if game.progress.transfer_item(item, to_vault, amount):
		game.traveler.play_interaction("storage", OFFSET + current_chest)
		game.save_game(false)
	update_storage()

func nearby(kind: String) -> bool:
	return points.any(func(p): return p.kind == kind and game.traveler.position.distance_to(p.position) < 2.7)

func begin_rest(train := false) -> bool:
	if game.workshop.active or not inside() or not nearby("bed") or (train and (not game.progress.learned or game.progress.herbs() < 2 or game.progress.cultivation >= 3)):
		game.notify("在室内蒲团旁使用。修炼还需功法、两株随身灵草，本阶段最多三次。")
		return false
	if meditating and not rest_done:
		return false
	meditating = true
	training = train
	rest_elapsed = 0
	rest_duration = 6.0 if train else 4.0
	rest_done = false
	game.traveler.position = OFFSET + current_cushion
	game.traveler.velocity = Vector3.ZERO
	game.traveler.model.rotation.y = cushion_group.rotation.y
	game.traveler.invincible = 0
	game.traveler.sitting = true
	game.traveler.busy = true
	game.notify("盘坐修炼中，完成后扣除两株灵草；E 或移动可取消。" if train else "盘坐调息中，完成后恢复状态；E 或移动起身。")
	return true

func stop_rest() -> void:
	meditating = false
	game.traveler.sitting = false
	game.traveler.busy = false
	for halo in mist: halo.hide()

func _process(delta: float) -> void:
	if not game.playing or game.paused or not inside():
		return
	if meditating:
		if Input.get_vector("left", "right", "forward", "back").length_squared() > 0.1:
			stop_rest()
			return
		rest_elapsed = minf(rest_duration, rest_elapsed + delta)
		for i in range(mist.size()):
			mist[i].show()
			mist[i].position = current_cushion + Vector3.UP * (0.18 + i * 0.35 + sin(game.progress.world_time * 1.7 + i) * 0.12)
			mist[i].rotation.y += delta * (0.3 + i * 0.2)
		if rest_elapsed >= rest_duration and not rest_done:
			rest_done = true
			if training:
				if game.progress.cultivate():
					game.notify("修炼完成：生命上限 +5，灵力上限 +10。E 起身，或 G 再修炼。")
			else:
				game.progress.hp = game.progress.max_hp()
				game.progress.qi = game.progress.max_qi()
				game.notify("调息完成。E 或移动起身，G 可开始修炼。")
			game.save_game(false)
