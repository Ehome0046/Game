extends RefCounted
const Terrain = preload("res://scripts/terrain.gd")
## Visible, interruptible behavior for the four renewable monster species.
var field: Node3D

func reset(enemy: Dictionary) -> void:
 enemy.state="patrol";enemy.state_time=0.0;enemy.windup=-1.0;enemy.aggro_until=0.0;enemy.retreat_ready=0.0
 enemy.knockback=Vector3.ZERO
 enemy.charge_dir=Vector3.FORWARD;enemy.charge_hit=false;enemy.attack_token=int(enemy.get("attack_token",0))+1
 enemy.warning.hide();enemy.lane.hide();enemy.node.velocity=Vector3.ZERO

func enter(enemy: Dictionary,state: String,duration := 0.0) -> void:
 enemy.state=state;enemy.state_time=duration
 if state!="windup": enemy.windup=-1.0
 if state not in ["windup","charge"]: enemy.warning.hide();enemy.lane.hide()

func cancel(enemy: Dictionary) -> void:
 enemy.attack_token+=1;enemy.warning.hide();enemy.lane.hide();enemy.windup=-1

func sight(enemy: Dictionary) -> bool:
 var game=field.game
 var query:=PhysicsRayQueryParameters3D.create(enemy.node.position+Vector3.UP,game.traveler.position+Vector3.UP,1)
 query.exclude=[enemy.node.get_rid(),game.traveler.get_rid()]
 return game.get_world_3d().direct_space_state.intersect_ray(query).is_empty()

func begin_attack(enemy: Dictionary,offset: Vector3) -> void:
 var game=field.game
 var species: int=enemy.species
 enter(enemy,"windup",[0.65,0.95,0.9,1.2][species]);enemy.windup=enemy.state_time
 enemy.cooldown=[2.1,3.2,2.8,3.4][species]
 enemy.mark=game.traveler.position if species==2 else enemy.node.position
 enemy.warning.mesh=Terrain.ring(enemy.mark,1.7 if species==2 else (3.4 if species==3 else 2.9))
 enemy.warning.position=Vector3(enemy.mark.x,Terrain.height_at(enemy.mark.x,enemy.mark.z),enemy.mark.z)
 enemy.warning.show()
 if species==1:
  enemy.charge_dir=offset.normalized()
  enemy.lane.position=Vector3.ZERO
  enemy.lane.rotation.y=0
  enemy.lane.mesh=Terrain.ribbon(enemy.node.position,enemy.node.position+enemy.charge_dir*8,1.8)
  enemy.lane.show()

func alert_pack(enemy: Dictionary) -> void:
 var game=field.game
 for ally in field.enemies:
  if ally==enemy or ally.species!=0 or field.dead(ally) or ally.node.position.distance_to(enemy.node.position)>18: continue
  if ally.state=="patrol":
   ally.aggro_until=game.progress.world_time+7
   enter(ally,"alert",0.65)

func hit(enemy: Dictionary,interrupt: bool) -> void:
 enemy.aggro_until=field.game.progress.world_time+8
 if interrupt and enemy.state in ["windup","charge"]:
  cancel(enemy);enter(enemy,"stagger",0.7)
  enemy.knockback=(enemy.node.position-field.game.traveler.position).normalized()*4
  field.game.effects.ring(enemy.node.position+Vector3.UP*0.5,Color("f2d48c"),0.8)

func move(enemy: Dictionary,direction: Vector3,delta: float) -> void:
 var body: CharacterBody3D=enemy.node
 body.velocity=direction+enemy.knockback;body.velocity.y=-8
 enemy.knockback=enemy.knockback.move_toward(Vector3.ZERO,delta*12)
 if body.position.y<Terrain.height_at(body.position.x,body.position.z)-0.2:body.position.y=Terrain.height_at(body.position.x,body.position.z)+0.05
 body.move_and_slide()
 body.position.x=clampf(body.position.x,-77,77);body.position.z=clampf(body.position.z,-77,77)
 if direction.length_squared()>0.01:
  body.rotation.y=lerp_angle(body.rotation.y,atan2(-direction.x,-direction.z),minf(1,delta*8))

func update(enemy: Dictionary,delta: float) -> void:
 var game=field.game
 var body: CharacterBody3D=enemy.node
 var offset: Vector3=game.traveler.position-body.position;offset.y=0
 var distance:=offset.length()
 var from_home: float=Vector2(body.position.x-enemy.origin.x,body.position.z-enemy.origin.z).length()
 var species: int=enemy.species
 var now: float=game.progress.world_time
 var velocity:=Vector3.ZERO
 enemy.cooldown=maxf(0,enemy.cooldown-delta)
 enemy.state_time=maxf(0,enemy.state_time-delta)
 if enemy.state!="return" and (distance>24 or from_home>21) and enemy.state!="patrol":
  cancel(enemy);enter(enemy,"return")
 match enemy.state:
  "return":
   var home: Vector3=enemy.origin-body.position;home.y=0
   if home.length()<0.7:
    enemy.hp=enemy.max_hp;enemy.aggro_until=0;enemy.cooldown=1.8;enter(enemy,"patrol")
   else:
    velocity=home.normalized()*3.3
    var ray:=PhysicsRayQueryParameters3D.create(body.position+Vector3.UP,body.position+Vector3.UP+velocity.normalized()*1.1,1)
    ray.exclude=[body.get_rid(),game.traveler.get_rid()]
    if not game.get_world_3d().direct_space_state.intersect_ray(ray).is_empty(): velocity=velocity.rotated(Vector3.UP,PI/2)
  "patrol":
   if (distance<11 and sight(enemy)) or enemy.aggro_until>now:
    enter(enemy,"alert",0.65)
    if species==0: alert_pack(enemy)
   else:
    var patrol: Vector3=enemy.origin+Vector3(sin(now*0.3+enemy.origin.x),0,cos(now*0.3))*2
    var towards: Vector3=patrol-body.position;towards.y=0
    velocity=towards.normalized()*0.65 if towards.length()>0.3 else Vector3.ZERO
  "alert":
   body.rotation.y=atan2(-offset.x,-offset.z)
   if enemy.state_time==0: enter(enemy,"chase")
  "chase":
   if distance<0.05: offset=Vector3.FORWARD
   var range: float=[2.5,8.5,10.5,3.0][species]
   if species==0 and enemy.hp<enemy.max_hp*0.3 and now>=enemy.retreat_ready:
    enemy.retreat_ready=now+6;enter(enemy,"retreat",0.85)
   elif enemy.cooldown<=0 and distance<range and sight(enemy):
    begin_attack(enemy,offset)
   elif species==2 and distance<4.5:
    velocity=-offset.normalized()*2.5
   elif distance>(6.5 if species==2 else 1.9):
    var forward:=offset.normalized()
    if species==0:
     var ally_near: bool=field.enemies.any(func(ally):return ally!=enemy and ally.species==0 and not field.dead(ally) and ally.node.position.distance_to(game.traveler.position)<4)
     if ally_near and distance>3.5: forward=(offset.normalized()+offset.normalized().cross(Vector3.UP)*0.65).normalized()
    velocity=forward*[3.1,2.0,2.1,1.4][species]
  "retreat":
   velocity=-offset.normalized()*3.2
   if enemy.state_time==0: enter(enemy,"chase")
  "windup":
   enemy.windup=enemy.state_time
   if enemy.state_time==0:
    if species==1:
     enter(enemy,"charge",0.75);enemy.charge_hit=false;enemy.warning.hide()
    else:
     enemy.warning.hide();field.attack(enemy);enter(enemy,"recover",1.25 if species==3 else 0.65)
  "charge":
   velocity=enemy.charge_dir*9
   if not enemy.charge_hit and distance<1.6:
    enemy.charge_hit=true;game.take_damage(28)
   if enemy.state_time==0:
    velocity=Vector3.ZERO;enter(enemy,"recover",1.15)
  "recover","stagger":
   if enemy.state_time==0: enter(enemy,"chase")
 move(enemy,velocity,delta)
 if enemy.state=="charge":
  for i in range(body.get_slide_collision_count()):
   var normal: Vector3=body.get_slide_collision(i).get_normal()
   if absf(normal.y)<0.5 and normal.dot(enemy.charge_dir)<-0.1:
    if not enemy.charge_hit and body.position.distance_to(game.traveler.position)<1.8:
     enemy.charge_hit=true;game.take_damage(28)
    enter(enemy,"recover",1.15);break
 var pace: float=Vector2(body.velocity.x,body.velocity.z).length()
 enemy.model.scale.y=1+sin(now*3+enemy.origin.x)*0.02
 enemy.model.rotation.x=-0.1 if enemy.state=="charge" else (-0.12*sin(enemy.state_time*15) if enemy.state=="windup" else 0.0)
 for i in range(enemy.legs.size()):
  var leg: Node3D=enemy.legs[i]
  leg.rotation.x=sin(now*(9 if pace>2.2 else 6)+i*PI)*minf(0.5,pace*0.15)
 enemy.label.position=body.position+Vector3.UP*2.6
 enemy.label.visible=distance<28;enemy.model.visible=distance<70
 var states: Dictionary={"alert":"察觉 / 呼应" if species==0 else "警戒","windup":["扑咬蓄力","冲锋预警","毒瘴瞄准","重击蓄力"][species],"charge":"冲锋！","stagger":"打断 / 失衡","return":"脱战归巢","retreat":"退让","recover":"收招"}
 enemy.label.text="%s %d/%d\n%s"%[enemy.title,roundi(enemy.hp),roundi(enemy.max_hp),states.get(enemy.state,"游荡" if enemy.state=="patrol" else "追击")]
