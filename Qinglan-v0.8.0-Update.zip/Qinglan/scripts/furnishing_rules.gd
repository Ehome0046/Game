extends RefCounted
## Shared placement rules for the editor and save validation.
const KINDS := {
 "cushion": {"name":"修炼蒲团", "size":Vector2(3.4,3.4), "height":0.22, "price":0, "solid":false},
 "chest": {"name":"储物箱", "size":Vector2(2.2,1.6), "height":1.1, "price":0, "solid":true},
 "bench": {"name":"木凳", "size":Vector2(1.5,0.8), "height":0.65, "price":12, "solid":true},
 "table": {"name":"茶案", "size":Vector2(1.9,1.3), "height":0.85, "price":25, "solid":true},
 "screen": {"name":"竹屏风", "size":Vector2(2.3,0.5), "height":2.4, "price":35, "solid":true},
 "lamp": {"name":"落地灯", "size":Vector2(0.8,0.8), "height":2.0, "price":18, "solid":true},
 "plant": {"name":"青竹盆栽", "size":Vector2(1.0,1.0), "height":1.8, "price":12, "solid":true},
 "rug": {"name":"云纹地毯", "size":Vector2(2.0,1.5), "height":0.04, "price":15, "solid":false},
 "sect_screen": {"name":"山门云屏", "size":Vector2(2.3,0.5), "height":2.4, "price":35, "sect":true, "solid":true},
 "sect_lamp": {"name":"青岚灯架", "size":Vector2(0.8,0.8), "height":2.1, "price":45, "sect":true, "solid":true}}
const STOCK := {"bench":1,"table":1,"screen":1,"lamp":2,"plant":1,"rug":1,"sect_screen":0,"sect_lamp":0}
const FIXED := [Rect2(-6.9,-0.3,3,3), Rect2(4,-0.3,3,3), Rect2(1.6,-8.1,3.8,2.2), Rect2(-6.8,-8.4,3.5,1.5), Rect2(-7.1,3.4,1.2,1.2), Rect2(5.9,3.4,1.2,1.2)]
const DOOR := Rect2(-1.5,2.7,3,5.7)
const MAX_PLACED := 22

static func initial_layout() -> Array:
 return [{"uid":1,"kind":"cushion","x":-3.4,"z":-2.4,"turn":0},{"uid":2,"kind":"chest","x":4.8,"z":-3.0,"turn":0}]

static func rect(item: Dictionary) -> Rect2:
 var dimensions: Vector2 = KINDS[item.kind].size
 if int(item.turn)%2: dimensions = Vector2(dimensions.y,dimensions.x)
 return Rect2(Vector2(item.x,item.z)-dimensions/2,dimensions)

static func anchor(layout: Array, kind: String) -> Vector3:
 for item in layout:
  if item.kind == kind: return Vector3(item.x,0.15 if kind=="cushion" else 0,item.z)
 return Vector3.ZERO

static func access(item: Dictionary) -> Vector2:
 var offset := Vector3(0,0,1.5).rotated(Vector3.UP,int(item.turn)*PI/2)
 return Vector2(item.x+offset.x,item.z+offset.z)

static func valid_layout(layout: Array) -> bool:
 if layout.size()<2 or layout.size()>MAX_PLACED: return false
 var cores := {"chest":0,"cushion":0}
 var occupied: Array[Rect2] = []
 var solid: Array[Rect2] = []
 var targets: Array[Vector2] = [Vector2(-5.4,3.5),Vector2(5.5,3.5)]
 for item in layout:
  if not KINDS.has(item.get("kind")): return false
  if cores.has(item.kind): cores[item.kind] += 1
  var area := rect(item)
  if not Rect2(-7.5,-8.5,15,17).encloses(area) or area.intersects(DOOR): return false
  for fixed in FIXED:
   if area.grow(0.1).intersects(fixed): return false
  for other in occupied:
   if area.grow(0.1).intersects(other): return false
  occupied.append(area)
  if KINDS[item.kind].solid: solid.append(area.grow(0.34))
  if item.kind=="chest": targets.append(access(item))
  if item.kind=="cushion": targets.append(Vector2(item.x,item.z))
 if cores.chest!=1 or cores.cushion!=1: return false
 # Keep a walkable route from the door to storage, meditation and both stations.
 var blocks: Array[Rect2] = solid.duplicate()
 for area in FIXED: blocks.append(area.grow(0.34))
 var queue: Array[Vector2i] = [Vector2i(0,5)]
 var seen := {Vector2i(0,5):true}
 var cursor := 0
 while cursor<queue.size():
  var cell: Vector2i = queue[cursor]
  cursor+=1
  for step in [Vector2i.LEFT,Vector2i.RIGHT,Vector2i.UP,Vector2i.DOWN]:
   var next: Vector2i = cell+step
   if seen.has(next) or abs(next.x)>7 or abs(next.y)>8: continue
   var point := Vector2(next)
   if blocks.any(func(area): return area.has_point(point)): continue
   seen[next] = true
   queue.append(next)
 for target in targets:
  if blocks.any(func(area):return area.has_point(target)): return false
  if not queue.any(func(cell):return Vector2(cell).distance_to(target)<1.1): return false
 return true
