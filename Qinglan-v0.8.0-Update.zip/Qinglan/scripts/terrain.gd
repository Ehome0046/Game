extends Node3D
## A low-cost walkable height field. Samples match the actual triangle mesh.
const STEP := 2.0
const EDGE := 82.0
static func raw_height(x: float,z: float) -> float:
 var height:=0.0
 for hill in [Vector4(67,-38,11,36),Vector4(47,63,8,31),Vector4(-56,57,7,33),Vector4(-65,-58,9,34)]:
  var d: float=Vector2(x-hill.x,z-hill.y).length()/hill.w
  if d<1: height+=hill.z*pow(1-d*d,2)
 var center_distance:=maxf(maxf(-39-x,x-35),maxf(-38-z,z-36))
 height*=smoothstep(0,10,center_distance)
 # Flat foundations and broad, smooth approaches for buildings and portals.
 for area in [Rect2(-69,3,25,29),Rect2(49,4,15,23),Rect2(6,-66,11,18),Rect2(-10,-80,20,15)]:
  var dx:=maxf(maxf(area.position.x-x,x-area.end.x),0)
  var dz:=maxf(maxf(area.position.y-z,z-area.end.y),0)
  height*=smoothstep(0,9,Vector2(dx,dz).length())
 height*=smoothstep(2.5,9,absf(x+19))
 return height

static func height_at(x: float,z: float) -> float:
 var x0:=floorf(x/STEP)*STEP
 var z0:=floorf(z/STEP)*STEP
 var u:=(x-x0)/STEP;var v:=(z-z0)/STEP
 var a:=raw_height(x0,z0);var b:=raw_height(x0+STEP,z0);var c:=raw_height(x0,z0+STEP);var d:=raw_height(x0+STEP,z0+STEP)
 return a+(b-a)*u+(c-a)*v if u+v<=1 else d+(c-d)*(1-u)+(b-d)*(1-v)

static func ground(at: Vector3) -> Vector3:
 return Vector3(at.x,at.y+height_at(at.x,at.z),at.z)

static func flat_distance(a: Vector3,b: Vector3) -> float:
 return Vector2(a.x-b.x,a.z-b.z).length()

func _ready() -> void:
 var surface:=SurfaceTool.new();surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 var cells:=int(EDGE*2/STEP)
 for iz in range(cells):
  for ix in range(cells):
   var x: float=-EDGE+ix*STEP;var z: float=-EDGE+iz*STEP
   var a:=Vector3(x,raw_height(x,z),z);var b:=Vector3(x+STEP,raw_height(x+STEP,z),z)
   var c:=Vector3(x,raw_height(x,z+STEP),z+STEP);var d:=Vector3(x+STEP,raw_height(x+STEP,z+STEP),z+STEP)
   for point in [a,b,c,b,d,c]:
    var tint:=Color("61744c").lerp(Color("8c8b75"),clampf(point.y/11,0,1))
    tint=tint.lightened(sin(point.x*0.3+point.z*0.21)*0.035)
    surface.set_color(tint);surface.set_uv(Vector2(point.x,point.z)/8);surface.add_vertex(point)
 surface.generate_normals()
 var model:=MeshInstance3D.new();model.mesh=surface.commit()
 var material:=StandardMaterial3D.new();material.vertex_color_use_as_albedo=true;material.roughness=1;model.material_override=material
 add_child(model);model.create_trimesh_collision()

func conform(game: Node3D) -> void:
 game.valley.ground_mesh.hide()
 for root in [game.valley,game.expedition,game.frontier]:
  for node in root.get_children():
   if not node is Node3D or node is CharacterBody3D or node==game.valley.ground_mesh:continue
   var at: Vector3=node.position
   if absf(at.x)>82 or absf(at.z)>82 or at.y>20:continue
   if node is MeshInstance3D and node.mesh is BoxMesh:
    var dimensions: Vector3=node.mesh.size
    if dimensions.y<0.1 and dimensions.x>15 and dimensions.z>15:node.hide();continue
   if node is MultiMeshInstance3D:
    for i in range(node.multimesh.instance_count):
     var transform: Transform3D=node.multimesh.get_instance_transform(i)
     if transform.origin.y>=0:transform.origin=ground(transform.origin)
     node.multimesh.set_instance_transform(i,transform)
   node.position=ground(at)
   if node is MeshInstance3D and node.mesh is BoxMesh and node.mesh.size.y<0.08 and node.mesh.size.x<2 and node.mesh.size.z<2:
    var dx:=height_at(at.x-0.2,at.z)-height_at(at.x+0.2,at.z)
    var dz:=height_at(at.x,at.z-0.2)-height_at(at.x,at.z+0.2)
    node.quaternion=Quaternion(Vector3.UP,Vector3(dx,0.4,dz).normalized())*node.quaternion
 for point in game.valley.interactions:point.position=ground(point.position)
 for plant in game.frontier.herbs:plant.position=ground(plant.position)
 for enemy in game.frontier.enemies:
  enemy.origin=ground(enemy.origin);enemy.node.position=enemy.origin;enemy.node.floor_snap_length=1.2

static func ribbon(from: Vector3,to: Vector3,width: float) -> ArrayMesh:
 var surface:=SurfaceTool.new();surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 var side: Vector3=(to-from).normalized().cross(Vector3.UP).normalized()*width/2
 for i in range(8):
  var a:=from.lerp(to,i/8.0)-side;var b:=from.lerp(to,i/8.0)+side
  var c:=from.lerp(to,(i+1)/8.0)-side;var d:=from.lerp(to,(i+1)/8.0)+side
  for p in [a,b,c,b,d,c]:p.y=height_at(p.x,p.z)+0.11;surface.add_vertex(p)
 surface.generate_normals();return surface.commit()

static func ring(center: Vector3,radius: float,width:=0.12) -> ArrayMesh:
 var surface:=SurfaceTool.new();surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 var origin:=Vector3(center.x,height_at(center.x,center.z),center.z)
 for i in range(32):
  var angle:=i*TAU/32;var next: float=(i+1)*TAU/32
  var points: Array[Vector3]=[]
  for pair in [[angle,radius-width],[angle,radius],[next,radius-width],[next,radius]]:
   var p:=center+Vector3(cos(pair[0])*pair[1],0,sin(pair[0])*pair[1]);p.y=height_at(p.x,p.z)+0.11;points.append(p-origin)
  for index in [0,1,2,1,3,2]:surface.add_vertex(points[index])
 surface.generate_normals();return surface.commit()
