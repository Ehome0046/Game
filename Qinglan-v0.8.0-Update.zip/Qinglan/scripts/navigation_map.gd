extends Control
const C = preload("res://scripts/catalog.gd")
const Rules = preload("res://scripts/world_rules.gd")
## A lightweight map of the existing valley, drawn with the same world coordinates.

var game: Node3D
var navigator: Control
var region_view := false

func bounds() -> float:
	return 80.0 if region_view else 36.0

func map_rect() -> Rect2:
	var side := minf(size.x - 40, size.y - 40)
	return Rect2((size - Vector2.ONE * side) / 2, Vector2.ONE * side)

func world_point(at: Vector3) -> Vector2:
	var rect := map_rect()
	var limit := bounds()
	return rect.position + Vector2((at.x + limit) / (limit * 2), (at.z + limit) / (limit * 2)) * rect.size

func landmark(at: Vector3, title: String, tint: Color, offset := Vector2(9, -9)) -> void:
	var point := world_point(at)
	draw_circle(point, 5, tint)
	draw_string(get_theme_default_font(), point + offset, title, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, tint)

func _draw() -> void:
	if game == null:
		return
	var player_at: Vector3 = game.adventure.HOME if game.progress.inside_home else game.traveler.position
	var rect := map_rect()
	draw_rect(rect, Color("263e37"))
	draw_rect(rect, Color("7c8c77"), false, 2)
	draw_string(get_theme_default_font(), rect.position + Vector2(12, 24), "北 ↑", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("ddd9bd"))
	var limit := bounds()
	for x in [-limit / 2, 0, limit / 2]:
		draw_line(world_point(Vector3(x, 0, -limit)), world_point(Vector3(x, 0, limit)), Color(0.5, 0.6, 0.5, 0.16), 1)
	for z in [-limit / 2, 0, limit / 2]:
		draw_line(world_point(Vector3(-limit, 0, z)), world_point(Vector3(limit, 0, z)), Color(0.5, 0.6, 0.5, 0.16), 1)
	draw_line(world_point(Vector3(-19, 0, -limit)), world_point(Vector3(-19, 0, limit)), Color("548483"), 8 if region_view else 13)
	if region_view:
		for zone in [{"at": Vector3(-49, 0, 49), "name": "南坡林地"}, {"at": Vector3(-49, 0, -50), "name": "西北瘴泽"},
			{"at": Vector3(55, 0, -48), "name": "东北石谷"}, {"at": Vector3(51, 0, 52), "name": "东南兽径"}]:
			draw_rect(Rect2(world_point(zone.at - Vector3(15, 0, 15)), world_point(zone.at + Vector3(15, 0, 15)) - world_point(zone.at - Vector3(15, 0, 15))), Color("3a5040"))
			landmark(zone.at, zone.name, Color("d1c79c"), Vector2(-35, -12))
		landmark(Rules.SURVEY, "勘察界碑", Color("e1c28b"), Vector2(-78, 22))
	for enemy in game.frontier.enemies:
		var at: Vector3 = enemy.node.position
		if not game.frontier.dead(enemy) and absf(at.x) < limit and absf(at.z) < limit:
			draw_circle(world_point(at), 3, Color("d59683"))
	for plant in game.frontier.herbs:
		if plant.node.visible and absf(plant.position.x) < limit and absf(plant.position.z) < limit:
			draw_circle(world_point(plant.position), 2.5, Color("b0ce8f"))
	draw_line(world_point(Vector3(0, 0, 25)), world_point(Vector3(0, 0, -25)), Color("9d9d7f"), 6)
	for at in [Vector3(-7, 0, 18), Vector3(8, 0, 22)]:
		draw_rect(Rect2(world_point(at) - Vector2(12, 10), Vector2(24, 20)), Color("747867"))
	draw_rect(Rect2(world_point(Vector3(16, 0, -36)), world_point(Vector3(33, 0, -18)) - world_point(Vector3(16, 0, -36))), Color("637269"))
	draw_rect(Rect2(world_point(Vector3(-30, 0, 13)), world_point(Vector3(-20, 0, 21)) - world_point(Vector3(-30, 0, 13))), Color("b29a69"), false, 3)
	if navigator.tracking:
		var points := PackedVector2Array([world_point(player_at)])
		for i in range(navigator.cursor, navigator.route.size()):
			points.append(world_point(navigator.route[i].at))
		if points.size() >= 2:
			draw_polyline(points, Color("f1ce81"), 3, true)
	if not region_view:
		landmark(Vector3(0, 0, -23), "北面残卷", Color("d8d6b4"))
		landmark(Vector3(24, 0, -28), "遗府", Color("d6b28a"), Vector2(8, 20))
		landmark(Vector3(13, 0, -8), "石角兽", Color("cd9b82"))
		landmark(Vector3(0, 0, 9), "静心台", Color("dbdaba"))
		landmark(Vector3(0, 0, 18), "村口", Color("dbdaba"), Vector2(9, 18))
		landmark(Vector3(7, 0, 28), "坊市 · 委托与交易", Color("dfc997"), Vector2(8, 25))
		landmark(Vector3(-19, 0, 23.5), "小桥", Color("b7d5c7"), Vector2(6, 20))
		landmark(Vector3(-25, 0, 9), "灵田", Color("b1d6a5"), Vector2(-44, -10))
		landmark(Vector3(-25, 0, 22), "自己的洞府" if game.progress.home_claimed else "无主石室 · E认领", Color("f1ce81"), Vector2(-105, 27))
	else:
		landmark(Vector3(0, 0, 18), "村庄 / 坊市", Color("dbdaba"), Vector2(9, 25))
		landmark(Vector3(-25, 0, 22), "洞府", Color("f1ce81"), Vector2(-40, 25))
	landmark(game.sect.EMISSARY, "青岚门接引处", Color("9ec7d2"), Vector2(9, 19))
	if region_view and (game.progress.journey.sect_stage in [1, 3] or game.progress.journey.contract == "trace"):
		for i in range(game.sect.CLUES.size()):
			landmark(game.sect.CLUES[i], "山道爪痕" if i == 0 else "残符瘴痕", Color("d8d498"), Vector2(9, -9))
		landmark(game.sect.BEACON, "镇瘴阵眼", Color("9ed7bf"), Vector2(-85, -10))
	for id in C.POIS:
		var at: Vector3 = C.POIS[id]
		if absf(at.x) <= limit and absf(at.z) <= limit:
			landmark(at, C.POI_NAMES[id], Color("e1c58f"), Vector2(-40, 21))
	var player := world_point(player_at)
	var facing: float = game.traveler.model.rotation.y
	var forward := Vector2(-sin(facing), -cos(facing))
	var side := Vector2(-forward.y, forward.x)
	draw_colored_polygon(PackedVector2Array([player + forward * 10, player - forward * 6 + side * 5, player - forward * 6 - side * 5]), Color("f6f1de"))
	draw_string(get_theme_default_font(), player + Vector2(12, -8), "你", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("ffffff"))
