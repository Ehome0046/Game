extends Node3D
const C = preload("res://scripts/catalog.gd")
var game: Node3D
var plants: Array[Dictionary] = []
var chests := {}
var guide: PanelContainer
var guide_text: Label
var target_index := 0
var refresh := 0.0
var ambience_active := false
var wind: AudioStreamPlayer
var water_sound: AudioStreamPlayer3D
var random := RandomNumberGenerator.new()

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 random.seed = 5041
 clear_old_decor()
 build_paths()
 build_grove()
 build_mine()
 build_shrine()
 for i in range(C.NODES.size()): build_resource(i)
 for id in C.CHESTS: build_chest(id)
 build_grass()
 build_ambience()
 guide = game.panel(Vector2(930, 370), Vector2(316, 168))
 var style: StyleBoxFlat = guide.get_theme_stylebox("panel").duplicate()
 style.content_margin_left = 18
 style.content_margin_right = 18
 style.content_margin_top = 14
 style.content_margin_bottom = 14
 guide.add_theme_stylebox_override("panel", style)
 guide.mouse_filter = Control.MOUSE_FILTER_IGNORE
 guide_text = game.label("", 17, Color("d8d1ae"))
 guide_text.custom_minimum_size.x = 280
 guide_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 guide_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
 guide.add_child(guide_text)
 guide.hide()

func clear_old_decor() -> void:
 # Old random props predate the new locations; clear their entrances and rooms.
 for node in game.valley.get_children():
  if not node is MeshInstance3D or not (node.mesh is CylinderMesh or node.mesh is SphereMesh): continue
  var at: Vector3 = node.position
  if (at.x > -69 and at.x < -44 and at.z > 3 and at.z < 31) or (at.x > 49 and at.x < 63 and at.z > 4 and at.z < 26) or (absf(at.x) < 10 and at.z < -65) or (at.x > 6 and at.x < 16 and at.z < -49):
   node.queue_free()

func box(at: Vector3, dimensions: Vector3, mat: Material, solid := false) -> MeshInstance3D:
 return game.valley.box(at, dimensions, mat, solid, self)

func label_at(text: String, at: Vector3, size := 28) -> Label3D:
 var label: Label3D = game.valley.sign_text(text, at, size, Color("dccca8"))
 label.reparent(self, false)
 return label

func point(kind: String, id: String, at: Vector3, title: String) -> void:
 game.valley.interactions.append({"kind": kind, "id": -1, "key": id, "position": at, "label": title})

func trail(points: Array) -> void:
 var stone: Material = game.valley.material("898876")
 for i in range(1, points.size()):
  var from: Vector3 = points[i - 1]
  var to: Vector3 = points[i]
  var count := ceili(from.distance_to(to) / 1.5)
  for j in range(count):
   var at := from.lerp(to, float(j) / count)
   var slab := box(at + Vector3.UP * 0.025, Vector3(random.randf_range(0.8, 1.4), 0.05, 0.85), stone)
   slab.rotation.y = random.randf_range(-0.45, 0.45)

func build_paths() -> void:
 trail([Vector3(-25, 0, 24), Vector3(-35, 0, 25), Vector3(-43, 0, 21), C.POIS.grove])
 trail([Vector3(17, 0, 28), Vector3(33, 0, 27), Vector3(44, 0, 25), C.POIS.mine])
 trail([Vector3(6, 0, -21), Vector3(7, 0, -30), Vector3(5, 0, -42), Vector3(11, 0, -53), C.POIS.shrine])
 label_at("← 落霞药谷 · 新药材", Vector3(-35, 2.3, 25), 26)
 label_at("青石矿洞 →\n灵铁与炼器图谱", Vector3(32, 2.4, 27), 26)
 label_at("望月古径 ↑\n炼气一层可入境", Vector3(6, 2.5, -43), 26)
 trail([Vector3(44,0,25),Vector3(42,0,4),Vector3(43,0,-18),Vector3(52,0,-33),Vector3(67,0,-38)])
 label_at("青石高岭 · 山坡可行走",Vector3(67,2.6,-38),27)
 # Paths continue over the physical height field.
 for at in [Vector3(-40, 0, 24), Vector3(43, 0, 26), Vector3(11, 0, -53)]:
  game.valley.cylinder(at + Vector3.UP * 1.15, 0.06, 0.1, 2.3, game.valley.wood, self)
  game.valley.cylinder(at + Vector3.UP * 2.25, 0.19, 0.19, 0.35, game.valley.material("d4bc7e", true), self)

func build_grove() -> void:
 var v = game.valley
 label_at("落 霞 药 谷", C.POIS.grove + Vector3.UP * 3.3, 34)
 var water := ShaderMaterial.new()
 water.shader = preload("res://shaders/water.gdshader")
 v.cylinder(Vector3(-60, 0.02, 27), 2.7, 2.7, 0.03, water, self)
 for i in range(9):
  var angle := i * TAU / 9
  v.cylinder(Vector3(-60 + cos(angle) * 3, 0.15, 27 + sin(angle) * 3), 0.25, 0.4, 0.3, v.stone, self)
 for x in [-67.0, -46.0]:
  v.pine(Vector3(x, 0, 16), 1.3)
 # A weathered herb rack and crates give the valley a former gathering camp.
 for x in [-61.0, -58.0]: box(Vector3(x, 1.3, 5), Vector3(0.12, 2.6, 0.16), v.wood)
 box(Vector3(-59.5, 2.45, 5), Vector3(3.3, 0.12, 0.18), v.wood)
 for i in range(5): v.cylinder(Vector3(-60.5 + i * 0.5, 2.0, 5), 0.08, 0.15, 0.5, v.leaf, self)

func build_mine() -> void:
 var v = game.valley
 var rock: Material = v.material("626d69")
 for x in [50.0, 62.0]:
  box(Vector3(x, 2.6, 14), Vector3(1.5, 5.2, 17), rock, true)
 box(Vector3(56, 2.6, 5.5), Vector3(13, 5.2, 1.5), rock, true)
 box(Vector3(56, 5.6, 14), Vector3(13, 1, 18), rock, true)
 for x in [52.0, 60.0]: box(Vector3(x, 2.1, 22), Vector3(0.45, 4.2, 0.6), v.wood, true)
 box(Vector3(56, 4.1, 22), Vector3(8.8, 0.4, 0.6), v.wood)
 for z in [9.0, 15.0]:
  for x in [51.5, 60.5]: box(Vector3(x, 2.1, z), Vector3(0.25, 4.2, 0.3), v.wood)
  box(Vector3(56, 4.1, z), Vector3(9.4, 0.25, 0.3), v.wood)
 for x in [55.0, 57.0]: box(Vector3(x, 0.04, 14), Vector3(0.06, 0.07, 15), v.material("8e9592"))
 for z in range(8, 23, 2): box(Vector3(56, 0.02, z), Vector3(2.8, 0.04, 0.18), v.wood)
 for at in [Vector3(52, 2.1, 19), Vector3(59, 2.1, 8)]:
  v.cylinder(at, 0.14, 0.1, 0.4, v.material("b9c9b9", true), self)
  var light := OmniLight3D.new()
  light.position = at
  light.light_color = Color("99c6bd")
  light.light_energy = 1.0
  light.omni_range = 9
  add_child(light)
 label_at("青 石 矿 洞\n灵铁 · 炼器图谱", Vector3(56, 4.6, 23), 30)

func build_shrine() -> void:
 var v = game.valley
 for x in [8.5, 13.5]:
  box(Vector3(x, 1.7, -62), Vector3(0.6, 3.4, 0.8), v.stone, true)
 box(Vector3(11, 3.5, -62), Vector3(6.3, 0.6, 1.1), v.stone)
 var ring := TorusMesh.new()
 ring.inner_radius = 1.45
 ring.outer_radius = 1.55
 var portal: MeshInstance3D = v.mesh_at(ring, Vector3(11, 1.7, -61.8), v.material("85bcb6", true), self)
 portal.rotation.x = PI / 2
 point("portal", "shrine", C.POIS.shrine, "望月秘境 · 炼气一层 / 兽丹 × 1")
 label_at("望 月 秘 境", Vector3(11, 4.4, -62), 32)
 # A sealed pocket in the existing world; both portals are usable and saved.
 for x in [-9.0, 9.0]: box(Vector3(x, 2.4, -72.5), Vector3(1, 4.8, 13), v.stone, true)
 for z in [-78.5, -66.5]: box(Vector3(0, 2.4, z), Vector3(18, 4.8, 1), v.stone, true)
 box(Vector3(0, 0.03, -72), Vector3(16, 0.06, 11), v.material("607b72"))
 for i in range(8):
  var angle := i * TAU / 8
  var at := Vector3(cos(angle) * 5.8, 0.13, -72 + sin(angle) * 3.8)
  v.cylinder(at, 0.35, 0.45, 0.26, v.material("adc7b3", true), self)
 var circle := TorusMesh.new()
 circle.inner_radius = 2.6
 circle.outer_radius = 2.66
 v.mesh_at(circle, Vector3(0, 0.11, -73), v.material("9ebdb0", true), self)
 var moon := OmniLight3D.new()
 moon.position = Vector3(0, 3, -73)
 moon.omni_range = 13
 moon.light_color = Color("9ecac7")
 moon.light_energy = 0.8
 add_child(moon)
 point("return_shrine", "shrine", Vector3(0, 0, -68.8), "离开秘境 · 返回望月古径")
 label_at("返 回 · E", Vector3(0, 2, -68.2), 28)

func build_resource(index: int) -> void:
 var definition: Dictionary = C.NODES[index]
 var at: Vector3 = definition.at
 var body := Node3D.new()
 add_child(body)
 body.position = at
 var v = game.valley
 if definition.item == "ore":
  var rock := SphereMesh.new()
  rock.radius = 0.7
  rock.height = 1
  rock.radial_segments = 9
  rock.rings = 5
  v.mesh_at(rock, Vector3.UP * 0.25, v.stone, body)
  for i in range(4):
   var shard: MeshInstance3D = v.cylinder(Vector3((i - 1.5) * 0.2, 0.65, 0), 0, 0.13, 0.8, v.material("86bfc4", true), body)
   shard.rotation.z = (i - 1.5) * 0.22
 else:
  v.cylinder(Vector3.UP * 0.4, 0.03, 0.05, 0.8, v.leaf, body)
  for i in range(4):
   var leaf: MeshInstance3D = v.box(Vector3(0, 0.18 + i * 0.14, 0), Vector3(0.6, 0.04, 0.16), v.material("83a481"), false, body)
   leaf.rotation.y = i * 1.3
  v.cylinder(Vector3.UP * 0.85, 0.12, 0.08, 0.18, v.material("c5876e" if definition.item == "redflower" else "8abfc0", true), body)
 var title: Label3D = label_at(C.NAMES[definition.item], at + Vector3.UP * 1.5, 22)
 title.visibility_range_end = 12
 title.pixel_size = 0.004
 plants.append({"node": body, "id": str(index), "label": title})
 point("resource", str(index), at, "采集" + C.NAMES[definition.item])

func build_chest(id: String) -> void:
 var at: Vector3 = C.CHESTS[id]
 var v = game.valley
 box(at + Vector3.UP * 0.45, Vector3(1.3, 0.8, 0.85), v.wood, true)
 var lid := Node3D.new()
 add_child(lid)
 lid.position = at + Vector3(0, 0.85, -0.42)
 v.box(Vector3(0, 0, 0.42), Vector3(1.4, 0.14, 0.95), v.material("9b8156"), false, lid)
 box(at + Vector3(0, 0.65, 0.48), Vector3(0.18, 0.25, 0.06), v.material("d7b979"))
 for x in [-0.48,0.48]:
  box(at+Vector3(x,0.42,0),Vector3(0.09,0.9,0.9),v.material("aa905d"))
  v.box(Vector3(x,0.09,0.42),Vector3(0.09,0.06,0.95),v.material("aa905d"),false,lid)
 for x in [-0.48,0.48]:
  for z in [-0.28,0.28]:box(at+Vector3(x,0.09,z),Vector3(0.18,0.18,0.18),v.wood)
 chests[id] = {"lid": lid}
 point("treasure", id, at + Vector3(0, 0, 0.85), "探索宝箱 · 装备与配方")

func build_grass() -> void:
 var surface := SurfaceTool.new()
 surface.begin(Mesh.PRIMITIVE_TRIANGLES)
 for axis in [0.0, PI / 2]:
  for vertex in [Vector3(-0.22, 0, 0), Vector3(0, 0.6, 0), Vector3(0.22, 0, 0)]:
   surface.set_uv(Vector2(0, vertex.y / 0.6))
   surface.add_vertex(vertex.rotated(Vector3.UP, axis))
 surface.generate_normals()
 var multi := MultiMesh.new()
 multi.transform_format = MultiMesh.TRANSFORM_3D
 multi.mesh = surface.commit()
 multi.instance_count = 900
 for i in range(multi.instance_count):
  var at := Vector3(random.randf_range(-73, 73), 0.02, random.randf_range(-73, 73))
  if i >= 550: at = Vector3(random.randf_range(-67, -45), 0.02, random.randf_range(5, 29))
  if absf(at.x) < 5 or absf(at.x + 19) < 3 or (at.x > -31 and at.x < -20 and at.z > 4 and at.z < 23) or (at.x > 49 and at.x < 63 and at.z > 5 and at.z < 24) or (absf(at.x) < 10 and at.z < -65):
   at.y = -4
  var scale := random.randf_range(0.65, 1.1)
  multi.set_instance_transform(i, Transform3D(Basis(Vector3.UP, random.randf() * TAU).scaled(Vector3.ONE * scale), at))
 var node := MultiMeshInstance3D.new()
 node.multimesh = multi
 var mat := ShaderMaterial.new()
 mat.shader = preload("res://shaders/grass.gdshader")
 node.material_override = mat
 node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 add_child(node)

func build_ambience() -> void:
 var stream := AudioStreamWAV.new()
 stream.format = AudioStreamWAV.FORMAT_16_BITS
 stream.mix_rate = 22050
 stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
 stream.loop_end = 44100
 var bytes := PackedByteArray()
 bytes.resize(88200)
 var previous := 0.0
 for i in range(44100):
  previous = lerpf(previous, random.randf_range(-1, 1), 0.15)
  var envelope := 0.5 - 0.5 * cos(TAU * i / 44100.0)
  bytes.encode_s16(i * 2, int(previous * envelope * 18000))
 stream.data = bytes
 wind = AudioStreamPlayer.new()
 wind.stream = stream
 wind.volume_db = -29
 add_child(wind)
 water_sound = AudioStreamPlayer3D.new()
 water_sound.stream = stream
 water_sound.position = Vector3(-19, 0.5, 20)
 water_sound.volume_db = -16
 water_sound.max_distance = 32
 water_sound.unit_size = 6
 add_child(water_sound)

func available(point_data: Dictionary) -> bool:
 if point_data.kind != "resource": return true
 return float(game.progress.expansion.node_ready.get(point_data.key, 0)) <= game.progress.world_time

func harvest(id: String) -> bool:
 var index := int(id)
 if index < 0 or index >= C.NODES.size(): return false
 var definition: Dictionary = C.NODES[index]
 var p = game.progress
 if p.world_time < float(p.expansion.node_ready.get(id, 0)) or game.traveler.position.distance_to(definition.at) >= 2.7 or p.item_count(definition.item) >= 100000: return false
 p.add_item(definition.item, 1)
 p.expansion.node_ready[id] = p.world_time + (90 if definition.item == "ore" else 45)
 game.notify("采得" + C.NAMES[definition.item] + "。可回洞府制作，或在坊市出售。")
 game.feedback.show_event("获得"+C.NAMES[definition.item]+" ×1", "已收入随身背包。", definition.item)
 sync()
 return true

func open_chest(id: String) -> bool:
 return game.treasure.open(id)

func enter_shrine() -> bool:
 var p = game.progress
 if p.expansion.secret_inside or game.traveler.position.distance_to(C.POIS.shrine) >= 2.7: return false
 if not p.growth.chests.get("shrine",[]).is_empty() and p.expansion.trial_defeated and not game.adventure.in_combat() and p.realm>=1:
  p.expansion.secret_inside=true
  game.traveler.position=Vector3(0,0.1,-70.5);game.traveler.velocity=Vector3.ZERO
  game.effects.clear();game.trial.reset();game.notify("秘境宝箱仍有存物，可免费取回，不开启新试炼。")
  return true
 if p.world_time < float(p.expansion.chest_ready.get("shrine", 0)):
  game.notify("秘境宝箱还在恢复灵气，稍后再来；未消耗兽丹。")
  return false
 if p.realm < 1 or game.adventure.in_combat() or (not p.expansion.trial_paid and p.beast_cores < 1):
  game.notify("入境需要炼气一层、一枚随身兽丹，并脱离战斗；未领奖的试炼可免费续战。")
  return false
 if not p.expansion.trial_paid:
  p.beast_cores -= 1
  p.expansion.trial_paid = true
  p.expansion.trial_runes = 0
  p.expansion.trial_defeated = false
 p.expansion.secret_inside = true
 game.traveler.position = Vector3(0, 0.1, -70.5)
 game.traveler.velocity = Vector3.ZERO
 game.traveler.yaw = 0
 game.effects.clear()
 game.trial.reset()
 game.notify("踏入望月试炼。先 E 唤醒三块阵石，击败守卫后开宝箱；返回点随时可用。")
 return true

func leave_shrine() -> void:
 if not game.progress.expansion.secret_inside: return
 game.progress.expansion.secret_inside = false
 game.traveler.position = C.POIS.shrine + Vector3(0, 0.1, 1.5)
 game.traveler.velocity = Vector3.ZERO
 game.effects.clear()
 game.trial.reset()
 if game.navigation.tracking: game.navigation.plan_route()
 game.notify("已返回望月古径。")

func cycle_target() -> void:
 target_index = (target_index + 1) % 4

func sync() -> void:
 for entry in game.valley.interactions:
  if entry.kind == "portal":
   entry.label = "望月试炼 · 未领奖可免费续战" if game.progress.expansion.trial_paid else "望月试炼 · 炼气一层 / 兽丹 × 1"
 for plant in plants:
  plant.node.visible = float(game.progress.expansion.node_ready.get(plant.id, 0)) <= game.progress.world_time
  plant.label.visible = plant.node.visible
 for id in chests:
  if not game.treasure.popup.visible and not (game.treasure.lid_tween and game.treasure.lid_tween.is_running()): chests[id].lid.rotation.x = 0

func reset() -> void:
 target_index = 0
 sync()

func _process(delta: float) -> void:
 visible = not game.progress.inside_home
 var active: bool = game.playing and not game.paused and not game.progress.inside_home and not game.exiting
 if active != ambience_active:
  ambience_active = active
  if active and DisplayServer.get_name() != "headless":
   wind.play()
   water_sound.play()
  else:
   wind.stop()
   water_sound.stop()
 guide.visible = active and (target_index < 3 or game.progress.expansion.secret_inside)
 guide.position.y = 126 if game.progress.expansion.secret_inside else 370
 if not active: return
 refresh -= delta
 if refresh <= 0:
  refresh = 0.25
  sync()
  for id in C.POIS:
   if id not in game.progress.expansion.discoveries and game.traveler.position.distance_to(C.POIS[id]) < 9:
    game.progress.expansion.discoveries.append(id)
    game.notify("发现" + C.POI_NAMES[id] + "。M 地图查看，T 切换探索指引。")
  if game.progress.expansion.secret_inside:
   guide_text.text = "望月试炼\n阵石 %d / 3 · %s\n返回点 E 可离开，未领奖可免费续战\n月华晶带回洞府提升装备品质" % [game.trial.seal_count(), "宝箱已解封" if game.progress.expansion.trial_defeated else "击败守卫后开箱"]
  elif target_index < 3:
   var id: String = C.POIS.keys()[target_index]
   guide_text.text = "探索 · %s\n距离约 %d 米\n%s\nT 切换 / 隐藏指引 · M 地图" % [C.POI_NAMES[id], ceili(game.traveler.position.distance_to(C.POIS[id])), {"grove": "村西过桥，沿石径向西找药材。", "mine": "从坊市向东，沿轨道走入矿洞。", "shrine": "绕过残卷石壁东侧，沿古径向北。"}[id]]

func stop_ambience() -> void:
 ambience_active = false
 if is_instance_valid(wind): wind.stop()
 if is_instance_valid(water_sound): water_sound.stop()

func _exit_tree() -> void:
 stop_ambience()
 if is_instance_valid(wind):
  wind.stream = null
 if is_instance_valid(water_sound):
  water_sound.stream = null
