extends Node3D
const EMISSARY := Vector3(16,0,29)
const BOARD := Vector3(21,0,30)
const CLUES := [Vector3(-35,0,38),Vector3(-35,0,-33)]
const BEACON := Vector3(-37,0,-29)
var game: Node3D
var popup: PanelContainer
var story: Label
var objective_label: Label
var actions: VBoxContainer
var status: Label
var rite_active := false
var rite_elapsed := 0.0
var refresh := 0.0
var marks: Array[Dictionary] = []

func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 game.town.build_npc("sect","林照 · 青岚门执事",EMISSARY,"4e7a86")
 var v=game.valley
 v.box(Vector3(19,0.03,31),Vector3(10,0.05,8),v.material("898775"))
 for x in [13.0,25.0]:
  v.box(Vector3(x,2,33),Vector3(0.3,4,0.3),v.wood,true)
  v.box(Vector3(x,2.5,32.8),Vector3(1,1.9,0.04),v.material("48777a"))
 v.box(Vector3(19,4,33),Vector3(12.5,0.35,1.5),v.wood)
 v.sign_text("青岚门 · 山下接引处\n林照 E 交谈 · J 宗门志",Vector3(19,4.9,33),29,Color("dfd3a8"))
 v.box(BOARD+Vector3.UP*1.4,Vector3(2,2.1,0.2),v.wood,true)
 v.box(BOARD+Vector3(0,1.5,-0.13),Vector3(1.6,1.6,0.04),v.material("c1b58e"))
 add_point("sect_board",BOARD+Vector3(0,0,-1),"宗门告示 · 委托与贡献",-1)
 v.sign_text("宗门告示 · E",BOARD+Vector3.UP*2.8,24)
 v.sign_text("村东接引处 →\n宗门剧情 · J 查看",Vector3(11,2.4,26),25)
 for i in range(CLUES.size()):
  var at: Vector3=CLUES[i]
  v.box(at+Vector3.UP*0.22,Vector3(1.2,0.4,0.7),v.stone)
  for j in range(3):
   v.box(at+Vector3((j-1)*0.23,0.45,0),Vector3(0.07,0.03,0.8),v.material("b19f72",true))
  var text: Label3D=v.sign_text(["山道爪痕 · E 调查","残符瘴痕 · E 调查"][i],at+Vector3.UP*1.6,24)
  marks.append({"node":text,"kind":"clue","id":i})
  add_point("sect_clue",at,"调查山道爪痕" if i==0 else "调查残符瘴痕",i)
 v.cylinder(BEACON+Vector3.UP*0.65,0.3,0.45,1.3,v.stone)
 var ring:=TorusMesh.new();ring.inner_radius=1.1;ring.outer_radius=1.16
 v.mesh_at(ring,BEACON+Vector3.UP*0.05,v.material("8cbcb2",true))
 var text: Label3D=v.sign_text("镇瘴阵眼 · E 安定灵脉",BEACON+Vector3.UP*1.9,25)
 marks.append({"node":text,"kind":"rite","id":-1})
 add_point("sect_rite",BEACON,"安定灵脉 · 4 秒施法",-1)
 popup=game.panel(Vector2(235,30),Vector2(810,656))
 var col:=VBoxContainer.new();col.add_theme_constant_override("separation",12);popup.add_child(col)
 col.add_child(game.label("宗 门 志 · 青 岚 门",30,Color("dfc997")))
 var scroll:=ScrollContainer.new();scroll.custom_minimum_size=Vector2(750,425);scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;col.add_child(scroll)
 var body:=VBoxContainer.new();body.custom_minimum_size.x=724;body.add_theme_constant_override("separation",16);scroll.add_child(body)
 story=game.label("",18);story.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;story.custom_minimum_size.x=720;body.add_child(story)
 objective_label=game.label("",18,Color("b9d4bf"));objective_label.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;objective_label.custom_minimum_size.x=720;body.add_child(objective_label)
 actions=VBoxContainer.new();actions.add_theme_constant_override("separation",8);body.add_child(actions)
 status=game.label("",16,Color("e2c58c"));status.custom_minimum_size.x=740;status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;col.add_child(status)
 var row:=HBoxContainer.new();row.add_theme_constant_override("separation",12);col.add_child(row)
 game.button("追踪 / 隐藏宗门目标",toggle_tracking,row)
 game.button("返回修行 · J / Esc",func():game.set_paused(false),row)
 popup.hide()

func add_point(kind: String,at: Vector3,title: String,id: int) -> void:
 game.valley.interactions.append({"kind":kind,"position":at,"label":title,"id":id})

func available(point: Dictionary) -> bool:
 if point.kind=="sect_clue": return game.progress.journey.sect_stage==1 or game.progress.journey.contract=="trace"
 if point.kind=="sect_rite": return game.progress.journey.sect_stage==3
 return true

func nearby(at: Vector3) -> bool:
 return not game.progress.inside_home and not game.progress.expansion.secret_inside and game.traveler.position.distance_to(at)<3.2

func open() -> void:
 if rite_active: cancel_rite()
 game.set_paused(true);game.pause_panel.hide();popup.show();status.text="";render()

func hide_panel() -> void:
 popup.hide()

func objective() -> String:
 var s=game.progress.journey
 match s.sect_stage:
  0: return "入门前置：炼气一层。\n村东林照处 E 接下考核，J 查看宗门志。"
  1: return "山道异闻：调查两处线索（%d / 2）。\n南坡林地东缘爪痕、西北瘴泽东缘残符，之后回林照处。" % [int(bool(s.clues&1))+int(bool(s.clues&2))]
  2: return "药火与山民：%s\n到沈娘处交 4 灵草或 3 灵铁，二选一，再回林照处。" % ("援助已送达" if s.support else "选择援助村民的方式")
  3: return "清剿瘴源：妖狼 %s / 山豕 %s / 毒蛛 %s\n随后到西北镇瘴阵眼 E 施法，再回林照处。" % ["✓" if s.hunts&1 else "0/1","✓" if s.hunts&2 else "0/1","✓" if s.hunts&4 else "0/1"]
 if s.contract=="hunt": return "外门巡猎：本次击败妖兽 %d / 2。\n回宗门告示交付，得 25 贡献、35 金币。"%s.contract_count
 if s.contract=="trace": return "外门巡查：本次调查线索 %d / 2。\n回宗门告示交付，得 25 贡献、35 金币。"%[int(bool(s.contract_clues&1))+int(bool(s.contract_clues&2))]
 return "青岚门外门弟子。\n村东宗门告示接重复委托；贡献可在洞府布置页兑换云屏与灯架。"

func target() -> Vector3:
 var s=game.progress.journey
 if (s.sect_stage==1 and s.clues!=3) or s.contract=="trace":
  var bits: int=s.clues if s.sect_stage==1 else s.contract_clues
  for i in [0,1]:
   if not bits&(1<<i): return CLUES[i]
 if s.sect_stage==2 and s.support==0: return Vector3(-5,0,26)
 if s.sect_stage==3 and not s.rite:
  if s.hunts!=7:
   for enemy in game.frontier.enemies:
    if enemy.species in [0,1,2] and not s.hunts&(1<<enemy.species) and not game.frontier.dead(enemy): return enemy.node.position
  return BEACON
 if s.contract=="hunt" and s.contract_count<2:
  for enemy in game.frontier.enemies:
   if not game.frontier.dead(enemy): return enemy.node.position
 return BOARD if s.sect_stage==4 else EMISSARY

func render() -> void:
 for child in actions.get_children(): actions.remove_child(child);child.queue_free()
 var s=game.progress.journey
 var chapters := ["初见 · 山门之约","第一章 · 山道异闻","第二章 · 药火与山民","第三章 · 清剿瘴源","终章 · 青岚入门"]
 var texts := [
  "林照：青岚门近来发现山下妖兽躁动。我奉命接引有心修行之人。修为只是一道门槛，遇事如何选择，才见本心。\n\n你若已引气入体，就替我查一查山道上的异象；未准备好，也可先照顾自己的修行与住处。",
  "林照：南坡留下了异常爪痕，西北又有破碎阵符。去两处看看，别急着把所有妖兽都当作敌人。线索会留在石堆上。\n\n山道爪痕：狼群似乎在绕开某处灵气。残符瘴痕：守山阵法有了缺口，瘴气正在改变兽群。",
  "林照：阵符受损，附近山民也受了瘴气影响。沈娘缺药材，修阵则缺灵铁。你可以采四株灵草送药，也可以交三块灵铁修阵。\n\n两条路都能帮助村民，只会消耗你亲自选择的一份材料。到沈娘面前 E 交谈，选择“宗门援助”。",
  "林照：现在知道了缘由，便不能只求自己安稳。在考核期间各击败一只妖狼、山豕和毒蛛，削弱瘴源，再到镇瘴阵眼施法四秒。\n\n清剿只计本章实际战斗，旧兽丹不能代替。观察妖兽动作，留意冲锋、毒瘴与地面预警。",
  "林照：你查清异闻，也为山下百姓出了力。从今日起，你是青岚门外门弟子。修行之路尚长，愿你记得今日为何入山。\n\n村东告示可接巡猎与巡查。贡献可兑换洞府陈设，让这段旅程也留在自己的住处。"]
 story.text=chapters[s.sect_stage]+"\n\n"+texts[s.sect_stage]
 if s.support: story.text+="\n\n沈娘回信："+("药草救急，村民已能安睡。谢谢你顾念众人。" if s.support==1 else "灵铁已送去补阵，山风中的瘴气渐渐散了。")
 var distance: float=Vector2(game.traveler.position.x-target().x,game.traveler.position.z-target().z).length()
 objective_label.text=objective()+"\n贡献 %d · 下一目标约 %.0f 米 · M 地图查看宗门标记"%[s.contribution,distance]
 if s.sect_stage<4:
  game.button("与林照交付 / 推进剧情",advance,actions).disabled=not nearby(EMISSARY)
 if s.sect_stage==2 and s.support==0:
  game.button("沈娘：送 4 灵草救治村民",aid.bind(1),actions).disabled=not nearby(Vector3(-5,0,26))
  game.button("沈娘：送 3 灵铁修复阵符",aid.bind(2),actions).disabled=not nearby(Vector3(-5,0,26))
 if s.sect_stage==4:
  if s.contract.is_empty():
   game.button("接巡猎：本次击败 2 只妖兽",accept.bind("hunt"),actions).disabled=not nearby(BOARD)
   game.button("接巡查：重新调查两处线索",accept.bind("trace"),actions).disabled=not nearby(BOARD)
  else:
   game.button("交付宗门委托",claim_contract,actions).disabled=not nearby(BOARD)
 if not nearby(EMISSARY) and s.sect_stage<4: status.text="J 随时查看进度；交付剧情需回到村东林照身边。"

func changed(ok: bool,text: String) -> void:
 if ok:
  game.traveler.play_interaction("trade",target());game.save_game(false)
 render();status.text=text if ok else "条件尚未满足。请查看本章目标、材料或装备背包空位。"

func advance() -> void:
 if not popup.visible or not game.paused or not nearby(EMISSARY): return
 changed(game.progress.journey.turn_in(game.progress),"剧情已推进，奖励已到账。下一目标见宗门志。")

func aid(choice: int) -> void:
 if not popup.visible or not game.paused or not nearby(Vector3(-5,0,26)): return
 changed(game.progress.journey.aid(game.progress,choice),"援助已送达，只扣所选材料。请回林照处交谈。")

func accept(kind: String) -> void:
 if not popup.visible or not game.paused or not nearby(BOARD): return
 changed(game.progress.journey.accept_contract(kind),"宗门委托已接取，本次行动开始计数。")

func claim_contract() -> void:
 if not popup.visible or not game.paused or not nearby(BOARD): return
 changed(game.progress.journey.claim_contract(game.progress),"委托完成：25 贡献、35 金币。可继续接取。")

func toggle_tracking() -> void:
 game.progress.journey.tracking=not game.progress.journey.tracking;game.save_game(false)
 status.text="已在左侧显示宗门目标。" if game.progress.journey.tracking else "宗门追踪已隐藏，原主线和坊市委托继续显示。"

func investigate(index: int) -> void:
 if index not in [0,1] or not nearby(CLUES[index]): return
 var changed: bool=game.progress.journey.investigate(index)
 game.notify((["爪痕指向西北：狼群正在躲避瘴气。","残符记载：守山阵法缺损，先回林照处报告。"][index]) if changed else "此处已调查；不会重复增加进度。")
 if changed: game.save_game(false)

func begin_rite() -> bool:
 var s=game.progress.journey
 if s.sect_stage!=3 or s.hunts!=7 or s.rite or not nearby(BEACON) or game.adventure.in_combat():
  game.notify("先完成本章三类清剿，并在镇瘴阵眼旁脱战施法。")
  return false
 rite_active=true;rite_elapsed=0;game.traveler.busy=true;game.traveler.velocity=Vector3.ZERO
 game.traveler.play_interaction("craft",BEACON);game.notify("安定灵脉中：4 秒施法，E 或移动可取消。")
 return true

func cancel_rite() -> void:
 if not rite_active: return
 rite_active=false;game.traveler.busy=false;rite_elapsed=0

func reset() -> void:
 cancel_rite();hide_panel()

func _process(delta: float) -> void:
 if not game.playing or game.paused: return
 if rite_active:
  if Input.get_vector("left","right","forward","back").length()>0.1 or not nearby(BEACON) or game.adventure.in_combat():
   cancel_rite();game.notify("施法中止，清剿进度保留。")
  else:
   rite_elapsed+=delta
   if game.traveler.interaction_time<0.1: game.traveler.play_interaction("craft",BEACON)
   if rite_elapsed>=4:
    game.progress.journey.rite=true;cancel_rite();game.effects.ring(BEACON+Vector3.UP*0.2,Color("a0d5bf"),1.7);game.save_game(false);game.notify("镇瘴阵眼已安定！回林照处完成入门。")
 refresh-=delta
 if refresh>0: return
 refresh=0.3
 for mark in marks:
  mark.node.visible=not game.progress.inside_home and ((game.progress.journey.sect_stage==1 or game.progress.journey.contract=="trace") if mark.kind=="clue" else game.progress.journey.sect_stage==3)
