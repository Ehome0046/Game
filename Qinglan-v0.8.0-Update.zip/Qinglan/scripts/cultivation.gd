extends Node
const Icon=preload("res://scripts/item_icon.gd")
var game: Node3D
var popup: PanelContainer
var detail: Label
var status: Label
func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 popup=game.panel(Vector2(240,35),Vector2(800,640))
 var col:=VBoxContainer.new();col.add_theme_constant_override("separation",12);popup.add_child(col)
 col.add_child(game.label("修 行 · 境 界 与 功 法",28,Color("dfc997")))
 detail=game.label("",18);detail.custom_minimum_size=Vector2(740,230);detail.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;col.add_child(detail)
 var row:=HBoxContainer.new();row.add_theme_constant_override("separation",12);col.add_child(row)
 game.button("选择剑修 · 御剑伤害 +6",choose_path.bind("sword"),row)
 game.button("选择法修 · 火弹伤害 +8",choose_path.bind("spell"),row)
 var upgrades:=HBoxContainer.new();upgrades.add_theme_constant_override("separation",12);col.add_child(upgrades)
 for pair in [["sword","御剑"],["fire","火弹"],["shield","护体"]]:
  var button: Button=game.button("研习"+pair[1],upgrade.bind(pair[0]),upgrades)
  button.custom_minimum_size=Vector2(210,52)
  var image:=Icon.new();image.item=pair[0];image.position=Vector2(10,8);image.size=Vector2(34,34);button.add_child(image)
 game.button("突破到下一层 · 静心台 / 室内蒲团旁",ascend,col)
 status=game.label("",16,Color("e2c58c"));status.custom_minimum_size=Vector2(740,70);status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;col.add_child(status)
 game.button("返回 · U / Esc",func():game.set_paused(false),col);popup.hide()
func open() -> void:
 game.set_paused(true);game.pause_panel.hide();popup.show();status.text="";render()
func render() -> void:
 var p=game.progress;var g=p.growth
 detail.text="境界：%s     修为：%d\n路线：%s（可免费切换）\n\n御剑 %d / %d   火弹 %d / %d   护体 %d / %d\n研习花费：御剑 %d、火弹 %d、护体 %d 修为\n\n"%[g.realm_name(p.realm),g.insight,{"":"尚未选择","sword":"剑修","spell":"法修"}[g.path],g.ranks.sword,mini(3,p.realm),g.ranks.fire,mini(3,p.realm),g.ranks.shield,mini(3,p.realm),25+25*g.ranks.sword,25+25*g.ranks.fire,25+25*g.ranks.shield]
 if p.realm==0:detail.text+="先到北面残卷学御剑，备齐 3 灵草、1 兽丹，在静心台 E 初次突破。"
 elif p.realm==1:detail.text+="突破二层：100 修为、6 灵草、3 兽丹。获得玄品飞剑 / 护符，可在 B 页对比后换上。"
 elif p.realm==2:detail.text+="突破三层：240 修为、6 灵铁、6 兽丹，并取得遗府传承。获得玄品法衣。"
 else:detail.text+="本阶段已到炼气三层。可继续研习功法、温养装备。"
 detail.text+="\n猎妖、完成炼制和蒲团修炼获得修为；突破与研习分别消耗。"
func accessible() -> bool:return popup.visible and game.paused
func choose_path(path: String) -> void:
 if not accessible() or path not in ["sword","spell"] or not game.progress.learned:return
 game.progress.growth.path=path;game.save_game(false);render();status.text="路线已切换。已有装备和功法等级保留。"
func upgrade(kind: String) -> void:
 if not accessible():return
 var ok: bool=game.progress.growth.upgrade(kind,game.progress)
 if ok:game.save_game(false);game.traveler.play_interaction("craft",game.traveler.position)
 render();status.text="功法已提升，实际伤害或护体强度增加。" if ok else "修为不足、已达当前境界上限，或尚未取得火弹传承。"
func ascend() -> void:
 if not accessible():return
 var near: bool=game.room.nearby("bed") if game.progress.inside_home else game.traveler.position.distance_to(game.valley.altar)<3
 if not near or game.adventure.in_combat():status.text="请到静心台或室内蒲团旁，脱战后再突破。";return
 var ok: bool=game.progress.growth.ascend(game.progress)
 if ok:
  game.save_game(false);game.traveler.play_interaction("craft",game.traveler.position);game.feedback.show_event("境界突破",game.progress.growth.realm_name(game.progress.realm),"core");game.effects.ring(game.traveler.position+Vector3.UP,Color("e4cf91"),1.2)
 render();status.text="突破成功！新装备已放入 B 装备页，可以一键穿戴推荐。" if ok else "检查修为、材料、传承，以及装备背包空位。未扣资源。"
