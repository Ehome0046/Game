extends Node3D
const C = preload("res://scripts/catalog.gd")
const Icon = preload("res://scripts/item_icon.gd")
var game: Node3D
var gear_panel: PanelContainer
var recipe_panel: PanelContainer
var stats: Label
var gear_detail: Label
var bag_grid: GridContainer
var equip_slots: VBoxContainer
var gear_buttons := {}
var selected := 0
var equip_button: Button
var salvage_button: Button
var sell_button: Button
var refine_button: Button
var promote_button: Button
var gear_filter := ""
var advanced: VBoxContainer
var upgrade_detail: Label
var equip_best_button: Button
var unequip_button: Button
var more_button: Button
var recipe_list: VBoxContainer
var recipe_detail: Label
var craft_button: Button
var station := "alchemy"
var chosen := "heal"
var active := false
var elapsed := 0.0
var duration := 5.0
var active_recipe := ""
var motion_clock := 0.0
var flame: MeshInstance3D
var station_targets := {"alchemy": Vector3(-5.4, 30.7, 2.6), "forge": Vector3(5.5, 30.8, 3)}
var stations := {"alchemy": Vector3(-5.4, 30, 1.2), "forge": Vector3(5.5, 30, 1.7)}

func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 build_stations()
 build_gear_panel()
 build_recipe_panel()

func build_stations() -> void:
 var v = game.valley
 var brass: Material = v.material("8c7b52")
 var at := Vector3(-5.4, 0, 2.6)
 v.box(at + Vector3.UP * 0.25, Vector3(1.5, 0.5, 1.4), v.stone, true, game.room)
 v.cylinder(at + Vector3.UP * 0.9, 0.52, 0.44, 0.85, brass, game.room)
 v.cylinder(at + Vector3.UP * 1.4, 0.13, 0.64, 0.22, brass, game.room)
 for x in [-0.65, 0.65]:
  v.box(at + Vector3(x, 1.0, 0), Vector3(0.2, 0.45, 0.22), brass, false, game.room)
 flame = v.cylinder(at + Vector3(0, 0.6, 0.5), 0.06, 0.16, 0.5, v.material("d78e4b", true), game.room)
 v.box(Vector3(5.5, 0.75, 3), Vector3(2.3, 0.18, 1.4), v.wood, true, game.room)
 for x in [4.6, 6.4]: v.box(Vector3(x, 0.35, 3), Vector3(0.2, 0.7, 1.1), v.wood, false, game.room)
 v.box(Vector3(5.5, 1.1, 3), Vector3(0.9, 0.6, 0.55), v.material("5f7476"), false, game.room)
 v.box(Vector3(6.2, 0.92, 2.8), Vector3(0.12, 0.12, 0.85), brass, false, game.room).rotation.y = 0.6
 game.room.point("alchemy", Vector3(-5.4, 0, 1.2), "丹炉 · 炼制药品")
 game.room.point("forge", Vector3(5.5, 0, 1.7), "炼器案 · 制作飞剑")
 game.room.sign_at("丹 炉 · E", at + Vector3.UP * 2.2)
 game.room.sign_at("炼 器 · E", Vector3(5.5, 2, 3))

func opaque(panel: PanelContainer) -> void:
 var style: StyleBoxFlat = panel.get_theme_stylebox("panel").duplicate()
 style.bg_color = Color("13231f")
 panel.add_theme_stylebox_override("panel", style)

func build_gear_panel() -> void:
 gear_panel = game.panel(Vector2(60,20),Vector2(1160,680))
 opaque(gear_panel)
 var column:=VBoxContainer.new();column.add_theme_constant_override("separation",8);gear_panel.add_child(column)
 column.add_child(game.label("装 备 · 选一件，看对比，再换上",27,Color("dfc997")))
 var filters:=HBoxContainer.new();filters.add_theme_constant_override("separation",12);column.add_child(filters)
 for pair in [["","全部装备"],["weapon","飞剑"],["robe","法衣"],["charm","护符"]]:game.button(pair[1],filter_gear.bind(pair[0]),filters).custom_minimum_size=Vector2(120,38)
 var row:=HBoxContainer.new();row.add_theme_constant_override("separation",24);column.add_child(row)
 var left:=VBoxContainer.new();left.custom_minimum_size.x=320;left.add_theme_constant_override("separation",8);row.add_child(left)
 stats=game.label("",17);left.add_child(stats)
 equip_slots=VBoxContainer.new();equip_slots.add_theme_constant_override("separation",8);left.add_child(equip_slots)
 var scroll:=ScrollContainer.new();scroll.custom_minimum_size=Vector2(740,240);scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;row.add_child(scroll)
 bag_grid=GridContainer.new();bag_grid.columns=1;bag_grid.add_theme_constant_override("v_separation",6);scroll.add_child(bag_grid)
 gear_detail=game.label("",17);gear_detail.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;gear_detail.custom_minimum_size=Vector2(1080,74);column.add_child(gear_detail)
 var actions:=HBoxContainer.new();actions.add_theme_constant_override("separation",10);column.add_child(actions)
 equip_button=game.button("换上这件",wear_selected,actions)
 unequip_button=game.button("卸下选中",unequip_selected,actions)
 equip_best_button=game.button("一键穿戴推荐",equip_best,actions)
 more_button=game.button("温养与整理 ▾",toggle_advanced,actions)
 game.button("返回 · B / Esc",func():game.set_paused(false),actions)
 for button in actions.get_children():button.custom_minimum_size.x=196
 advanced=VBoxContainer.new();advanced.add_theme_constant_override("separation",6);column.add_child(advanced)
 upgrade_detail=game.label("",15);upgrade_detail.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;upgrade_detail.custom_minimum_size=Vector2(1080,36);advanced.add_child(upgrade_detail)
 var extra:=HBoxContainer.new();extra.add_theme_constant_override("separation",10);advanced.add_child(extra)
 refine_button=game.button("温养 +1",refine_selected,extra);promote_button=game.button("提升品质",promote_selected,extra)
 salvage_button=game.button("分解选中",salvage_selected,extra);sell_button=game.button("卖给陆舟",sell_selected,extra)
 for button in extra.get_children():button.custom_minimum_size=Vector2(230,38)
 advanced.hide()
 column.add_child(game.label("已穿戴会单独标记；背包 60 件。突破获得进阶装备，原装备也能继续温养，无需强制更换。",15))
 gear_panel.hide()

func build_recipe_panel() -> void:
 recipe_panel = game.panel(Vector2(205, 28), Vector2(870, 660))
 opaque(recipe_panel)
 var column := VBoxContainer.new()
 column.add_theme_constant_override("separation", 14)
 recipe_panel.add_child(column)
 column.add_child(game.label("洞 府 工 坊 · 丹 方 与 制 作", 27, Color("dfc997")))
 var scroll := ScrollContainer.new()
 scroll.custom_minimum_size = Vector2(790, 185)
 column.add_child(scroll)
 recipe_list = VBoxContainer.new()
 recipe_list.custom_minimum_size.x = 775
 recipe_list.add_theme_constant_override("separation", 8)
 scroll.add_child(recipe_list)
 recipe_detail = game.label("", 18)
 recipe_detail.custom_minimum_size = Vector2(790, 140)
 recipe_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 column.add_child(recipe_detail)
 craft_button = game.button("开始炼制", start_chosen, column)
 game.button("返回房间", func(): game.set_paused(false), column)
 recipe_panel.hide()

func hide_panels() -> void:
 gear_panel.hide()
 recipe_panel.hide()

func clear_children(node: Node) -> void:
 for child in node.get_children():
  node.remove_child(child)
  child.queue_free()

func open_gear() -> void:
 if active:
  game.notify("正在炼制，先按 E 取消或等待完成。")
  return
 game.set_paused(true)
 game.pause_panel.hide()
 gear_panel.show()
 render_gear()

func gear_score(item: Dictionary) -> float:
 if item.is_empty():return -1
 var data: Dictionary=C.GEAR[item.id];var points: Dictionary=game.progress.expansion.gear_stats(item)
 match data.slot:
  "weapon":return points.attack*10
  "robe":return points.hp+points.armor*8
  _:return points.qi+points.attack*8

func filter_gear(slot: String) -> void:
 gear_filter=slot;render_gear()

func toggle_advanced() -> void:
 advanced.visible=not advanced.visible
 more_button.text="收起温养与整理 ▴" if advanced.visible else "温养与整理 ▾"

func render_gear() -> void:
 var p=game.progress;var state=p.expansion;var bonus: Dictionary=state.bonuses()
 stats.text="当前穿戴 / %s\n生命 %d  灵力 %d\n装备攻击 +%d  护甲 %d\n背包 %d / 60"%[p.growth.realm_name(p.realm),p.max_hp(),p.max_qi(),bonus.attack,bonus.armor,state.gear.size()]
 clear_children(equip_slots)
 for slot in C.SLOTS:
  var worn: Dictionary=state.find_gear(int(state.equipped[slot]))
  var title: String=C.GEAR[worn.id].name if not worn.is_empty() else "空位"
  var button: Button=game.button("      "+C.SLOT_NAMES[slot]+" · "+title,select_gear.bind(int(state.equipped[slot])),equip_slots)
  button.custom_minimum_size=Vector2(320,48);button.add_theme_font_size_override("font_size",16);button.disabled=worn.is_empty()
  var image:=Icon.new();image.item="sword" if slot=="weapon" else slot;image.position=Vector2(8,6);image.size=Vector2(34,34);button.add_child(image)
 clear_children(bag_grid);gear_buttons.clear()
 var visible_items: Array=state.gear.filter(func(item):return gear_filter.is_empty() or C.GEAR[item.id].slot==gear_filter)
 if not visible_items.any(func(item):return int(item.uid)==selected):selected=int(visible_items[0].uid) if not visible_items.is_empty() else 0
 for item in visible_items:
  var data: Dictionary=C.GEAR[item.id];var worn: bool=int(state.equipped[data.slot])==int(item.uid)
  var stat: Dictionary=state.gear_stats(item)
  var description: String=("攻击 +%d"%stat.attack) if data.slot=="weapon" else (("生命 +%d · 护甲 +%d"%[stat.hp,stat.armor]) if data.slot=="robe" else "灵力 +%d · 攻击 +%d"%[stat.qi,stat.attack])
  var button: Button=game.button("%s · %s +%d%s\n%s"%[data.name,C.QUALITY[data.quality],item.level," [已穿戴]" if worn else "",description],select_gear.bind(int(item.uid)),bag_grid)
  button.custom_minimum_size=Vector2(720,62);button.alignment=HORIZONTAL_ALIGNMENT_LEFT;button.add_theme_font_size_override("font_size",16);button.add_theme_color_override("font_color",Color(C.COLORS[data.quality]))
  for state_name in ["normal","hover","pressed","disabled"]:
   var style: StyleBoxFlat=button.get_theme_stylebox(state_name).duplicate()
   style.content_margin_left=60
   button.add_theme_stylebox_override(state_name,style)
  var image:=Icon.new();image.item="sword" if data.slot=="weapon" else data.slot;image.position=Vector2(10,12);image.size=Vector2(38,38);button.add_child(image)
  if selected==int(item.uid):button.add_theme_stylebox_override("normal",button.get_theme_stylebox("pressed"))
  gear_buttons[int(item.uid)]=button
 var item: Dictionary=state.find_gear(selected);var exists:=not item.is_empty();var worn:=selection_is_worn()
 equip_button.disabled=not exists or worn;equip_button.text="已穿戴" if worn else "换上这件"
 unequip_button.disabled=not worn
 salvage_button.disabled=not exists or worn;sell_button.disabled=not exists or not near_trader() or worn
 refine_button.disabled=not exists or not at_refiner() or not state.can_pay(state.refine_cost(selected),p)
 promote_button.disabled=not exists or not at_refiner() or not state.can_pay(state.promote_cost(selected),p)
 if exists:
  var data: Dictionary=C.GEAR[item.id];var selected_stats: Dictionary=state.gear_stats(item)
  var current: Dictionary=state.find_gear(int(state.equipped[data.slot]));var old: Dictionary=state.gear_stats(current) if not current.is_empty() else {"attack":0,"hp":0,"qi":0,"armor":0}
  gear_detail.text="选中：%s · %s · 温养 +%d%s\n换装对比："%[data.name,C.QUALITY[data.quality],item.level,"（当前已穿戴）" if worn else ""]
  for pair in [["attack","攻击"],["hp","生命"],["qi","灵力"],["armor","护甲"]]:
   var change: int=int(selected_stats[pair[0]])-int(old[pair[0]])
   if selected_stats[pair[0]] or old[pair[0]]:gear_detail.text+="%s %d → %d（%s%d）  "%[pair[1],old[pair[0]],selected_stats[pair[0]],"+" if change>=0 else "",change]
  upgrade_detail.text="温养：%s；升品：%s\n需在炼器案或陆舟旁；分解得 %d 灵铁，售价 %d 金币。已穿戴物品需先卸下。"%[cost_text(state.refine_cost(selected)),cost_text(state.promote_cost(selected)),1+int(data.quality),data.price]
 else:
  gear_detail.text="还没有这类装备。猎妖 / 宝箱获得，或突破获得进阶装备。\n取到装备后，选一件点“换上这件”，也可“一键穿戴推荐”。";upgrade_detail.text=""

func wear_selected() -> void:
 if not selection_is_worn():equip_selected()

func unequip_selected() -> void:
 if selection_is_worn():equip_selected()

func equip_best() -> void:
 if not gear_panel.visible or not game.paused:return
 var state=game.progress.expansion
 for slot in C.SLOTS:
  var best: Dictionary=state.find_gear(int(state.equipped[slot]))
  for item in state.gear:
   if C.GEAR[item.id].slot==slot and gear_score(item)>gear_score(best):best=item
  if not best.is_empty() and int(state.equipped[slot])!=int(best.uid):state.equip(int(best.uid),game.progress)
 game.apply_equipment();game.save_game(false);render_gear()
 game.feedback.show_event("推荐装备已穿戴","仍可手动选择其他装备。","robe")

func cost_text(cost: Dictionary) -> String:
 if cost.is_empty(): return "已到上限"
 var parts: Array[String] = []
 for item in cost: parts.append("%d%s" % [cost[item], C.NAMES[item]])
 return " + ".join(parts)

func at_refiner() -> bool:
 return near_trader() or (game.progress.inside_home and game.traveler.position.distance_to(stations.forge)<2.7)

func refine_selected() -> void:
 if not gear_panel.visible or not game.paused or not at_refiner(): return
 if game.progress.expansion.refine(selected, game.progress):
  game.apply_equipment()
  game.traveler.play_interaction("craft", game.traveler.position)
  game.save_game(false)
 render_gear()

func promote_selected() -> void:
 if not gear_panel.visible or not game.paused or not at_refiner(): return
 if game.progress.expansion.promote(selected, game.progress):
  game.apply_equipment()
  game.traveler.play_interaction("craft", game.traveler.position)
  game.save_game(false)
 render_gear()

func select_gear(uid: int) -> void:
 selected = uid
 var item: Dictionary = game.progress.expansion.find_gear(uid)
 if not item.is_empty() and not gear_filter.is_empty(): gear_filter = C.GEAR[item.id].slot
 render_gear()

func near_trader() -> bool:
 return not game.progress.inside_home and game.traveler.position.distance_to(Vector3(7, 0, 28)) < 3.2

func equip_selected() -> void:
 if not gear_panel.visible or not game.paused: return
 if game.progress.expansion.equip(selected, game.progress):
  game.apply_equipment()
  game.traveler.play_interaction("equip", game.traveler.position)
  game.save_game(false)
  render_gear()

func selection_is_worn() -> bool:
 var item: Dictionary = game.progress.expansion.find_gear(selected)
 return not item.is_empty() and int(game.progress.expansion.equipped[C.GEAR[item.id].slot]) == selected

func salvage_selected() -> void:
 if not gear_panel.visible or not game.paused: return
 if selection_is_worn(): return
 if game.progress.expansion.remove(selected, game.progress):
  game.apply_equipment()
  game.save_game(false)
  render_gear()

func sell_selected() -> void:
 if not gear_panel.visible or not game.paused or not near_trader(): return
 if selection_is_worn(): return
 if game.progress.expansion.remove(selected, game.progress, true):
  game.apply_equipment()
  game.save_game(false)
  render_gear()

func near_station() -> bool:
 return game.progress.inside_home and game.traveler.position.distance_to(stations[station]) < 2.7

func open_recipe(kind: String) -> void:
 if active or kind not in stations: return
 station = kind
 if not near_station(): return
 chosen = "iron_blade" if station == "forge" else "heal"
 game.set_paused(true)
 game.pause_panel.hide()
 recipe_panel.show()
 render_recipe()

func select_recipe(id: String) -> void:
 chosen = id
 render_recipe()

func render_recipe() -> void:
 clear_children(recipe_list)
 var p = game.progress
 for id in C.RECIPES:
  if C.RECIPES[id].station != station: continue
  var known: bool = id in p.expansion.recipes
  game.button(("◆ " if id == chosen else "") + C.RECIPES[id].name + ("" if known else " [未获得配方]"), select_recipe.bind(id), recipe_list)
 var recipe: Dictionary = C.RECIPES[chosen]
 var owned: Array[String] = []
 for item in recipe.cost: owned.append("%s %d" % [C.NAMES[item], p.item_count(item)])
 recipe_detail.text = "材料：" + C.recipe_cost(chosen) + "\n随身：" + " · ".join(owned) + "\n过程：%d 秒，完成时结算；E 或移动取消，不扣材料。" % recipe.seconds
 recipe_detail.text += "\n制作熟练 %d 批 · 三批解锁凝元丹。" % p.expansion.batches
 if chosen not in p.expansion.recipes:
  recipe_detail.text += {"iron_blade":"\n图谱藏在青石矿洞宝箱。", "focus":"\n丹方藏在望月秘境宝箱。", "ward":"\n击败望月守卫后领悟护元丹方。", "elixir":"\n完成三次制作后，自动领悟凝元丹方。"}.get(chosen, "")
 elif chosen == "ward": recipe_detail.text += "\n7 使用：游玩 180 秒护甲 +3，已有药效时不消耗。"
 elif chosen == "elixir": recipe_detail.text += "\n8 使用：生命与灵力全恢复；全满时不消耗。"
 elif chosen == "focus": recipe_detail.text += "\n聚气丹：按 6 使用，游玩 120 秒内伤害 +8，已有药效时不消耗。"
 craft_button.disabled = not p.expansion.can_craft(chosen, p)
 craft_button.text = "开始制作" if station == "forge" else "开始炼丹"

func start_chosen() -> void:
 if not recipe_panel.visible or not game.paused or not near_station() or not game.progress.expansion.can_craft(chosen, game.progress): return
 game.set_paused(false)
 game.room.stop_rest()
 active_recipe = chosen
 duration = C.RECIPES[chosen].seconds
 elapsed = 0
 active = true
 motion_clock = 0
 game.traveler.busy = true
 game.traveler.invincible = 0
 game.traveler.play_interaction("craft", station_targets[station])
 game.notify("开始%s，完成后结算材料；E 或移动取消。" % C.RECIPES[chosen].name)

func cancel(feedback := true) -> void:
 active = false
 game.traveler.busy = false
 flame.scale = Vector3.ONE
 if feedback: game.notify("炼制已取消，材料保留。")

func _process(delta: float) -> void:
 if not active or not game.playing or game.paused: return
 if not near_station() or Input.get_vector("left", "right", "forward", "back").length_squared() > 0.1:
  cancel()
  return
 elapsed += delta
 motion_clock -= delta
 flame.scale.y = 1.0 + sin(elapsed * 7) * 0.18
 if motion_clock <= 0:
  motion_clock = 0.8
  game.traveler.play_interaction("craft", station_targets[station])
  game.effects.ring(station_targets[station] + Vector3.UP * 0.4, Color("dab881"), 0.35)
 if elapsed >= duration:
  active = false
  game.traveler.busy = false
  flame.scale = Vector3.ONE
  if game.progress.expansion.craft(active_recipe, game.progress):
   game.notify("制作完成：" + C.RECIPES[active_recipe].name + "。成品已收入背包，可自用或到坊市出售。")
   game.apply_equipment()
   game.save_game(false)
  else: game.notify("材料或背包空间不足，未扣除材料。")
