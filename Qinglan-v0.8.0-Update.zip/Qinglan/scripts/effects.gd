extends Node3D
## Small CPU effects for the compatibility renderer; no large textures or GPU particles.

signal hit_confirmed(damage: float)
var shots: Array[Dictionary] = []
var sparks: Array[Dictionary] = []
var rings: Array[Dictionary] = []
var numbers: Array[Dictionary] = []
var flashes: Array[Dictionary] = []
var trails: Array[Dictionary] = []
var orbit: Node3D
var weapon_id := ""
var blade_color := Color("e5f3ef")
var weapon_scale := 1.0
var orbit_time := 0.0
var random := RandomNumberGenerator.new()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	random.seed = 8421

func material(color: Color, transparent := false) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	if transparent:
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return mat

func mesh_node(mesh: Mesh, mat: Material, parent: Node3D) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.material_override = mat
	node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(node)
	return node

func box(size: Vector3, at: Vector3, mat: Material, parent: Node3D) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := mesh_node(mesh, mat, parent)
	node.position = at
	return node

func blade_mesh() -> ArrayMesh:
	var points := [Vector3(-0.075, 0, 0.25), Vector3(0.075, 0, 0.25),
		Vector3(0.075, 0, -0.65), Vector3(0, 0, -0.92), Vector3(-0.075, 0, -0.65)]
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for height in [-0.024, 0.024]:
		for triangle in [[0, 1, 2], [0, 2, 3], [0, 3, 4]]:
			for i in triangle:
				surface.add_vertex(points[i] + Vector3.UP * height)
	for i in range(5):
		var a: Vector3 = points[i]
		var b: Vector3 = points[(i + 1) % 5]
		for vertex in [a + Vector3.UP * 0.024, b + Vector3.UP * 0.024, b - Vector3.UP * 0.024,
			a + Vector3.UP * 0.024, b - Vector3.UP * 0.024, a - Vector3.UP * 0.024]:
			surface.add_vertex(vertex)
	surface.generate_normals()
	return surface.commit()

func make_sword(parent: Node3D, combo: int) -> Node3D:
	var body := Node3D.new()
	parent.add_child(body)
	mesh_node(blade_mesh(), material(blade_color), body)
	box(Vector3(0.36, 0.07, 0.10), Vector3(0, 0, 0.28), material(Color("d7b77a")), body)
	box(Vector3(0.08, 0.08, 0.32), Vector3(0, 0, 0.48), material(Color("476d61")), body)
	box(Vector3(0.03, 0.035, 0.98), Vector3(0, 0.03, -0.28), material(Color("b4efdb")), body)
	body.scale = Vector3.ONE * weapon_scale * (1.15 if combo == 2 else 1.0)
	return body

func set_weapon(id: String) -> void:
	if weapon_id == id: return
	weapon_id = id
	var catalog = preload("res://scripts/catalog.gd")
	blade_color = Color(catalog.COLORS[catalog.GEAR[id].quality]) if catalog.GEAR.has(id) else Color("e5f3ef")
	weapon_scale = 1.0 + (float(catalog.GEAR[id].quality) * 0.08 if catalog.GEAR.has(id) else 0.0)
	if is_instance_valid(orbit):
		orbit.queue_free()
		orbit = null

func update_orbit(at: Vector3, facing: float, learned: bool, delta: float) -> void:
	orbit_time += delta
	if not learned:
		if is_instance_valid(orbit):
			orbit.hide()
		return
	if not is_instance_valid(orbit):
		orbit = make_sword(self, 0)
	orbit.visible = shots.is_empty()
	orbit.position = at + Vector3(0.64, 1.35 + sin(orbit_time * 2.1) * 0.06, 0.25).rotated(Vector3.UP, facing)
	orbit.rotation = Vector3(PI / 2, facing, 0.12 + sin(orbit_time * 1.4) * 0.04)

func launch(kind: String, start: Vector3, target: Node3D, combo: int, impact: Callable) -> void:
	if shots.size() >= 12:
		# This limit is above the player's cast rate; avoid dropping gameplay callbacks.
		impact.call()
		return
	if kind == "sword" and is_instance_valid(orbit) and orbit.visible:
		start = orbit.position
		orbit.hide()
	var body := make_sword(self, combo) if kind == "sword" else Node3D.new()
	if kind != "sword":
		add_child(body)
	body.position = start
	var color := Color("f8bf73") if kind == "fire" else Color("a9edd9")
	if kind != "sword":
		var ball := SphereMesh.new()
		ball.radius = 0.22
		ball.height = 0.44
		ball.radial_segments = 12
		ball.rings = 6
		mesh_node(ball, material(color), body)
		var halo := mesh_node(ball, material(Color(0.95, 0.5, 0.2, 0.2), true), body)
		halo.scale = Vector3.ONE * 1.6
	var ribbon := ImmediateMesh.new()
	var ribbon_mat := material(Color.WHITE, true)
	ribbon_mat.vertex_color_use_as_albedo = true
	var trail := mesh_node(ribbon, ribbon_mat, self)
	shots.append({"node": body, "target": weakref(target), "start": start, "age": 0.0,
		"life": 0.36 if kind == "fire" else 0.23, "kind": kind, "combo": combo,
		"points": [start], "ribbon": ribbon, "trail": trail, "color": color, "impact": impact})
	ring(start, color, 0.28)

func draw_ribbon(mesh: ImmediateMesh, points: Array, width: float, color: Color) -> void:
	mesh.clear_surfaces()
	if points.size() < 2:
		return
	mesh.surface_begin(Mesh.PRIMITIVE_TRIANGLES)
	for axis in [Vector3.UP, Vector3.RIGHT]:
		for i in range(1, points.size()):
			var direction: Vector3 = points[i] - points[i - 1]
			var side: Vector3 = direction.normalized().cross(axis)
			if side.length_squared() < 0.001:
				continue
			side = side.normalized() * width * float(i) / points.size()
			var tint := color
			tint.a = float(i) / points.size() * 0.65
			for vertex in [points[i - 1] - side, points[i - 1] + side, points[i] + side,
				points[i - 1] - side, points[i] + side, points[i] - side]:
				mesh.surface_set_color(tint)
				mesh.surface_add_vertex(vertex)
	mesh.surface_end()

func impact(at: Vector3, damage: float, kind: String, victim: Node3D) -> void:
	hit_confirmed.emit(damage)
	var color := Color("ffd08a") if kind == "fire" else Color("b4efdb")
	burst(at, color, 14 if kind == "fire" else 10)
	var wave := ring(at, color, 0.7)
	var camera := get_viewport().get_camera_3d()
	if camera != null:
		wave.quaternion = Quaternion(Vector3.UP, (camera.global_position - at).normalized())
	var label := Label3D.new()
	label.text = "−%d" % roundi(damage)
	label.font_size = 44
	label.pixel_size = 0.008
	label.outline_size = 6
	label.modulate = color
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	add_child(label)
	label.position = at + Vector3(0, 0.65, 0) + (camera.global_basis.x * 0.45 if camera != null else Vector3.RIGHT * 0.45)
	numbers.append({"node": label, "age": 0.0, "life": 0.7})
	var meshes: Array[Dictionary] = []
	for child in victim.find_children("*", "MeshInstance3D", true, false):
		if child is MeshInstance3D:
			meshes.append({"node": child, "previous": child.material_overlay})
			child.material_overlay = material(Color(color.r, color.g, color.b, 0.55), true)
	flashes.append({"meshes": meshes, "age": 0.0})

func burst(at: Vector3, color: Color, count: int) -> void:
	for i in range(count):
		if sparks.size() >= 112:
			break
		var shard := box(Vector3(0.035, 0.035, 0.16), Vector3.ZERO, material(color), self)
		shard.position = at
		shard.rotation = Vector3(random.randf() * TAU, random.randf() * TAU, random.randf() * TAU)
		var velocity := Vector3(random.randf_range(-1, 1), random.randf_range(-0.2, 1.3), random.randf_range(-1, 1)).normalized() * random.randf_range(1.4, 3.5)
		sparks.append({"node": shard, "velocity": velocity, "age": 0.0, "life": random.randf_range(0.25, 0.5)})

func ring(at: Vector3, color: Color, radius: float) -> MeshInstance3D:
	var mesh := TorusMesh.new()
	mesh.inner_radius = radius * 0.85
	mesh.outer_radius = radius
	mesh.rings = 16
	mesh.ring_segments = 6
	var node := mesh_node(mesh, material(Color(color.r, color.g, color.b, 0.65), true), self)
	node.position = at
	rings.append({"node": node, "age": 0.0, "life": 0.35})
	return node

func footstep(at: Vector3, running: bool) -> void:
	for i in range(3):
		if sparks.size() >= 112:
			return
		var dust := box(Vector3(0.09, 0.04, 0.09), Vector3.ZERO, material(Color("939882")), self)
		dust.position = at
		sparks.append({"node": dust, "velocity": Vector3(random.randf_range(-0.3, 0.3), 0.35, random.randf_range(-0.3, 0.3)) * (1.4 if running else 1.0), "age": 0.0, "life": 0.28})

func _process(delta: float) -> void:
	for i in range(shots.size() - 1, -1, -1):
		var shot := shots[i]
		shot.age += delta
		var target = shot.target.get_ref()
		if not is_instance_valid(target):
			shot.node.queue_free()
			shot.trail.queue_free()
			shots.remove_at(i)
			continue
		var destination: Vector3 = target.global_position + Vector3.UP
		var t: float = clampf(shot.age / shot.life, 0, 1)
		var offset := Vector3.UP * sin(t * PI) * (0.45 if shot.kind == "sword" else 0.15)
		var side: Vector3 = (destination - shot.start).normalized().cross(Vector3.UP).normalized()
		offset += side * sin(t * PI) * (0.7 if shot.combo % 2 == 0 else -0.7)
		shot.node.position = shot.start.lerp(destination, t) + offset
		var toward: Vector3 = destination - shot.node.position
		if toward.length_squared() > 0.0001:
			shot.node.look_at(shot.node.position + toward, Vector3.RIGHT if toward.normalized().cross(Vector3.UP).length_squared() < 0.001 else Vector3.UP)
		shot.points.append(shot.node.position)
		if shot.points.size() > 10:
			shot.points.pop_front()
		draw_ribbon(shot.ribbon, shot.points, 0.13 if shot.kind == "fire" else 0.10, shot.color)
		if t >= 1:
			shot.node.queue_free()
			trails.append({"node": shot.trail, "age": 0.0})
			shots.remove_at(i)
			shot.impact.call()
	for i in range(sparks.size() - 1, -1, -1):
		var spark := sparks[i]
		spark.age += delta
		spark.velocity.y -= delta * 2
		spark.node.position += spark.velocity * delta
		spark.node.scale = Vector3.ONE * maxf(0.01, 1 - spark.age / spark.life)
		if spark.age >= spark.life:
			spark.node.queue_free()
			sparks.remove_at(i)
	for i in range(rings.size() - 1, -1, -1):
		var effect := rings[i]
		effect.age += delta
		effect.node.scale = Vector3.ONE * (0.5 + effect.age * 3)
		effect.node.material_override.albedo_color.a = maxf(0, 0.65 * (1 - effect.age / effect.life))
		if effect.age >= effect.life:
			effect.node.queue_free()
			rings.remove_at(i)
	for i in range(numbers.size() - 1, -1, -1):
		var number := numbers[i]
		number.age += delta
		number.node.position.y += delta * 0.9
		number.node.modulate.a = maxf(0, 1 - number.age / number.life)
		if number.age >= number.life:
			number.node.queue_free()
			numbers.remove_at(i)
	for i in range(trails.size() - 1, -1, -1):
		var trail := trails[i]
		trail.age += delta
		trail.node.material_override.albedo_color.a = maxf(0, 1 - trail.age / 0.16)
		if trail.age >= 0.16:
			trail.node.queue_free()
			trails.remove_at(i)
	for i in range(flashes.size() - 1, -1, -1):
		flashes[i].age += delta
		if flashes[i].age >= 0.10:
			for mesh in flashes[i].meshes:
				if is_instance_valid(mesh.node):
					mesh.node.material_overlay = mesh.previous
			flashes.remove_at(i)

func clear() -> void:
	for flash in flashes:
		for mesh in flash.meshes:
			if is_instance_valid(mesh.node):
				mesh.node.material_overlay = mesh.previous
	for child in get_children():
		child.queue_free()
	shots.clear()
	sparks.clear()
	rings.clear()
	numbers.clear()
	flashes.clear()
	trails.clear()
	orbit = null
