extends Node3D
const F=preload("res://scripts/furnishing_rules.gd")
var game: Node3D
var editing := false
var camera: Camera3D
var grid: MeshInstance3D
var catalog_panel: PanelContainer
var toolbar: PanelContainer
var info_panel: PanelContainer
var info: Label
var inventory_list: VBoxContainer
var placed_list: VBoxContainer
var ghost: MeshInstance3D
var ghost_mat: StandardMaterial3D
var models := {}
var selected_kind := ""
var selected_uid := 0
var turn := 0
var cursor := Vector2.ZERO
var valid := false
var preview_key := ""
var tabs: TabContainer

func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 camera=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=24;camera.position=Vector3(0,46,0);camera.rotation.x=-PI/2;add_child(camera)
 grid=MeshInstance3D.new();add_child(grid)
 var vertices:=PackedVector3Array()
 for x in range(-15,16):
  vertices.append(Vector3(x*0.5,30.03,-8.5));vertices.append(Vector3(x*0.5,30.03,8.5))
 for z in range(-17,18):
  vertices.append(Vector3(-7.5,30.03,z*0.5));vertices.append(Vector3(7.5,30.03,z*0.5))
 var arrays:=[];arrays.resize(Mesh.ARRAY_MAX);arrays[Mesh.ARRAY_VERTEX]=vertices
 var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_LINES,arrays);grid.mesh=mesh
 var mat: StandardMaterial3D=game.valley.material("9db5a3",true);mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;mat.albedo_color.a=0.35;mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;grid.material_override=mat;grid.hide()
 ghost=MeshInstance3D.new();add_child(ghost);ghost.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
 ghost_mat=StandardMaterial3D.new();ghost_mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA;ghost_mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;ghost.material_override=ghost_mat;ghost.hide()
 catalog_panel=game.panel(Vector2(16,90),Vector2(280,600))
 var col:=VBoxContainer.new();col.add_theme_constant_override("separation",10);catalog_panel.add_child(col)
 col.add_child(game.label("洞 府 布 置",26,Color("dfc997")))
 tabs=TabContainer.new();tabs.custom_minimum_size=Vector2(224,445);col.add_child(tabs)
 for title in ["家具","已摆放"]:
  var scroll:=ScrollContainer.new();scroll.name=title;scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED;tabs.add_child(scroll)
  var list:=VBoxContainer.new();list.custom_minimum_size.x=208;list.add_theme_constant_override("separation",8);scroll.add_child(list)
  if title=="家具": inventory_list=list
  else: placed_list=list
 game.button("买入所选家具",buy_selected,col)
 toolbar=game.panel(Vector2(312,16),Vector2(940,68))
 var toolbar_style: StyleBoxFlat=toolbar.get_theme_stylebox("panel").duplicate()
 toolbar_style.content_margin_top=12;toolbar_style.content_margin_bottom=12
 toolbar.add_theme_stylebox_override("panel",toolbar_style)
 var row:=HBoxContainer.new();row.add_theme_constant_override("separation",12);toolbar.add_child(row)
 game.button("旋转 R",rotate_preview,row)
 game.button("收回 Delete",collect_selected,row)
 game.button("取消选中 / 右键",cancel_preview,row)
 game.button("完成布置 · Esc",func():game.set_paused(false),row)
 info_panel=game.panel(Vector2(936,126),Vector2(316,500))
 info=game.label("",16);info.custom_minimum_size.x=260;info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;info_panel.add_child(info)
 hide_panels()

func hide_panels() -> void:
 catalog_panel.hide();toolbar.hide();info_panel.hide()

func open_editor() -> bool:
 if not game.progress.inside_home or game.workshop.active:
  game.notify("进入自己的洞府后，按 P 开始自由布置；先结束炼制。")
  return false
 game.room.stop_rest();game.set_paused(true);game.pause_panel.hide()
 editing=true
 for part in game.room.ceiling_parts: part.hide()
 camera.make_current();grid.show()
 catalog_panel.show();toolbar.show();info_panel.show();rebuild_lists();cancel_preview()
 return true

func close_editor() -> void:
 if not editing: return
 editing=false
 for part in game.room.ceiling_parts: part.show()
 game.traveler.camera.make_current();grid.hide();ghost.hide();hide_panels();selected_kind="";selected_uid=0
 keep_player_clear()

func keep_player_clear() -> void:
 if not game.progress.inside_home: return
 var at:=Vector2(game.traveler.position.x,game.traveler.position.z)
 for item in game.progress.journey.layout:
  if F.KINDS[item.kind].solid and F.rect(item).grow(0.4).has_point(at):
   game.traveler.position=game.room.OFFSET+game.room.ENTRY;game.traveler.velocity=Vector3.ZERO
   return

func rebuild_lists() -> void:
 for list in [inventory_list,placed_list]:
  for child in list.get_children(): list.remove_child(child);child.queue_free()
 var s=game.progress.journey
 for kind in F.STOCK:
  var data: Dictionary=F.KINDS[kind]
  var currency: String="贡献" if data.get("sect",false) else "金币"
  var b: Button=game.button("%s ×%d\n%d %s"%[data.name,s.stock[kind],data.price,currency],choose.bind(kind,0),inventory_list)
  b.custom_minimum_size=Vector2(208,58);b.add_theme_font_size_override("font_size",16)
 for item in s.layout:
  var b: Button=game.button("%s #%d\n移动 / 旋转"%[F.KINDS[item.kind].name,item.uid],choose.bind(item.kind,int(item.uid)),placed_list)
  b.custom_minimum_size=Vector2(208,58);b.add_theme_font_size_override("font_size",16)

func choose(kind: String,uid: int) -> void:
 if not editing or not F.KINDS.has(kind): return
 selected_kind=kind;selected_uid=uid;turn=0;preview_key=""
 if uid:
  for item in game.progress.journey.layout:
   if int(item.uid)==uid: turn=int(item.turn)
 var box:=BoxMesh.new();box.size=Vector3(F.KINDS[kind].size.x,F.KINDS[kind].height,F.KINDS[kind].size.y);ghost.mesh=box;ghost.show()
 refresh_preview(true)

func cancel_preview() -> void:
 selected_kind="";selected_uid=0;ghost.hide();valid=false
 info.text="选择家具后，在地板上移动鼠标，左键放置。点击已有家具可移动；R 旋转，右键取消。\n\n绿色可放，红色表示重叠、挡门或堵住功能区。\n\n0.5 米吸附；P / Esc 完成。\n\n普通陈设用金币添置；入门后可用贡献换云屏与灯架。"

func rotate_preview() -> void:
 if not editing or selected_kind.is_empty(): return
 turn=(turn+1)%4;preview_key="";refresh_preview(true)

func candidate(at: Vector2) -> Array:
 var next: Array=game.progress.journey.layout.duplicate(true)
 if selected_uid:
  for item in next:
   if int(item.uid)==selected_uid: item.x=at.x;item.z=at.y;item.turn=turn
 else: next.append({"uid":game.progress.journey.next_furniture,"kind":selected_kind,"x":at.x,"z":at.y,"turn":turn})
 return next

func refresh_preview(force := false, mouse := Vector2.INF) -> void:
 if selected_kind.is_empty(): return
 if not mouse.is_finite(): mouse=get_viewport().get_mouse_position()
 var ray:=camera.project_ray_origin(mouse);var direction:=camera.project_ray_normal(mouse)
 var at:=ray+direction*((30.05-ray.y)/direction.y)
 cursor=Vector2(snappedf(at.x,0.5),snappedf(at.z,0.5))
 var key: String="%s/%d/%s"%[cursor,turn,selected_kind]
 if not force and key==preview_key: return
 preview_key=key
 valid=F.valid_layout(candidate(cursor)) and (selected_uid!=0 or game.progress.journey.stock.get(selected_kind,0)>0)
 ghost.position=Vector3(cursor.x,30.08+F.KINDS[selected_kind].height/2,cursor.y);ghost.rotation.y=turn*PI/2
 ghost_mat.albedo_color=Color(0.35,0.85,0.6,0.38) if valid else Color(0.9,0.3,0.25,0.42)
 var s=game.progress.journey
 info.text="%s · %s · 朝向 %d°\n坐标 %.1f, %.1f\n\n金币 %d\n宗门贡献 %d\n库存 %d\n\n左键确认，R 旋转，右键取消。\n\n箱子与蒲团只能移动，不能收回。"%[F.KINDS[selected_kind].name,"可放置" if valid else "此处不可放 / 库存不足",turn*90,cursor.x,cursor.y,game.progress.coins,s.contribution,s.stock.get(selected_kind,0)]

func commit_at(at: Vector2) -> bool:
 if not editing or selected_kind.is_empty(): return false
 var ok: bool=game.progress.journey.place(selected_kind,at,turn,selected_uid)
 if ok:
  game.traveler.play_interaction("craft",game.room.OFFSET+Vector3(at.x,0,at.y));restore();game.save_game(false);rebuild_lists();cancel_preview()
 return ok

func buy_selected() -> void:
 if not editing or selected_kind.is_empty() or selected_uid: return
 var kind:=selected_kind
 if game.progress.journey.buy_furniture(kind,game.progress):
  game.traveler.play_interaction("trade",game.traveler.position);game.save_game(false);rebuild_lists();preview_key="";refresh_preview(true)
 else: info.text="购买失败：金币 / 贡献不足、库存已满，或尚未成为外门弟子。已有家具与材料保留。"

func collect_selected() -> void:
 if not editing or not selected_uid: return
 if game.progress.journey.collect_furniture(selected_uid):
  game.traveler.play_interaction("craft",game.traveler.position);restore();game.save_game(false);rebuild_lists();cancel_preview()
 else: info.text="箱子与蒲团需留在洞府；其他家具可收回库存。库存已满时不会丢失家具。"

func handle_event(event: InputEvent) -> bool:
 if not editing: return false
 if event is InputEventKey and event.pressed and not event.echo:
  if event.physical_keycode==KEY_R or event.keycode==KEY_R: rotate_preview();return true
  if event.physical_keycode==KEY_DELETE or event.keycode==KEY_DELETE: collect_selected();return true
 if event is InputEventMouseButton and event.pressed:
  if event.button_index==MOUSE_BUTTON_RIGHT: cancel_preview();return true
  if event.button_index!=MOUSE_BUTTON_LEFT: return false
  for panel in [catalog_panel,toolbar,info_panel]:
   if panel.get_global_rect().has_point(event.position): return false
  if not selected_kind.is_empty():
   refresh_preview(true,event.position)
   if valid: commit_at(cursor)
   return true
  var ray:=camera.project_ray_origin(event.position)
  for item in game.progress.journey.layout:
   if F.rect(item).has_point(Vector2(ray.x,ray.z)):
    choose(item.kind,int(item.uid));tabs.current_tab=1;return true
 return false

func model_for(kind: String) -> Node3D:
 var v=game.valley
 var root:=Node3D.new();game.room.add_child(root)
 var wood: Material=v.material("70583d")
 var cloth: Material=v.material("577b6c" if not kind.begins_with("sect") else "537e94")
 if kind=="bench" or kind=="table":
  var height: float=0.62 if kind=="bench" else 0.82
  var width: float=1.4 if kind=="bench" else 1.8
  var depth: float=0.7 if kind=="bench" else 1.2
  v.box(Vector3(0,height,0),Vector3(width,0.14,depth),wood,true,root)
  for x in [-width*0.38,width*0.38]:
   for z in [-depth*0.32,depth*0.32]: v.box(Vector3(x,height/2,z),Vector3(0.12,height,0.12),wood,false,root)
  if kind=="table":
   v.cylinder(Vector3(-0.3,0.97,0),0.15,0.18,0.22,v.material("99b6a7"),root)
   for x in [0.15,0.48]: v.cylinder(Vector3(x,0.94,0),0.08,0.05,0.13,v.material("c0b188"),root)
 elif kind in ["screen","sect_screen"]:
  for x in [-1.05,0,1.05]: v.box(Vector3(x,1.2,0),Vector3(0.09,2.4,0.12),wood,true,root)
  v.box(Vector3(0,1.3,0),Vector3(2.1,1.8,0.06),cloth,true,root)
  for y in [0.35,2.25]: v.box(Vector3(0,y,0),Vector3(2.3,0.1,0.12),wood,false,root)
  for x in [-0.7,0,0.7]:
   var peak: MeshInstance3D=v.box(Vector3(x,1.2, -0.04),Vector3(0.5,0.5,0.025),v.material("a7bb9d"),false,root);peak.rotation.z=PI/4
 elif kind in ["lamp","sect_lamp"]:
  v.box(Vector3(0,0.08,0),Vector3(0.55,0.16,0.55),wood,true,root)
  v.cylinder(Vector3.UP*0.85,0.055,0.08,1.5,wood,root)
  var paper: Material=v.material("d8bc7b" if kind=="lamp" else "90c8cc",true)
  v.cylinder(Vector3.UP*1.65,0.25,0.22,0.6,paper,root)
  for y in [1.32,1.98]: v.cylinder(Vector3.UP*y,0.28,0.28,0.06,wood,root)
 elif kind=="plant":
  v.cylinder(Vector3.UP*0.3,0.3,0.22,0.6,v.material("7b8a76"),root)
  for i in range(4):
   var stem: MeshInstance3D=v.cylinder(Vector3((i-1.5)*0.09,1,0),0.025,0.04,1.4,v.leaf,root);stem.rotation.z=(i-1.5)*0.12
   for y in [0.9,1.3]: v.box(Vector3((i-1.5)*0.13,y,0),Vector3(0.4,0.04,0.15),v.material("6d996d"),false,root).rotation.y=i
 elif kind=="rug":
  v.box(Vector3(0,0.025,0),Vector3(1.95,0.035,1.45),cloth,false,root)
  for x in [-0.85,0.85]: v.box(Vector3(x,0.045,0),Vector3(0.04,0.01,1.3),v.material("c2ad79"),false,root)
 return root

func restore() -> void:
 for model in models.values(): model.queue_free()
 models.clear()
 for item in game.progress.journey.layout:
  var node: Node3D
  if item.kind=="cushion": node=game.room.cushion_group
  elif item.kind=="chest": node=game.room.chest_group
  else:
   node=model_for(item.kind);models[int(item.uid)]=node
  node.position=Vector3(item.x,0.15 if item.kind=="cushion" else 0,item.z);node.rotation.y=int(item.turn)*PI/2
 game.room.update_anchors()
 for node in models.values():
  for shape in node.find_children("*","CollisionShape3D",true,false): shape.set_deferred("disabled",not game.progress.inside_home)
 keep_player_clear()

func _process(_delta: float) -> void:
 if editing: refresh_preview()
