extends SceneTree
const Game=preload("res://scripts/game.gd")
const P=preload("res://scripts/progress.gd")
var checks:=0
var failures:=0
var capture_dir:=""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):capture_dir=arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func check(ok: bool,text: String) -> void:
 checks+=1
 if ok:print("PASS: "+text)
 else:failures+=1;push_error("FAIL: "+text)
func frames(n: int) -> void:
 for i in range(n):await physics_frame
func capture(name: String) -> void:
 if capture_dir.is_empty():return
 await process_frame;await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func key(code: Key) -> void:
 var e:=InputEventKey.new();e.keycode=code;e.physical_keycode=code;e.pressed=true;root.push_input(e,true)
func click(at: Vector2) -> void:
 var e:=InputEventMouseButton.new();e.position=at;e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;root.push_input(e,true);e=e.duplicate();e.pressed=false;root.push_input(e,true)
func run() -> void:
 var game=Game.new();root.add_child(game);game.begin_new();await frames(3)
 check(not game.furnishings.open_editor() and not game.paused,"furniture editor is only available inside owned room")
 game.progress.claim_home();game.traveler.position=game.adventure.HOME;game.interact();await frames(4)
 var p=game.progress;var s=p.journey
 key(KEY_P);await frames(3)
 check(game.furnishings.editing and game.paused and game.furnishings.camera.current and not game.room.roof.visible,"P opens overhead cutaway editor while pausing gameplay")
 check(game.furnishings.inventory_list.get_child_count()==8 and s.stock.bench==1,"old and new homeowners receive a finite initial furniture stock")
 var button: Button=game.furnishings.inventory_list.get_child(0)
 click(button.get_global_rect().get_center());await frames(2)
 check(game.furnishings.selected_kind=="bench" and game.furnishings.ghost.visible,"real catalog click selects a furniture preview")
 var snapshot: Dictionary=s.snapshot()
 check(not game.furnishings.commit_at(Vector2(0,6)) and s.snapshot()==snapshot,"placement cannot block exit corridor or consume stock on failure")
 check(not game.furnishings.commit_at(Vector2(-3.4,-2.4)) and s.snapshot()==snapshot,"overlap with cushion is rejected without spending furniture")
 check(not game.furnishings.commit_at(Vector2(8,8)) and s.snapshot()==snapshot,"out-of-room placement is rejected")
 check(game.furnishings.commit_at(Vector2(-5.5,5.5)) and s.stock.bench==0 and s.layout.size()==3,"confirmed placement consumes exactly one owned bench")
 var bench_uid: int=s.layout.back().uid
 check(game.furnishings.models.has(bench_uid) and game.furnishings.models[bench_uid].find_children("*","CollisionShape3D",true,false).size()>0,"placed solid furniture has real collision geometry")
 game.furnishings.choose("bench",bench_uid);key(KEY_R)
 check(game.furnishings.turn==1,"R rotates selected furniture by ninety degrees")
 check(game.furnishings.commit_at(Vector2(-5.5,6)) and s.stock.bench==0 and s.layout.back().uid==bench_uid,"moving and rotating preserves instance ID and does not spend inventory again")
 game.furnishings.choose("table",0);game.furnishings.cancel_preview()
 check(s.stock.table==1 and s.layout.size()==3,"canceling preview preserves furniture and layout")
 game.furnishings.choose("table",0)
 check(game.furnishings.commit_at(Vector2(3.5,5.5)),"tea table fits clear living area")
 game.furnishings.choose("screen",0)
 check(game.furnishings.commit_at(Vector2(-3.5,6)),"screen can be freely placed alongside other furniture")
 game.furnishings.choose("rug",0)
 var screen: Vector2=game.furnishings.camera.unproject_position(Vector3(-5.5,30.05,-5.5))
 var motion:=InputEventMouseMotion.new();motion.position=screen;root.push_input(motion,true)
 click(screen);await frames(3)
 check(s.stock.rug==0 and s.layout.any(func(item):return item.kind=="rug" and item.x==-5.5 and item.z==-5.5),"actual mouse click places preview on projected floor cell")
 game.furnishings.choose("chest",2);game.furnishings.turn=1
 check(game.furnishings.commit_at(Vector2(3.5,-4.5)) and game.room.current_chest==Vector3(3.5,0,-4.5),"functional storage chest can move and rotate")
 game.furnishings.choose("cushion",1);game.furnishings.turn=1
 check(game.furnishings.commit_at(Vector2(-2.5,-3.5)) and game.room.current_cushion==Vector3(-2.5,0.15,-3.5),"functional meditation cushion can move and rotate")
 snapshot=s.snapshot();game.furnishings.choose("chest",2);game.furnishings.collect_selected()
 check(s.snapshot()==snapshot,"functional chest cannot be deleted or duplicated into inventory")
 game.furnishings.choose("lamp",0);p.coins=0;game.furnishings.buy_selected()
 check(s.stock.lamp==2 and p.coins==0,"insufficient money cannot purchase extra furniture")
 p.coins=50;game.furnishings.buy_selected()
 check(s.stock.lamp==3 and p.coins==32,"explicit purchase costs displayed coins and adds one stored lamp")
 game.furnishings.choose("sect_lamp",0);var contribution: int=s.contribution;game.furnishings.buy_selected()
 check(s.stock.sect_lamp==0 and s.contribution==contribution,"sect furniture is unavailable before admission")
 s.sect_stage=4;s.clues=3;s.support=1;s.hunts=7;s.rite=true;s.contribution=80;p.learned=true;p.realm=1
 game.furnishings.buy_selected()
 check(s.stock.sect_lamp==1 and s.contribution==35,"admitted disciple purchases exclusive furniture with contribution")
 game.furnishings.choose("sect_lamp",0)
 check(game.furnishings.commit_at(Vector2(5.5,6)),"contribution reward can be placed as actual home furniture")
 await frames(4);await capture("40-free-furnishing-editor")
 game.furnishings.choose("bench",bench_uid);game.furnishings.collect_selected()
 check(s.stock.bench==1 and not s.layout.any(func(item):return item.uid==bench_uid),"collect returns exactly one placed furniture item to inventory")
 game.furnishings.collect_selected();check(s.stock.bench==1,"repeated collect cannot duplicate inventory")
 key(KEY_ESCAPE);await frames(4)
 check(not game.furnishings.editing and not game.paused and game.traveler.camera.current and game.room.roof.visible and game.traveler.enabled,"Esc restores room roof, player camera and mouse control")
 for point in game.room.points:
  if point.kind=="storage":game.traveler.position=point.position+Vector3.UP*0.1
 game.interact();await frames(4)
 check(game.room.storage_panel.visible and game.paused,"moved chest remains interactable at its rotated front")
 game.set_paused(false);p.learned=true;p.herb_stock=4
 game.traveler.position=game.room.OFFSET+game.room.current_cushion+Vector3(0,0.1,0.3);game.interact();await frames(60)
 check(game.room.meditating and game.traveler.sitting and game.traveler.position.distance_to(game.room.OFFSET+game.room.current_cushion)<0.25,"moved cushion still seats player at its actual location")
 game.traveler.yaw=-0.4;game.traveler.pitch=-0.25;await frames(3);await capture("41-rearranged-home")
 game.room.stop_rest()
 check(game.save_game(false),"custom home saves successfully")
 check(game.continue_game(),"custom home save restores successfully")
 check(game.progress.journey.layout==s.layout and game.progress.journey.stock==s.stock,"custom placement, rotation and inventory survive save reload")
 check(game.room.current_chest==Vector3(3.5,0,-4.5) and game.room.current_cushion==Vector3(-2.5,0.15,-3.5),"reloading applies functional anchors as well as decorative models")
 var broken: Dictionary=game.progress.snapshot(Vector3(0,0.1,3.5));broken.journey.layout[0].x=0;broken.journey.layout[0].z=6
 var loaded=P.new();var original: Dictionary=loaded.snapshot(Vector3.ZERO)
 check(not loaded.restore(broken) and loaded.snapshot(Vector3.ZERO)==original,"blocked-door save layout is rejected atomically")
 broken=game.progress.snapshot(Vector3(0,0.1,3.5));broken.journey.layout[1].uid=broken.journey.layout[0].uid
 check(not loaded.restore(broken),"duplicate furniture IDs are rejected on load")
 game.room.leave();await frames(4)
 var enabled_shapes:=0
 for model in game.furnishings.models.values():
  for shape in model.find_children("*","CollisionShape3D",true,false):
   if not shape.disabled:enabled_shapes+=1
 check(enabled_shapes==0 and not game.room.visible,"indoor furniture collision disables on leaving home")
 game.exiting=true;game.expedition.stop_ambience();await frames(3)
 game.queue_free();await process_frame
 print("RESULT: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
