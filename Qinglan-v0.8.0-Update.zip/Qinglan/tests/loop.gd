extends SceneTree

const Terrain = preload("res://scripts/terrain.gd")
const Game = preload("res://scripts/game.gd")
const Progress = preload("res://scripts/progress.gd")
const Rules = preload("res://scripts/world_rules.gd")
var checks := 0
var failures := 0
var capture_dir := ""

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-dir="):
			capture_dir = arg.trim_prefix("--capture-dir=")
	call_deferred("run")

func check(value: bool, description: String) -> void:
	checks += 1
	if value:
		print("PASS: " + description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func frames(count: int) -> void:
	for i in range(count):
		await physics_frame

func capture(name: String) -> void:
	if capture_dir.is_empty():
		return
	await process_frame
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)

func press(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	root.push_input(event, true)

func talk_to(game: Node3D, id: String) -> void:
	for npc in game.town.npcs:
		if npc.id == id:
			game.traveler.position = npc.position + Vector3(0, 0.1, 1.5)
			game.traveler.velocity = Vector3.ZERO
			game.interact()
			return
	check(false, "NPC exists: " + id)

func collect(game: Node3D) -> void:
	for item in game.progress.pending_loot.duplicate(true):
		game.traveler.position = Terrain.ground(Vector3(item.position[0], 0.1, item.position[2]))
		game.traveler.velocity = Vector3.ZERO
		game.interact()

func kill_wolf(game: Node3D) -> void:
	var wolf: Dictionary = game.frontier.enemies[0]
	game.traveler.position = wolf.node.position + Vector3(0, 0.1, 4)
	game.traveler.velocity = Vector3.ZERO
	game.traveler.yaw = 0
	game.progress.qi = game.progress.max_qi()
	game.combo_window = 0
	await frames(2)
	for i in range(3):
		game.cast_sword()
		await frames(35)

func run() -> void:
	var state = Progress.new()
	state.coins = 0
	check(not state.buy("heal") and state.heal_potions == 0, "insufficient gold purchase is atomic")
	check(not state.sell("core") and state.coins == 0, "empty sale cannot mint gold")
	state.coins = 30
	check(state.buy("herb") and state.sell("herb") and state.coins == 23, "buy then sell cannot generate arbitrage profit")
	state.heal_potions = 1
	check(not state.use_potion("heal") and state.heal_potions == 1, "full-health potion is not wasted")
	check(not state.upgrade_weapon() and state.weapon_level == 0, "upgrade requires enough gold")
	state.herb_stock = 3
	check(state.accept_order("herbs") and not state.accept_order("hunt"), "quest choice cannot silently overwrite another branch")
	check(state.complete_order() and state.herbs() == 0 and state.orders_completed == 1, "commission consumes exact resources and completes")
	var paid: int = state.coins
	check(not state.complete_order() and state.coins == paid, "commission reward cannot be claimed twice")
	var cultivator = Progress.new()
	cultivator.learned = true
	cultivator.herb_stock = 3
	cultivator.beast_cores = 3
	check(cultivator.breakthrough() and cultivator.beast_cores == 2, "breakthrough consumes one core from a stack without deleting the remainder")
	var restored = Progress.new()
	check(restored.restore(JSON.parse_string(JSON.stringify(cultivator.snapshot(Vector3.ZERO)))) and restored.beast_cores == 2, "post-breakthrough stacked cores persist without requiring the story beast")
	var game = Game.new()
	root.add_child(game)
	game.begin_new()
	game.progress.learned = true
	await frames(3)
	check(game.frontier.enemies.size() == 12 and game.frontier.enemies[0].species != game.frontier.enemies[9].species, "expanded world contains twelve renewable monsters across four types")
	check(["elder", "healer", "trader"].all(func(id): return game.town.npcs.any(func(npc): return npc.id == id)), "three original NPCs remain in market alongside sect emissary")
	talk_to(game, "elder")
	check(game.town.popup.visible and game.paused and game.town.current == "elder", "E opens actual elder conversation and pauses world")
	game.town.accept("herbs")
	check(game.progress.active_order == "herbs", "elder conversation accepts gathering branch")
	await capture("15-elder-commission")
	game.set_paused(false)
	check(not game.town.popup.visible, "closing NPC conversation removes modal panel")
	for id in range(3):
		for point in game.valley.interactions:
			if point.kind == "herb" and point.id == id:
				game.traveler.position = point.position + Vector3.UP * 0.1
				game.interact()
	check(game.progress.herbs() == 3, "gather real world plants for chosen branch")
	talk_to(game, "elder")
	var money: int = game.progress.coins
	game.town.complete()
	check(game.progress.coins == money + 35 and game.progress.active_order.is_empty(), "return to elder pays gathering commission")
	game.town.complete()
	check(game.progress.coins == money + 35, "repeated NPC turn-in does not duplicate payment")
	game.town.accept("hunt")
	game.set_paused(false)
	await kill_wolf(game)
	check(game.frontier.dead(game.frontier.enemies[0]) and game.progress.beast_cores == 0, "real sword combat kills wolf without auto-crediting its core")
	check(game.progress.pending_loot.size() >= 2 and game.frontier.loot_nodes.size() >= 2, "wolf leaves visible physical core and coin objects")
	await capture("16-field-loot")
	var first_id: int = game.progress.pending_loot[0].uid
	check(game.save_game(false) and game.continue_game(), "uncollected drops survive save and reload")
	check(game.frontier.loot_nodes.size() >= 2 and game.frontier.dead(game.frontier.enemies[0]), "reload keeps corpse timer and renders remaining drops")
	collect(game)
	check(game.progress.beast_cores == 1 and game.progress.pending_loot.is_empty(), "E pickup transfers physical loot into inventory")
	check(not game.progress.pickup_loot(first_id), "picked loot UID cannot be credited twice")
	game.progress.world_time = float(game.progress.monster_ready.wolf0) + 0.1
	await frames(2)
	check(game.frontier.dead(game.frontier.enemies[0]), "monster does not respawn underneath a nearby player")
	game.traveler.position = Vector3(0, 0.1, 18)
	await frames(3)
	check(not game.frontier.dead(game.frontier.enemies[0]) and game.frontier.enemies[0].node.visible, "dead monster respawns after timer when player leaves spawn area")
	await kill_wolf(game)
	collect(game)
	check(game.progress.beast_cores == 2, "second encounter yields another core for repeatable hunting loop")
	talk_to(game, "elder")
	money = game.progress.coins
	game.town.complete()
	check(game.progress.coins == money + 65 and game.progress.beast_cores == 0 and game.progress.orders_completed == 2, "hunting commission consumes two cores and pays after repeated encounter")
	game.set_paused(false)
	talk_to(game, "trader")
	game.town.upgrade()
	check(game.progress.weapon_level == 1 and game.progress.max_hp() == 108, "merchant upgrades sword and gameplay stats with earned gold")
	await capture("17-market-trader")
	game.set_paused(false)
	talk_to(game, "healer")
	game.town.buy("heal")
	game.town.buy("mana")
	check(game.progress.heal_potions == 1 and game.progress.mana_potions == 1, "apothecary sells actual usable potion inventory")
	game.set_paused(false)
	money = game.progress.coins
	game.town.buy("seed")
	check(game.progress.coins == money, "closed merchant interface cannot transact remotely")
	game.progress.hp = 20
	game.progress.qi = 20
	press(KEY_4)
	press(KEY_5)
	check(game.progress.hp == 80 and game.progress.qi == 80 and game.progress.heal_potions == 0 and game.progress.mana_potions == 0, "field hotkeys consume purchased supplies and restore health and qi")
	talk_to(game, "elder")
	game.town.accept("survey")
	game.set_paused(false)
	game.traveler.position = Terrain.ground(Rules.SURVEY + Vector3(0, 0.1, 1.5))
	game.interact()
	check(game.progress.surveyed, "exploration branch records physical interaction with distant landmark")
	press(KEY_M)
	await frames(2)
	check(game.navigation.map_view.region_view and game.navigation.map_view.map_rect().has_point(game.navigation.map_view.world_point(Rules.SURVEY)), "expanded locations appear in regional map bounds")
	await capture("18-regional-map")
	press(KEY_M)
	talk_to(game, "elder")
	money = game.progress.coins
	game.town.complete()
	check(game.progress.coins == money + 45 and game.progress.orders_completed == 3, "exploration branch pays independently of gathering and hunting")
	game.town.accept("survey")
	check(not game.progress.order_ready(), "repeated exploration commission requires a fresh landmark visit")
	game.town.cancel()
	game.set_paused(false)
	var point: Dictionary = game.valley.interactions.filter(func(item): return item.kind == "herb" and item.id == 0)[0]
	check(game.frontier.available(point), "harvested wild plant regrows after world timer")
	game.traveler.position = point.position + Vector3.UP * 0.1
	game.interact()
	check(game.progress.herbs() == 1 and game.progress.collected.size() == 3, "regrown harvest adds stock without duplicating legacy resource IDs")
	game.interact()
	check(game.progress.herbs() == 1, "freshly harvested plant cannot instantly regrow")
	game.traveler.position = Vector3(0, 0.1, 48)
	game.traveler.velocity = Vector3.ZERO
	game.traveler.yaw = 0
	Input.action_press("back")
	await frames(20)
	Input.action_release("back")
	check(game.traveler.position.z > 49 and game.traveler.is_on_floor(), "player traverses new ground beyond original map and floor")
	game.traveler.position = Vector3(-43, 0.1, -36)
	game.traveler.velocity = Vector3.ZERO
	var mire: Dictionary = game.frontier.enemies[6]
	mire.cooldown = 0
	var health: float = game.progress.hp
	await frames(135)
	check(game.progress.hp < health, "new ranged species telegraphs and lands a poison projectile")
	game.frontier.hit(mire.id, 1000)
	check(game.progress.pending_loot.any(func(item): return item.item == "herb"), "poison creature leaves a physical herb bundle alongside other loot")
	check(game.save_game(false) and game.continue_game() and game.progress.weapon_level == 1 and game.progress.orders_completed == 3, "economy and completed branches survive save reload")
	var legacy := {"version": 2, "name": "旧修士", "robe": 1, "learned": true, "collected": [0, 1, 2, 3],
		"core": false, "beast_dead": true, "realm": 1, "hp": 125, "qi": 87, "position": [-25, 0.1, 23],
		"herb_stock": 1, "home_claimed": true, "home_style": 1, "vault_herbs": 2, "seeds": 3,
		"plots": [-1, -1, -1], "world_time": 20, "cultivation": 0, "runes": 3,
		"spitter_dead": true, "guardian_dead": true, "relic": true}
	var text := JSON.stringify(legacy)
	var file := FileAccess.open(Game.SAVE, FileAccess.WRITE)
	file.store_string(text)
	file.close()
	check(game.continue_game() and game.progress.realm == 1 and game.progress.home_style == 1 and game.progress.vault_herbs == 2, "v2 migration keeps original character, home and stored items")
	check(FileAccess.get_file_as_string(Game.SAVE + ".v2.bak") == text, "v2 migration preserves original save backup")
	game.progress.buy("seed")
	game.save_game(false)
	check(game.continue_game() and game.progress.coins == 22, "migration seed money is not granted again on v3 reload")
	var invalid: Dictionary = game.progress.snapshot(Vector3.ZERO)
	invalid.coins = -100
	check(not game.progress.restore(invalid) and game.progress.coins == 22, "invalid economy data is rejected without mutating live currency")
	game.progress.add_loot("core", 1, Vector3.ZERO)
	invalid = game.progress.snapshot(Vector3.ZERO)
	invalid.pending_loot.append(invalid.pending_loot[0].duplicate(true))
	check(not game.progress.restore(invalid), "duplicated physical loot IDs are rejected by save loader")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
