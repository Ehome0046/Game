extends SceneTree
const Game=preload("res://scripts/game.gd")
const P=preload("res://scripts/progress.gd")
const C=preload("res://scripts/catalog.gd")
var checks:=0
var failures:=0
var capture_dir:=""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):capture_dir=arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func check(ok: bool,text: String) -> void:
 checks+=1
 if ok:print("PASS: "+text)
 else:failures+=1;push_error("FAIL: "+text)
func frames(n: int) -> void:
 for i in range(n):await physics_frame
func capture(name: String) -> void:
 if capture_dir.is_empty():return
 await process_frame;await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func click(button: Button) -> void:
 var e:=InputEventMouseButton.new();e.position=button.get_global_rect().get_center();e.button_index=MOUSE_BUTTON_LEFT;e.pressed=true;root.push_input(e,true);e=e.duplicate();e.pressed=false;root.push_input(e,true)
func run() -> void:
 var game=Game.new();root.add_child(game);game.begin_new();await frames(3)
 game.traveler.position=C.CHESTS.mine+Vector3(0,0.1,0.85);game.interact();await frames(24)
 var p=game.progress
 check(game.paused and game.treasure.popup.visible and game.expedition.chests.mine.lid.rotation.x < -1,"E opens physical chest lid and actual loot inventory")
 check(game.treasure.slots.size()==18 and game.treasure.bag.size()==18,"outdoor chest uses familiar eighteen-slot chest and bag grids")
 check("iron_blade" in p.expansion.recipes and p.pending_loot.is_empty() and p.growth.chests.mine.size()==3,"mine chest contents remain in slots instead of spawning automatic ground rewards")
 click(game.treasure.slots[0]);await frames(2)
 check(p.item_count("ore")==1 and p.growth.chests.mine[0].count==3,"real chest slot click transfers exactly one material")
 p.herb_stock=4;game.treasure.render();click(game.treasure.bag[0]);await frames(2)
 check(p.herbs()==3 and p.growth.chests.mine.any(func(item):return item.item=="herb" and item.count==1),"real bag slot click deposits material into outdoor chest")
 await capture("49-outdoor-chest-grid")
 check(game.save_game(false) and game.continue_game() and game.progress.growth.chests.mine[0].count==3,"partly looted and deposited contents survive save reload")
 p=game.progress;game.traveler.position=C.CHESTS.mine+Vector3(0,0.1,0.85);game.interact();game.treasure.take_all()
 check(p.growth.chests.mine.is_empty() and p.item_count("ore")==4 and p.expansion.gear.size()==1 and p.coins==45 and p.herbs()==4,"take all transfers mixed currency, gear and materials exactly once")
 game.treasure.take_all();check(p.coins==45 and p.expansion.gear.size()==1,"repeated take all cannot duplicate rewards")
 game.set_paused(false);check(not game.expedition.open_chest("mine") and p.expansion.chest_visits.mine==1,"empty chest cannot regenerate rewards before cooldown")
 p.world_time=float(p.expansion.chest_ready.mine)+0.1;game.expedition.open_chest("mine");check(p.expansion.chest_visits.mine==2,"empty chest refreshes only after active recovery time")
 game.traveler.position=Vector3(0,0.1,18);var ore: int=p.item_count("ore");game.treasure.take(0,true)
 check(p.item_count("ore")==ore,"remote or stale chest UI cannot withdraw items")
 game.set_paused(false);p.learned=true;p.realm=1;p.hp=p.max_hp();p.qi=p.max_qi();p.beast_cores=1;game.traveler.position=C.POIS.shrine+Vector3.UP*0.1;game.expedition.enter_shrine();p.expansion.trial_runes=7;game.trial.sync();game.trial.hit(10000)
 game.traveler.position=C.CHESTS.shrine+Vector3(0,0.1,0.85);game.interact();await frames(3)
 check(game.treasure.popup.visible and not p.expansion.trial_paid and p.growth.chests.shrine.size()==4,"victory chest creates one persisted reward set and closes paid trial")
 game.set_paused(false);game.expedition.leave_shrine();game.traveler.position=C.POIS.shrine+Vector3.UP*0.1;var cores: int=p.beast_cores
 check(game.expedition.enter_shrine() and p.beast_cores==cores and p.expansion.trial_defeated,"unclaimed shrine contents can be retrieved freely during cooldown without a new fight")
 var data: Dictionary=p.snapshot(Vector3(0,0.1,-70.5));data.growth.chests.shrine[0].count=-1
 var loaded=P.new();check(not loaded.restore(data),"negative or malformed outdoor chest stacks are rejected")
 game.exiting=true;game.expedition.stop_ambience();await frames(3);game.queue_free();await process_frame
 print("RESULT: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
