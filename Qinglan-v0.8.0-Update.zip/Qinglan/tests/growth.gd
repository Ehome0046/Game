extends SceneTree
const Game=preload("res://scripts/game.gd")
const P=preload("res://scripts/progress.gd")
var checks:=0
var failures:=0
var capture_dir:=""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):capture_dir=arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func check(ok: bool,text: String) -> void:
 checks+=1
 if ok:print("PASS: "+text)
 else:failures+=1;push_error("FAIL: "+text)
func frames(n: int) -> void:
 for i in range(n):await physics_frame
func capture(name: String) -> void:
 if capture_dir.is_empty():return
 await process_frame;await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func key(code: Key) -> void:
 var e:=InputEventKey.new();e.keycode=code;e.physical_keycode=code;e.pressed=true;root.push_input(e,true)
func run() -> void:
 var p=P.new();p.learned=true;p.realm=1;p.herb_stock=6;p.beast_cores=3
 var original: Dictionary=p.snapshot(Vector3.ZERO)
 check(not p.growth.ascend(p) and p.snapshot(Vector3.ZERO)==original,"unfunded breakthrough is atomic")
 p.growth.insight=100;p.growth.path="sword"
 check(p.growth.ascend(p) and p.realm==2 and p.max_hp()==180 and p.max_qi()==170 and p.growth.insight==0 and p.herbs()==0 and p.beast_cores==0,"second realm costs exact insight and materials and raises caps")
 check(p.expansion.gear.size()==1 and p.expansion.gear[0].id=="jade_blade","second realm awards tangible upgrade equipment")
 p.growth.insight=240;p.beast_cores=6;p.expansion.materials.ore=6
 check(not p.growth.ascend(p) and p.growth.insight==240,"third realm requires inherited technique before charging resources")
 p.runes=3;p.guardian_dead=true;p.relic=true
 check(p.growth.ascend(p) and p.realm==3 and p.max_hp()==220 and p.max_qi()==200 and p.item_count("ore")==0,"third realm requires inheritance and consumes exact displayed cost")
 check(p.expansion.gear.back().id=="cloud_robe" and not p.growth.ascend(p),"top realm awards robe and cannot repeatedly ascend")
 p.growth.insight=200
 check(p.growth.upgrade("sword",p) and p.growth.ranks.sword==1 and p.growth.insight==175,"skill research spends displayed insight")
 p.growth.upgrade("sword",p);p.growth.upgrade("sword",p)
 check(not p.growth.upgrade("sword",p) and p.growth.ranks.sword==3,"skill ranks stop at realm and hard cap")
 var loaded=P.new()
 check(loaded.restore(JSON.parse_string(JSON.stringify(p.snapshot(Vector3.ZERO)))) and loaded.realm==3 and loaded.growth.ranks.sword==3,"new realms, path and skill ranks persist in JSON")
 var broken: Dictionary=p.snapshot(Vector3.ZERO);broken.growth.ranks.fire=4
 check(not loaded.restore(broken) and loaded.growth.ranks.sword==3,"invalid new skill data cannot mutate live save state")
 var game=Game.new();root.add_child(game);game.begin_new();await frames(3);p=game.progress;p.learned=true;p.realm=1;p.hp=p.max_hp();p.qi=p.max_qi()
 key(KEY_U);await frames(3)
 check(game.paused and game.cultivation.popup.visible,"U opens actual cultivation interface")
 p.growth.insight=100;p.herb_stock=6;p.beast_cores=3;game.cultivation.ascend()
 check(p.realm==1 and p.growth.insight==100,"remote cultivation interface cannot ascend away from a cultivation site")
 game.set_paused(false);game.traveler.position=game.valley.altar+Vector3.UP*0.1;key(KEY_U);game.cultivation.choose_path("spell");game.cultivation.ascend()
 check(p.realm==2 and p.growth.path=="spell" and p.expansion.gear.back().id=="moon_charm","site-bound UI breakthrough uses chosen path and awards appropriate gear")
 await frames(3);await capture("44-cultivation-and-realms")
 game.set_paused(false);var xp: int=p.growth.insight;game.frontier.hit("wolf0",10000)
 check(p.growth.insight==xp+12,"actual monster defeat grants insight once")
 game.frontier.hit("wolf0",10000);check(p.growth.insight==xp+12,"dead monster cannot duplicate insight")
 p.growth.insight=75;p.expansion.add_gear("twig_blade");p.expansion.add_gear("linen_robe")
 game.workshop.open_gear();game.workshop.equip_best()
 check(int(p.expansion.equipped.charm)>0 and int(p.expansion.equipped.weapon)>0 and int(p.expansion.equipped.robe)>0,"one-click recommendation actually fills all three available equipment slots")
 check(not game.workshop.advanced.visible and not game.workshop.equip_button.text.contains("/"),"simplified equipment view separates wearing from advanced item actions")
 await frames(3);await capture("45-simple-equipment-comparison")
 game.workshop.toggle_advanced();await frames(3);await capture("50-equipment-upgrade-actions")
 game.set_paused(false);p.growth.path="";game.traveler.position=game.valley.beast.position+Vector3(0,0.1,4);p.qi=p.max_qi();game.attack_cooldown=0;game.combo_window=0
 var hp: float=game.beast_hp;game.cast_sword();await frames(25)
 check(hp-game.beast_hp>=55,"higher realm and worn equipment affect actual projectile damage")
 game.traveler.position=Vector3(0,0.1,18);game.traveler.invincible=0;game.shield_cooldown=0;p.qi=p.max_qi();p.hp=p.max_hp()
 check(game.cast_shield(),"shield starts perfect defense window")
 hp=p.hp;game.take_damage(30)
 check(p.hp==hp and game.counter_time>0 and game.parry_time==0,"timely shield perfectly blocks and enables one counterattack")
 game.traveler.position=game.valley.beast.position+Vector3(0,0.1,4);game.attack_cooldown=0;game.cast_sword()
 check(game.counter_time==0,"counter bonus is consumed by one successful attack")
 await frames(30)
 game.progress.beast_dead=false;game.beast_hp=300;game.valley.beast.show();game.traveler.position=game.valley.beast.position+Vector3(0,0.1,4);game.attack_cooldown=0;p.qi=p.max_qi()
 hp=game.beast_hp;var qi: float=p.qi
 check(game.begin_charge(),"holding attack begins a charge without instant resource cost")
 await frames(45)
 check(game.beast_hp==hp and p.qi>=qi and game.charge_time>=0.65,"charging has visible duration and deals no damage before release")
 check(game.release_charge(),"releasing charged attack launches heavy sword")
 await frames(25)
 check(hp-game.beast_hp>90 and not game.charging,"charged sword has actual increased damage and completes once")
 check(game.save_game(false) and game.continue_game() and game.progress.realm==2 and game.progress.growth.path=="","ordinary save reload preserves newly unlocked realm")
 var legacy: Dictionary=game.progress.snapshot(Vector3(0,0.1,18));legacy.version=7;legacy.realm=1;legacy.hp=100;legacy.qi=100;legacy.erase("growth");legacy.expansion.kills=5;legacy.expansion.batches=2
 var exact:=JSON.stringify(legacy);var file:=FileAccess.open(Game.SAVE,FileAccess.WRITE);file.store_string(exact);file.close()
 check(game.continue_game() and game.progress.growth.insight==56 and game.progress.realm==1,"v7 migration seeds insight from existing kills and crafting without changing realm")
 check(FileAccess.get_file_as_string(Game.SAVE+".v7.bak")==exact,"v7 migration preserves exact original backup")
 game.exiting=true;game.expedition.stop_ambience();await frames(3);game.queue_free();await process_frame
 print("RESULT: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
