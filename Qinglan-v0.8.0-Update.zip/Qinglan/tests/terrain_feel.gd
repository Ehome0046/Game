extends SceneTree
const Game=preload("res://scripts/game.gd")
const T=preload("res://scripts/terrain.gd")
var checks:=0
var failures:=0
var capture_dir:=""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):capture_dir=arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func check(ok: bool,text: String) -> void:
 checks+=1
 if ok:print("PASS: "+text)
 else:failures+=1;push_error("FAIL: "+text)
func frames(n: int) -> void:
 for i in range(n):await physics_frame
func capture(name: String) -> void:
 if capture_dir.is_empty():return
 await process_frame;await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func run() -> void:
 var game=Game.new();root.add_child(game);game.begin_new();await frames(4)
 check(T.height_at(67,-38)>7 and T.height_at(-56,57)>5 and T.height_at(0,18)==0,"terrain has actual high ridges and keeps village foundation level")
 var ray:=PhysicsRayQueryParameters3D.create(Vector3(47,20,61),Vector3(47,-2,61),1)
 var result: Dictionary=game.get_world_3d().direct_space_state.intersect_ray(ray)
 check(not result.is_empty() and absf(result.position.y-T.height_at(47,61))<0.05,"height samples agree with actual physical terrain triangles")
 var enemy: Dictionary=game.frontier.enemies[9];game.frontier.brain.begin_attack(enemy,Vector3.BACK)
 var vertices: PackedVector3Array=enemy.warning.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
 var aligned:=vertices.size()>90
 for vertex in vertices:
  var at: Vector3=vertex+enemy.warning.position
  if absf(at.y-T.height_at(at.x,at.z)-0.11)>0.02:aligned=false
 check(aligned,"enemy ground warnings follow hill surface instead of floating or disappearing under it")
 game.traveler.position=T.ground(Vector3(47,0.1,49));game.traveler.velocity=Vector3.ZERO;game.traveler.yaw=0;await frames(4)
 var low: float=game.traveler.position.y;Input.action_press("back");await frames(135);Input.action_release("back");await frames(3)
 check(game.traveler.position.z>56 and game.traveler.position.y>low+1.2 and game.traveler.is_on_floor(),"player physically walks uphill rather than crossing a decorative flat map")
 check(absf(game.traveler.position.y-T.height_at(game.traveler.position.x,game.traveler.position.z))<0.2,"feet stay grounded on slopes")
 game.traveler.yaw=0.9;game.traveler.pitch=-0.3;game.traveler.spring.spring_length=7;await frames(3);await capture("46-walkable-hills")
 check(game.save_game(false) and game.continue_game() and game.traveler.position.y>3,"save reload restores ridge position onto elevated ground")
 game.progress.add_loot("core",1,Vector3(47,0.2,61));game.frontier.sync_loot();game.traveler.position=T.ground(Vector3(47,0.1,61));var cores: int=game.progress.beast_cores;game.interact()
 check(game.progress.beast_cores==cores+1,"physical loot can be collected on elevated terrain")
 game.progress.learned=true;game.traveler.position=game.valley.beast.position+Vector3(0,0.1,4);game.traveler.velocity=Vector3.ZERO;game.attack_cooldown=0;game.progress.qi=100;game.cast_sword();await frames(8)
 var forward: Vector3=-game.traveler.model.global_basis.z
 check((game.traveler.right_hand.global_position-game.traveler.right_arm.global_position).dot(forward)>0.15 and (-game.traveler.face.global_basis.z).dot(forward)>0.7,"face and casting hand both point toward the actual target")
 game.traveler.yaw=PI;game.traveler.pitch=-0.12;await frames(2);await capture("47-correct-character-facing")
 game.traveler.position=Vector3(0,0.1,18);game.traveler.velocity=Vector3.ZERO;game.traveler.dodge_cooldown=0;Input.action_press("dodge");await frames(3);Input.action_release("dodge")
 check(game.traveler.roll_left>0 and absf(game.traveler.model.rotation.x)>0.2 and game.traveler.invincible>0,"dodge performs an actual forward roll while preserving invulnerability")
 await frames(30);check(game.traveler.roll_left==0 and absf(game.traveler.model.rotation.x)<0.01,"roll returns body to upright stance")
 game.traveler.invincible=0;game.take_damage(12);await frames(2)
 check(game.traveler.hurt_left>0 and game.feedback.flash.color.a>0 and game.feedback.flash.size.x>1000,"damage causes visible recoil and full viewport hit flash")
 game.progress.claim_home();game.traveler.position=game.adventure.HOME;game.room.enter();await frames(4)
 var supports:=0
 for mesh in game.room.get_children():
  if mesh is MeshInstance3D and mesh.mesh is CylinderMesh and mesh.mesh.top_radius<0.03 and mesh.mesh.height>1.8:supports+=1
 check(supports>=2,"hanging interior lamps have visible ceiling chains")
 game.traveler.position=game.room.OFFSET+Vector3(1,0.1,5);game.traveler.yaw=-0.4;game.traveler.pitch=0.2;await frames(3);await capture("48-supported-lanterns")
 game.exiting=true;game.expedition.stop_ambience();await frames(3);game.queue_free();await process_frame
 print("RESULT: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
