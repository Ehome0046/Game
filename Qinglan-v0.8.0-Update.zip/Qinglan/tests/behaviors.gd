extends SceneTree
const Game=preload("res://scripts/game.gd")
var checks:=0
var failures:=0
var capture_dir:=""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):capture_dir=arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func check(ok: bool,text: String) -> void:
 checks+=1
 if ok:print("PASS: "+text)
 else:failures+=1;push_error("FAIL: "+text)
func frames(n: int) -> void:
 for i in range(n):await physics_frame
func capture(name: String) -> void:
 if capture_dir.is_empty():return
 await process_frame;await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func prepare(game: Node3D,enemy: Dictionary,offset: Vector3) -> void:
 game.frontier.reset_encounters();enemy.node.position=enemy.origin;game.traveler.position=enemy.origin+offset+Vector3.UP*0.1;game.traveler.velocity=Vector3.ZERO
 game.progress.hp=game.progress.max_hp();game.progress.qi=game.progress.max_qi();game.traveler.invincible=0;game.attack_cooldown=0
func run() -> void:
 var game=Game.new();root.add_child(game);game.begin_new();await frames(3)
 game.progress.learned=true;game.progress.realm=1;game.progress.beast_dead=true;game.progress.runes=3;game.progress.guardian_dead=true;game.progress.relic=true;game.sync_world()
 var wolf: Dictionary=game.frontier.enemies[0]
 prepare(game,wolf,Vector3(0,0,7));await frames(3)
 check(wolf.state=="alert" and game.frontier.enemies[1].state=="alert","wolf sight triggers visible alert and calls nearby pack member")
 var before: Vector3=wolf.node.position
 await frames(50)
 check(wolf.state in ["chase","windup"] and wolf.node.position.distance_to(before)>0.1,"pack alert transitions to actual pursuit")
 check(wolf.legs.size()==4 and wolf.legs.any(func(leg):return absf(leg.rotation.x)>0.01),"running wolf animates its physical legs")
 prepare(game,wolf,Vector3(0,0,7))
 var wall=game.valley.box(wolf.origin+Vector3(0,1.2,3.5),Vector3(4,2.4,0.4),game.valley.stone,true)
 await frames(4)
 game.frontier.brain.reset(wolf);game.frontier.brain.reset(game.frontier.enemies[1]);await frames(4)
 check(wolf.state=="patrol","solid terrain blocks visual aggro")
 wall.queue_free();await frames(4)
 check(wolf.state=="alert","removing sight obstruction permits detection")
 var boar: Dictionary=game.frontier.enemies[3]
 prepare(game,boar,Vector3(0,0,5));game.frontier.brain.begin_attack(boar,Vector3.BACK)
 var hp: float=game.progress.hp;await frames(3)
 check(boar.warning.visible and boar.lane.visible and game.progress.hp==hp,"boar charge has visible lane and windup before damage")
 var frozen: Vector3=boar.charge_dir
 game.traveler.position+=Vector3(4,0,0);game.traveler.velocity=Vector3.ZERO
 game.traveler.yaw=0.7;game.traveler.pitch=-0.4;await frames(4);await capture("42-boar-charge-warning")
 before=boar.node.position;await frames(110)
 check(boar.charge_dir==frozen and boar.node.position.z>before.z+2 and absf(boar.node.position.x-before.x)<0.5,"charge follows warned direction rather than steering toward dodging player")
 check(game.progress.hp==hp,"sidestepping outside warned lane avoids charge damage")
 prepare(game,boar,Vector3(0,0,2.7));game.frontier.brain.begin_attack(boar,Vector3.BACK);hp=game.progress.hp;await frames(110)
 check(game.progress.hp==hp-28,"remaining in charge lane takes exactly one charge hit")
 check(boar.state in ["recover","chase"] and not boar.lane.visible,"charge ends with recovery and clears its warning")
 prepare(game,boar,Vector3(0,0,5))
 wall=game.valley.box(boar.origin+Vector3(0,1.2,3.5),Vector3(4,2.4,0.4),game.valley.stone,true)
 await frames(3);game.frontier.brain.begin_attack(boar,Vector3.BACK);hp=game.progress.hp;await frames(100)
 check(boar.node.position.z<boar.origin.z+3.3 and game.progress.hp==hp,"charge stops on solid terrain without passing through wall or hitting behind it")
 wall.queue_free();await frames(3)
 var spider: Dictionary=game.frontier.enemies[6]
 prepare(game,spider,Vector3(0,0,3));game.frontier.brain.enter(spider,"chase");spider.cooldown=2
 var distance: float=spider.node.position.distance_to(game.traveler.position);await frames(25)
 check(spider.node.position.distance_to(game.traveler.position)>distance+0.5,"ranged spider backs away when player approaches too closely")
 prepare(game,spider,Vector3(0,0,6));game.frontier.brain.begin_attack(spider,Vector3.BACK);hp=game.progress.hp;await frames(85)
 check(game.frontier.hazards.size()==1 and game.progress.hp==hp-16,"poison projectile hits marked point and leaves lingering hazard")
 game.traveler.yaw=0;game.traveler.pitch=-0.35;await frames(3);await capture("43-spider-poison-zone")
 game.set_paused(true);var left: float=game.frontier.hazards[0].left;await frames(20)
 check(game.frontier.hazards[0].left==left,"pause freezes lingering hazard lifetime")
 game.set_paused(false);await frames(65)
 check(game.progress.hp<hp-16,"standing in visible poison zone takes periodic actual damage")
 game.traveler.position+=Vector3(4,0,0);game.traveler.velocity=Vector3.ZERO;hp=game.progress.hp;await frames(60)
 check(game.progress.hp==hp,"leaving poison zone avoids subsequent poison tick")
 game.frontier.clear_hazards();check(game.frontier.hazards.is_empty(),"encounter cleanup removes poison geometry and damage sources")
 var stone: Dictionary=game.frontier.enemies[9]
 prepare(game,stone,Vector3(0,0,2.7));game.frontier.brain.begin_attack(stone,Vector3.BACK);hp=game.progress.hp;game.fire_cooldown=0
 check(game.cast_attack("fire"),"real fire spell can target charging stone enemy")
 await frames(25)
 check(stone.state=="stagger" and stone.hp<stone.max_hp and not stone.warning.visible,"actual fire projectile interrupts heavy windup and displays stagger")
 await frames(50);check(game.progress.hp==hp,"interrupted heavy strike cannot deal delayed damage")
 prepare(game,stone,Vector3(0,0,2.7));game.frontier.brain.begin_attack(stone,Vector3.BACK);game.combo_stage=1;game.combo_window=1;hp=game.progress.hp
 check(game.cast_sword(),"real third sword strike can target heavy windup")
 await frames(25);check(stone.state=="stagger" and game.combo_stage==2,"third sword combo interrupts telegraphed attack")
 prepare(game,stone,Vector3(0,0,2.7));game.frontier.brain.begin_attack(stone,Vector3.BACK);game.frontier.hit(stone.id,1,false)
 check(stone.state=="windup","ordinary hit does not cancel every enemy attack")
 game.traveler.position+=Vector3(5,0,0);game.traveler.velocity=Vector3.ZERO;hp=game.progress.hp;await frames(80)
 check(game.progress.hp==hp,"moving out of stone heavy strike radius avoids damage")
 prepare(game,boar,Vector3(0,0,5));boar.node.position=boar.origin+Vector3(4,0,0);boar.hp=20;game.frontier.brain.enter(boar,"chase")
 game.traveler.position=Vector3(0,0.1,18);await frames(3)
 check(boar.state=="return" and boar.hp==20,"leash enters visible retreat without instantly healing mid-field")
 await frames(100)
 check(boar.hp==boar.max_hp and boar.state=="patrol" and boar.node.position.distance_to(boar.origin)<2.5,"enemy returns to origin before restoring health and resuming patrol")
 game.progress.claim_home();game.traveler.position=game.adventure.HOME;game.room.enter();await frames(3)
 before=wolf.node.position;await frames(30)
 check(wolf.node.position==before and game.frontier.hazards.is_empty(),"outdoor AI and poison cannot run inside safe home")
 game.exiting=true;game.expedition.stop_ambience();await frames(3)
 game.queue_free();await process_frame
 print("RESULT: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
