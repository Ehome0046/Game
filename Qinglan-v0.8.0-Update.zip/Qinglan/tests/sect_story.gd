extends SceneTree
const Game=preload("res://scripts/game.gd")
const P=preload("res://scripts/progress.gd")
var checks:=0
var failures:=0
var capture_dir:=""
func _initialize() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="): capture_dir=arg.trim_prefix("--capture-dir=")
 call_deferred("run")
func check(ok: bool,text: String) -> void:
 checks+=1
 if ok: print("PASS: "+text)
 else: failures+=1;push_error("FAIL: "+text)
func frames(n: int) -> void:
 for i in range(n): await physics_frame
func capture(name: String) -> void:
 if capture_dir.is_empty():return
 await process_frame;await RenderingServer.frame_post_draw
 check(root.get_texture().get_image().save_png(capture_dir.path_join(name+".png"))==OK,"render "+name)
func key(code: Key) -> void:
 var event:=InputEventKey.new();event.keycode=code;event.physical_keycode=code;event.pressed=true;root.push_input(event,true)
func click(button: Button) -> void:
 var event:=InputEventMouseButton.new();event.position=button.get_global_rect().get_center();event.button_index=MOUSE_BUTTON_LEFT;event.pressed=true;root.push_input(event,true);event=event.duplicate();event.pressed=false;root.push_input(event,true)
func approach(game: Node3D,at: Vector3) -> void:
 game.traveler.position=at+Vector3(0,0.1,-0.7);game.traveler.velocity=Vector3.ZERO
func run() -> void:
 var game=Game.new();root.add_child(game);game.begin_new();await frames(3)
 var p=game.progress
 key(KEY_J);await frames(2)
 check(game.paused and game.sect.popup.visible,"J opens readable sect journal before joining")
 var coins: int=p.coins
 game.sect.advance()
 check(p.journey.sect_stage==0 and p.coins==coins,"remote journal cannot advance or award sect story")
 game.set_paused(false);approach(game,game.sect.EMISSARY);game.interact();await frames(2)
 game.sect.advance()
 check(p.journey.sect_stage==0,"emissary requires learned cultivation and first realm")
 p.learned=true;p.realm=1;p.hp=p.max_hp();p.qi=p.max_qi();game.sect.advance()
 check(p.journey.sect_stage==1 and p.journey.tracking,"actual emissary dialogue starts investigation and tracks story")
 await frames(3);await capture("38-sect-introduction")
 game.set_paused(false)
 for i in range(2): approach(game,game.sect.CLUES[i]);game.interact()
 check(p.journey.clues==3,"E investigates both physical clues")
 game.interact();check(p.journey.clues==3,"repeated clue interaction does not duplicate progress")
 approach(game,game.sect.EMISSARY);game.interact();await frames(2);click(game.sect.actions.get_child(0));await frames(2)
 check(p.journey.sect_stage==2 and p.coins==coins+40 and p.journey.contribution==20,"actual UI turn-in advances chapter with one-time reward")
 game.sect.aid(1);check(p.journey.support==0,"emissary location cannot remotely pay healer branch")
 game.set_paused(false);approach(game,Vector3(-5,0,26));game.interact();await frames(2)
 var found:=false
 for b in game.town.actions.get_children():
  if b.text.begins_with("宗门援助"): click(b);found=true;break
 await frames(2);check(found and game.sect.popup.visible,"healer dialogue links into actual aid choice")
 p.herb_stock=3;p.expansion.materials.ore=3;game.sect.aid(1)
 check(p.journey.support==0 and p.herbs()==3,"insufficient chosen aid materials do not spend anything")
 p.herb_stock=4;game.sect.aid(1)
 check(p.journey.support==1 and p.herbs()==0 and p.item_count("ore")==3,"healer herb branch spends only four herbs and records narrative choice")
 game.sect.aid(2);check(p.journey.support==1 and p.item_count("ore")==3,"other aid branch cannot be paid after one has been chosen")
 var alternative=P.new();alternative.journey.sect_stage=2;alternative.expansion.materials.ore=3
 check(alternative.journey.aid(alternative,2) and alternative.item_count("ore")==0 and alternative.journey.support==2,"alternative repair branch spends exactly three iron")
 game.set_paused(false);approach(game,game.sect.EMISSARY);game.interact();game.sect.advance()
 check(p.journey.sect_stage==3 and p.journey.contribution==50 and p.journey.hunts==0,"aid report starts actual hunt chapter with no retroactive kills")
 game.set_paused(false);approach(game,game.sect.BEACON);game.interact()
 check(not game.sect.rite_active,"ritual cannot bypass three required monster species")
 for index in [0,3,6]:
  game.frontier.hit(game.frontier.enemies[index].id,10000)
 check(p.journey.hunts==7,"defeating actual wolf, boar and spider updates story kill objectives")
 approach(game,game.sect.BEACON);game.interact();await frames(90)
 check(game.sect.rite_active and not p.journey.rite and game.traveler.busy,"ritual has animated duration before completion")
 game.set_paused(true);var elapsed: float=game.sect.rite_elapsed;await frames(20)
 check(game.sect.rite_elapsed==elapsed,"menu pause freezes ritual progress")
 game.set_paused(false);Input.action_press("forward");await frames(2);Input.action_release("forward")
 check(not game.sect.rite_active and not p.journey.rite and p.journey.hunts==7,"moving cancels ritual while preserving earned hunt progress")
 approach(game,game.sect.BEACON);game.interact();await frames(245)
 check(p.journey.rite and not game.sect.rite_active and not game.traveler.busy,"completed ritual records seal and restores movement control")
 approach(game,game.sect.EMISSARY);game.interact();game.sect.advance()
 check(p.journey.sect_stage==4 and p.journey.contribution==130 and p.coins==coins+140 and p.expansion.gear.any(func(item):return item.id=="moss_robe"),"final report admits disciple and awards currency plus actual robe")
 game.sect.advance();check(p.coins==coins+140 and p.journey.contribution==130,"finished story cannot repeatedly award admission rewards")
 await frames(3);await capture("39-sect-membership")
 game.set_paused(false);approach(game,game.sect.BOARD+Vector3(0,0,-1));game.interact();game.sect.accept("trace")
 check(p.journey.contract=="trace" and p.journey.contract_clues==0,"physical board starts repeatable patrol with fresh progress")
 game.sect.claim_contract();check(p.journey.contribution==130,"old investigation cannot instantly complete new patrol")
 game.set_paused(false)
 for i in range(2):approach(game,game.sect.CLUES[i]);game.interact()
 approach(game,game.sect.BOARD+Vector3(0,0,-1));game.interact();game.sect.claim_contract()
 check(p.journey.contract.is_empty() and p.journey.contribution==155 and p.coins==coins+175,"repeatable field patrol awards contribution and coins once")
 game.sect.claim_contract();check(p.journey.contribution==155,"claimed contract cannot be paid twice")
 game.sect.accept("hunt");game.frontier.hit(game.frontier.enemies[4].id,10000);game.frontier.hit(game.frontier.enemies[5].id,10000)
 check(p.journey.contract_count==2,"repeatable hunting counts actual post-acceptance kills")
 check(game.save_game(false) and game.continue_game() and game.progress.journey.support==1 and game.progress.journey.contract_count==2,"sect branch, membership and unfinished contract survive save reload")
 p=game.progress
 var good: Dictionary=p.snapshot(Vector3(0,0.1,18))
 var rejected:=P.new();var before: Dictionary=rejected.snapshot(Vector3.ZERO)
 var bad: Dictionary=good.duplicate(true);bad.journey.support=0
 check(not rejected.restore(bad) and rejected.snapshot(Vector3.ZERO)==before,"inconsistent story save is rejected atomically")
 var legacy: Dictionary=good.duplicate(true);legacy.version=6;legacy.erase("journey")
 var original:=JSON.stringify(legacy);var file:=FileAccess.open(Game.SAVE,FileAccess.WRITE);file.store_string(original);file.close()
 check(game.continue_game() and game.progress.journey.sect_stage==0 and game.progress.coins==p.coins and game.progress.expansion.gear==p.expansion.gear,"v6 migration adds new story without resetting old money or equipment")
 check(FileAccess.get_file_as_string(Game.SAVE+".v6.bak")==original,"v6 migration preserves exact original backup")
 game.exiting=true;game.expedition.stop_ambience();await frames(3)
 game.queue_free();await process_frame
 print("RESULT: %d checks, %d failures"%[checks,failures]);quit(1 if failures else 0)
