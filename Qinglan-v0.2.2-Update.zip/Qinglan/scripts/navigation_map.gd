extends Control
## A lightweight map of the existing valley, drawn with the same world coordinates.

var game: Node3D
var navigator: Control

func map_rect() -> Rect2:
	var side := minf(size.x - 40, size.y - 40)
	return Rect2((size - Vector2.ONE * side) / 2, Vector2.ONE * side)

func world_point(at: Vector3) -> Vector2:
	var rect := map_rect()
	return rect.position + Vector2((at.x + 36) / 72, (at.z + 36) / 72) * rect.size

func landmark(at: Vector3, title: String, tint: Color, offset := Vector2(9, -9)) -> void:
	var point := world_point(at)
	draw_circle(point, 5, tint)
	draw_string(get_theme_default_font(), point + offset, title, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, tint)

func _draw() -> void:
	if game == null:
		return
	var rect := map_rect()
	draw_rect(rect, Color("263e37"))
	draw_rect(rect, Color("7c8c77"), false, 2)
	draw_string(get_theme_default_font(), rect.position + Vector2(12, 24), "北 ↑", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("ddd9bd"))
	for x in [-18, 0, 18]:
		draw_line(world_point(Vector3(x, 0, -36)), world_point(Vector3(x, 0, 36)), Color(0.5, 0.6, 0.5, 0.16), 1)
	for z in [-18, 0, 18]:
		draw_line(world_point(Vector3(-36, 0, z)), world_point(Vector3(36, 0, z)), Color(0.5, 0.6, 0.5, 0.16), 1)
	draw_line(world_point(Vector3(-19, 0, -36)), world_point(Vector3(-19, 0, 36)), Color("548483"), 13)
	draw_line(world_point(Vector3(0, 0, 25)), world_point(Vector3(0, 0, -25)), Color("9d9d7f"), 6)
	for at in [Vector3(-7, 0, 18), Vector3(8, 0, 22)]:
		draw_rect(Rect2(world_point(at) - Vector2(12, 10), Vector2(24, 20)), Color("747867"))
	draw_rect(Rect2(world_point(Vector3(16, 0, -36)), world_point(Vector3(33, 0, -18)) - world_point(Vector3(16, 0, -36))), Color("637269"))
	draw_rect(Rect2(world_point(Vector3(-30, 0, 13)), world_point(Vector3(-20, 0, 21)) - world_point(Vector3(-30, 0, 13))), Color("b29a69"), false, 3)
	if navigator.tracking:
		var points := PackedVector2Array([world_point(game.traveler.position)])
		for i in range(navigator.cursor, navigator.route.size()):
			points.append(world_point(navigator.route[i].at))
		if points.size() >= 2:
			draw_polyline(points, Color("f1ce81"), 3, true)
	landmark(Vector3(0, 0, -23), "北面残卷", Color("d8d6b4"))
	landmark(Vector3(24, 0, -28), "遗府", Color("d6b28a"), Vector2(8, 20))
	landmark(Vector3(13, 0, -8), "石角兽", Color("cd9b82"))
	landmark(Vector3(0, 0, 9), "静心台", Color("dbdaba"))
	landmark(Vector3(0, 0, 18), "村口", Color("dbdaba"), Vector2(9, 18))
	landmark(Vector3(-19, 0, 23.5), "小桥", Color("b7d5c7"), Vector2(6, 20))
	landmark(Vector3(-25, 0, 9), "灵田", Color("b1d6a5"), Vector2(-44, -10))
	landmark(Vector3(-25, 0, 22), "自己的洞府" if game.progress.home_claimed else "无主石室 · E认领", Color("f1ce81"), Vector2(-105, 27))
	var player := world_point(game.traveler.position)
	var facing: float = game.traveler.model.rotation.y
	var forward := Vector2(-sin(facing), -cos(facing))
	var side := Vector2(-forward.y, forward.x)
	draw_colored_polygon(PackedVector2Array([player + forward * 10, player - forward * 6 + side * 5, player - forward * 6 - side * 5]), Color("f6f1de"))
	draw_string(get_theme_default_font(), player + Vector2(12, -8), "你", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("ffffff"))
