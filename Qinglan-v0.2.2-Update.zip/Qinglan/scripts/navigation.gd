extends Control

const MapView = preload("res://scripts/navigation_map.gd")
const CLAIM := Vector3(-25, 0, 22)
var game: Node3D
var tracking := true
var route: Array[Dictionary] = []
var cursor := 0
var was_claimed := false
var refresh := 0.0
var guide: PanelContainer
var guide_title: Label
var guide_text: Label
var marker: PanelContainer
var marker_text: Label
var map_panel: PanelContainer
var map_view: Control
var map_text: Label
var map_track: Button
var path_root: Node3D
var breadcrumbs: Array[MeshInstance3D] = []

func panel_at(at: Vector2, minimum: Vector2) -> PanelContainer:
	var result := PanelContainer.new()
	result.position = at
	result.custom_minimum_size = minimum
	var style: StyleBoxFlat = game.quest_panel.get_theme_stylebox("panel").duplicate()
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 14
	style.content_margin_bottom = 14
	result.add_theme_stylebox_override("panel", style)
	add_child(result)
	return result

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	guide = panel_at(Vector2(930, 126), Vector2(316, 218))
	guide.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	guide.add_child(column)
	guide_title = game.label("安家 · 认领洞府", 22, Color("e7ce95"))
	column.add_child(guide_title)
	guide_text = game.label("", 17)
	guide_text.custom_minimum_size.x = 280
	guide_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(guide_text)
	marker = panel_at(Vector2.ZERO, Vector2(290, 58))
	marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	marker_text = game.label("", 18, Color("f1d89f"))
	marker_text.custom_minimum_size.x = 254
	marker_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	marker_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	marker.add_child(marker_text)
	build_map()
	build_path_markers()
	refresh_ui()

func build_map() -> void:
	map_panel = panel_at(Vector2(40, 35), Vector2(1200, 610))
	var map_style: StyleBoxFlat = map_panel.get_theme_stylebox("panel").duplicate()
	map_style.bg_color = Color("0d1b18")
	map_panel.add_theme_stylebox_override("panel", map_style)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	map_panel.add_child(column)
	column.add_child(game.label("青 岚 谷 · 洞府路线", 28, Color("e7ce95")))
	var content := HBoxContainer.new()
	content.add_theme_constant_override("separation", 20)
	column.add_child(content)
	map_view = MapView.new()
	map_view.game = game
	map_view.navigator = self
	map_view.custom_minimum_size = Vector2(750, 450)
	map_view.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(map_view)
	var details := VBoxContainer.new()
	details.add_theme_constant_override("separation", 16)
	content.add_child(details)
	map_text = game.label("", 18)
	map_text.custom_minimum_size.x = 320
	map_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	details.add_child(map_text)
	map_track = game.button("开始引路 · 认领洞府", start_tracking, details)
	game.button("关闭地图 · 返回游戏", close_map, details)
	column.add_child(game.label("金线：推荐路线   白色箭头：你的位置与朝向   M / Esc：关闭地图", 16))
	map_panel.hide()

func build_path_markers() -> void:
	path_root = Node3D.new()
	game.valley.add_child(path_root)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color("dcc18a")
	var mesh := CylinderMesh.new()
	mesh.top_radius = 0.13
	mesh.bottom_radius = 0.13
	mesh.height = 0.035
	mesh.radial_segments = 8
	for i in range(16):
		var point := MeshInstance3D.new()
		point.mesh = mesh
		point.material_override = mat
		point.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		path_root.add_child(point)
		breadcrumbs.append(point)
	# Physical signs stay useful even when the optional HUD tracking is disabled.
	var v = game.valley
	v.sign_text("自己的洞府 ←\n村口南侧绕行 · 过桥按 E 认领", Vector3(-3.5, 2.8, 14.5), 27, Color("e7ce95"))
	v.sign_text("村西小桥 → 无主石室\n开局可认领", Vector3(-15, 2.1, 22), 27, Color("e7ce95"))
	for x in [-16.3, -21.7]:
		v.cylinder(Vector3(x, 0.6, 25.2), 0.04, 0.06, 1.2, v.wood)
		v.box(Vector3(x, 1.35, 25.2), Vector3(0.25, 0.35, 0.25), v.material("cfbb85", true))

func add_waypoint(at: Vector3, hint: String) -> void:
	route.append({"at": at, "hint": hint})

func plan_route() -> void:
	route.clear()
	cursor = 0
	var at: Vector3 = game.traveler.position
	# Routes go around the village houses and the home doorposts, rather than
	# drawing a straight line through the nearest building.
	if at.x < -20:
		if at.x > -29 and at.x < -21 and at.z > 13.5 and at.z < 21:
			add_waypoint(Vector3(-25, 0, 20), "走到石室门口")
		elif at.z < 21:
			add_waypoint(Vector3(-31.5, 0, minf(at.z, 11.5)), "从石室西侧绕行")
			add_waypoint(Vector3(-31.5, 0, 24), "绕到石室正门")
		add_waypoint(Vector3(-25, 0, 24), "走到正门前")
	else:
		if at.x >= 33 and at.z < -17:
			add_waypoint(Vector3(34, 0, -16), "沿遗府外墙向南")
		elif at.x > 17.2 and at.z < -18.5:
			add_waypoint(Vector3(24, 0, -16), "从遗府石门出去")
		elif absf(at.x) < 5 and at.z < -27.4:
			add_waypoint(Vector3(5.5, 0, at.z), "绕过北面洞府外墙")
			add_waypoint(Vector3(5.5, 0, -20), "沿洞府外侧向南")
		elif absf(at.x) < 2 and at.z < -22.5:
			add_waypoint(Vector3(1.4, 0, at.z), "绕过残卷石台")
			add_waypoint(Vector3(1.4, 0, -20), "离开北面洞府")
		if at.x < -10:
			if at.z < 21:
				add_waypoint(Vector3(-12, 0, 23.5), "绕过村西房屋")
		elif at.x < -4 and at.z < 16:
			add_waypoint(Vector3(-12, 0, 11), "沿村庄西侧向南")
			add_waypoint(Vector3(-12, 0, 23.5), "绕过村西房屋")
		elif at.x > 4 and at.z > 16:
			if at.z < 24.5:
				add_waypoint(Vector3(12, 0, minf(at.z, 18)), "绕到村东房屋外侧")
				add_waypoint(Vector3(12, 0, 26.5), "从房屋南侧绕行")
			add_waypoint(Vector3(0, 0, 26.5), "回到村口南侧")
			add_waypoint(Vector3(-11, 0, 23.5), "向西前往小桥")
		else:
			if at.z < 16:
				add_waypoint(Vector3(0, 0, 7), "沿石径返回村口")
			add_waypoint(Vector3(0, 0, 23.5), "从村口南侧绕过房屋")
			add_waypoint(Vector3(-11, 0, 23.5), "向西前往小桥")
		add_waypoint(Vector3(-15.5, 0, 23.5), "走到村西小桥")
		add_waypoint(Vector3(-19, 0, 23.5), "过桥，前往无主石室")
		add_waypoint(Vector3(-25, 0, 24), "从石室正门前接近")
	add_waypoint(CLAIM, "门前按 E 认领" if not game.progress.home_claimed else "自己的洞府")

func reset() -> void:
	hide_map()
	was_claimed = game.progress.home_claimed
	tracking = not was_claimed
	plan_route()
	refresh_ui()

func start_tracking() -> void:
	tracking = true
	plan_route()
	if map_panel.visible:
		close_map()
	game.notify("沿金色地面引路点走，到无主石室门前按 E。洞府开局即可认领。" if not game.progress.home_claimed else "已显示回到自己洞府的步行路线。")
	refresh_ui()

func toggle_tracking() -> void:
	if tracking:
		tracking = false
		game.notify("洞府引路已隐藏。N 再次显示，M 查看地图。")
	else:
		start_tracking()
	refresh_ui()

func open_map() -> void:
	game.set_paused(true)
	game.pause_panel.hide()
	map_panel.show()
	refresh_ui()
	map_view.queue_redraw()

func hide_map() -> void:
	map_panel.hide()

func close_map() -> void:
	hide_map()
	game.set_paused(false)

func current_waypoint() -> Vector3:
	return route[cursor].at if cursor < route.size() else CLAIM

func route_distance() -> float:
	var total := 0.0
	var at: Vector3 = game.traveler.position
	for i in range(cursor, route.size()):
		var next: Vector3 = route[i].at
		total += Vector2(at.x - next.x, at.z - next.z).length()
		at = next
	return total

func _process(delta: float) -> void:
	visible = game.playing
	guide.visible = game.playing and not map_panel.visible
	path_root.visible = game.playing and tracking
	if not game.playing:
		return
	if game.progress.home_claimed != was_claimed:
		was_claimed = game.progress.home_claimed
		if was_claimed:
			tracking = false
	if tracking and not game.paused:
		while cursor < route.size() - 1 and game.traveler.position.distance_to(route[cursor].at) < 1.1:
			cursor += 1
	refresh -= delta
	if refresh <= 0:
		refresh = 0.12
		refresh_ui()
	update_marker()

func refresh_ui() -> void:
	guide_title.text = "安家 · 认领自己的洞府" if not game.progress.home_claimed else "安家 · 你的洞府"
	if game.progress.home_claimed:
		guide_text.text = "洞府已归你所有。\nH 脱战回府，M 查看地图。\n屋内：储物箱、蒲团、陈设石台\n屋外北侧：三块灵田\nN 显示 / 隐藏步行引路"
	else:
		guide_text.text = "开局可直接认领，无需通关遗府。\n村口南侧 → 村西小桥 → 无主石室\n门前按 E，认领后 H 可回府。\n%s\nM 地图 · N 显示 / 隐藏引路" % ("沿金色引路点走，约 %d 米" % ceili(route_distance()) if tracking else "引路已隐藏")
	map_text.text = ("你的洞府\n\n" if game.progress.home_claimed else "认领自己的洞府\n\n开局即可，无需境界或战斗条件。\n\n")
	map_text.text += "1. 绕到村口南侧\n2. 向西走，经过小桥\n3. 无主石室门前按 E\n\n认领后：\nH 脱战回府\n箱子 E 储物\n蒲团 E 调息 / G 修炼\n三块灵田 E 播种 / 收获\n\n引路需要用 WASD 手动行走。"
	map_track.text = "显示回府步行路线" if game.progress.home_claimed else "开始引路 · 去认领洞府"
	map_view.queue_redraw()
	update_breadcrumbs()

func update_marker() -> void:
	marker.visible = game.playing and tracking and not game.paused
	if not marker.visible:
		return
	var camera: Camera3D = game.traveler.camera
	var at := current_waypoint() + Vector3.UP
	var facing: Vector3 = -camera.global_basis.z * Vector3(1, 0, 1)
	var behind := camera.is_position_behind(at) or facing.dot(current_waypoint() - game.traveler.position) < 0
	var point := camera.unproject_position(at)
	if behind:
		var local := camera.to_local(at)
		point = Vector2(640 + signf(local.x) * 520, 530)
	point.x = clampf(point.x - 145, 36, 954)
	point.y = clampf(point.y - 45, 110, 430)
	if point.y < 400 and (point.x < 350 or point.x > 900):
		point.y = 410
	marker.position = point
	var distance: float = game.traveler.position.distance_to(current_waypoint())
	var hint: String = route[cursor].hint if cursor < route.size() else "门前按 E"
	marker_text.text = ("转身 · " if behind else "引路 · ") + hint + "\n%d 米" % ceili(distance)

func update_breadcrumbs() -> void:
	for point in breadcrumbs:
		point.hide()
	if not tracking or not game.playing:
		return
	var at: Vector3 = game.traveler.position
	var used := 0
	for i in range(cursor, route.size()):
		var destination: Vector3 = route[i].at
		var start := Vector3(at.x, 0, at.z)
		var end := Vector3(destination.x, 0, destination.z)
		var length := start.distance_to(end)
		var direction := (end - start).normalized()
		var distance := 1.4
		while distance < length and used < breadcrumbs.size():
			breadcrumbs[used].position = start + direction * distance + Vector3.UP * 0.19
			breadcrumbs[used].show()
			used += 1
			distance += 1.6
		at = destination
		if used == breadcrumbs.size():
			break
