extends SceneTree
## Run through tools/check.py, which isolates all save files in a temporary project.

const Progress = preload("res://scripts/progress.gd")
const Game = preload("res://scripts/game.gd")
var checks := 0
var failures := 0
var capture_dir := ""

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-dir="):
			capture_dir = arg.trim_prefix("--capture-dir=")
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	checks += 1
	if condition:
		print("PASS: " + description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func frames(count: int) -> void:
	for i in range(count):
		await physics_frame

func capture(name: String) -> void:
	if capture_dir.is_empty():
		return
	await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	check(image.save_png(capture_dir.path_join(name + ".png")) == OK, "render capture " + name)

func run() -> void:
	var state = Progress.new()
	check(not state.cast(), "unlearned spell is blocked")
	check(not state.breakthrough(), "breakthrough needs all prerequisites")
	check(state.gather(0) and not state.gather(0), "harvest is awarded once")
	check(not state.gather(-1) and not state.gather(5), "out of range resource IDs are rejected")
	state.learned = true
	state.qi = 13
	check(not state.cast() and state.qi == 13, "insufficient qi does not spend resource")
	var data: Dictionary = state.snapshot(Vector3.ZERO)
	var restored = Progress.new()
	check(restored.restore(JSON.parse_string(JSON.stringify(data))), "JSON save roundtrip")
	for invalid in [null, {}, {"version": 900}]:
		check(not restored.restore(invalid), "invalid save rejected")
	var corrupt: Dictionary = data.duplicate(true)
	corrupt.collected = [0, 0]
	check(not restored.restore(corrupt), "duplicate harvest IDs in save rejected")
	corrupt = data.duplicate(true)
	corrupt.position = [999, 0, 0]
	check(not restored.restore(corrupt), "out of valley save rejected")
	corrupt = data.duplicate(true)
	corrupt.realm = 1
	check(not restored.restore(corrupt), "impossible progression rejected")
	check(restored.character_name == "无名" and restored.realm == 0, "invalid save does not mutate live state")
	var game = Game.new()
	root.add_child(game)
	await frames(3)
	await capture("01-character")
	game.name_input.text = "青禾"
	game.robe_input.select(1)
	game.request_new()
	check(game.playing and game.progress.character_name == "青禾" and game.progress.robe == 1, "create named character and select robe")
	await frames(8)
	var start: Vector3 = game.traveler.position
	Input.action_press("forward")
	await frames(30)
	Input.action_release("forward")
	check(game.traveler.position.z < start.z - 1.0, "physics input moves traveler forward")
	check(game.traveler.is_on_floor() and absf(game.traveler.position.y) < 0.2, "player collides with the valley floor")
	var before: Vector3 = game.traveler.position
	game.set_paused(true)
	Input.action_press("forward")
	await frames(10)
	Input.action_release("forward")
	check(game.traveler.position.is_equal_approx(before), "pause stops movement")
	game.set_paused(false)
	check(not game.cast_sword(), "scene blocks attack before learning")
	await capture("02-valley")
	game.traveler.position = Vector3(0, 0.1, -21)
	game.interact()
	check(game.progress.learned, "interact with cave scroll learns sword spell")
	for id in range(3):
		for point in game.valley.interactions:
			if point.kind == "herb" and point.id == id:
				game.traveler.position = point.position + Vector3.UP * 0.1
				game.interact()
	check(game.progress.herbs() == 3, "harvest three distinct herbs through world interactions")
	var resources: int = game.progress.herbs()
	game.interact()
	check(game.progress.herbs() == resources, "repeat interaction cannot duplicate herb")
	game.traveler.position = game.valley.altar + Vector3.UP * 0.1
	game.interact()
	check(game.progress.realm == 0, "altar blocks breakthrough without beast core")
	game.traveler.position = game.valley.beast.position + Vector3(1.4, 0.1, 0)
	game.enemy_cooldown = 0
	var hp_before_hit: float = game.progress.hp
	await frames(45)
	check(game.progress.hp < hp_before_hit, "telegraphed beast strike damages nearby player")
	game.traveler.position = game.valley.beast.position + Vector3(1.4, 0.1, 0)
	game.windup = 0.12
	var hp_before_dodge: float = game.progress.hp
	Input.action_press("dodge")
	await frames(1)
	Input.action_release("dodge")
	await frames(12)
	check(game.progress.hp == hp_before_dodge, "space dodge avoids telegraphed strike")
	game.traveler.invincible = 0
	game.traveler.position = game.valley.beast.position + Vector3(1.4, 0.1, 0)
	game.progress.hp = 18
	game.windup = 0.01
	await frames(2)
	check(game.progress.hp == 100 and game.traveler.position.distance_to(game.valley.altar) < 3, "defeat respawns player safely at altar")
	check(game.progress.herbs() == 3 and game.beast_hp == 112, "defeat keeps inventory and resets living beast")
	game.traveler.position = Vector3(10, 0.1, -8)
	game.traveler.yaw = -1.2
	await frames(2)
	var successful_casts := 0
	for i in range(4):
		if game.cast_sword():
			successful_casts += 1
		if i == 0:
			game.set_paused(true)
			var hp_before: float = game.beast_hp
			await frames(15)
			check(game.beast_hp == hp_before, "pause also stops in-flight sword damage")
			game.set_paused(false)
		await frames(38)
	check(successful_casts == 4, "four timed sword casts execute")
	check(game.progress.beast_dead and game.progress.core and not game.valley.beast.visible, "sword hits defeat beast and award one core")
	game.traveler.position = game.valley.altar + Vector3.UP * 0.1
	game.interact()
	check(game.progress.realm == 1 and game.progress.herbs() == 0 and not game.progress.core, "altar consumes materials and advances realm")
	check(game.progress.hp == 140 and game.progress.max_qi() == 140, "breakthrough raises health and qi limits")
	check(not game.progress.breakthrough(), "cannot repeat the same breakthrough")
	game.traveler.position = Vector3(0, 0.1, 13)
	game.traveler.yaw = 0
	game.update_hud()
	await frames(3)
	await capture("03-breakthrough")
	check(game.save_game(false), "save file written atomically")
	game.progress.character_name = "changed"
	check(game.continue_game() and game.progress.character_name == "青禾" and game.progress.realm == 1, "continue restores identity and realm")
	check(game.progress.collected.size() == 3 and game.progress.beast_dead and not game.valley.beast.visible, "continue preserves harvested resources and defeated beast")
	var file := FileAccess.open(Game.SAVE, FileAccess.WRITE)
	file.store_string("{broken-json")
	file.close()
	check(not game.continue_game() and game.progress.character_name == "青禾", "corrupt save fails safely without changing active character")
	check(ProjectSettings.globalize_path(Game.SAVE).begins_with(ProjectSettings.globalize_path("res://")), "save is inside project, not the OS profile")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
