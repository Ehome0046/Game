extends RefCounted
## Pure gameplay state. No renderer or device-specific input dependencies.

const VERSION := 1
const HERB_COUNT := 5
const ROBES := ["青灰", "墨绿", "赭红"]
var character_name := "无名"
var robe := 0
var learned := false
var collected: Array[int] = []
var core := false
var beast_dead := false
var realm := 0
var hp := 100.0
var qi := 100.0

func max_hp() -> float:
	return 140.0 if realm == 1 else 100.0

func max_qi() -> float:
	return 140.0 if realm == 1 else 100.0

func herbs() -> int:
	return collected.size() - (3 if realm == 1 else 0)

func gather(id: int) -> bool:
	if id < 0 or id >= HERB_COUNT or id in collected:
		return false
	collected.append(id)
	return true

func cast() -> bool:
	if not learned or qi < 14.0 or hp <= 0.0:
		return false
	qi -= 14.0
	return true

func breakthrough() -> bool:
	if realm != 0 or not learned or not core or herbs() < 3:
		return false
	realm = 1
	core = false
	hp = max_hp()
	qi = max_qi()
	return true

func snapshot(position: Vector3) -> Dictionary:
	return {"version": VERSION, "name": character_name, "robe": robe,
		"learned": learned, "collected": collected.duplicate(), "core": core,
		"beast_dead": beast_dead, "realm": realm, "hp": hp, "qi": qi,
		"position": [position.x, position.y, position.z]}

func restore(data: Variant) -> bool:
	# Validate the entire save before changing live state.
	if not data is Dictionary:
		return false
	for key in ["version", "name", "robe", "learned", "collected", "core", "beast_dead", "realm", "hp", "qi", "position"]:
		if not data.has(key):
			return false
	if data.version != VERSION or not data.name is String or data.name.strip_edges().is_empty() or data.name.length() > 16:
		return false
	for key in ["learned", "core", "beast_dead"]:
		if not data[key] is bool:
			return false
	for key in ["robe", "realm", "hp", "qi"]:
		if not (data[key] is int or data[key] is float) or not is_finite(float(data[key])):
			return false
	if data.robe != int(data.robe) or data.robe < 0 or data.robe >= ROBES.size():
		return false
	if data.realm != int(data.realm) or int(data.realm) not in [0, 1]:
		return false
	if not data.collected is Array or data.collected.size() > HERB_COUNT:
		return false
	var ids: Array[int] = []
	for id in data.collected:
		if not (id is int or id is float) or not is_finite(float(id)):
			return false
		if id != int(id) or id < 0 or id >= HERB_COUNT or int(id) in ids:
			return false
		ids.append(int(id))
	if data.core and not data.beast_dead:
		return false
	if data.realm == 1 and (not data.learned or not data.beast_dead or data.core or ids.size() < 3):
		return false
	if not data.position is Array or data.position.size() != 3:
		return false
	for n in data.position:
		if not (n is int or n is float) or not is_finite(float(n)) or absf(float(n)) > 100.0:
			return false
	if absf(float(data.position[0])) > 36.0 or absf(float(data.position[2])) > 36.0 or float(data.position[1]) < 0 or float(data.position[1]) > 5:
		return false
	var limit: float = 140.0 if data.realm == 1 else 100.0
	if data.hp <= 0 or data.hp > limit or data.qi < 0 or data.qi > limit:
		return false
	character_name = data.name
	robe = int(data.robe)
	learned = data.learned
	collected = ids
	core = data.core
	beast_dead = data.beast_dead
	realm = int(data.realm)
	hp = float(data.hp)
	qi = float(data.qi)
	return true
