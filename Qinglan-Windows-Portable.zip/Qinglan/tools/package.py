#!/usr/bin/env python3
"""Build a portable project ZIP without saves, caches, Git metadata or test data."""
from pathlib import Path
import argparse
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("--with-engine", action="store_true")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
destination = root / "dist"
destination.mkdir(exist_ok=True)
output = destination / ("Qinglan-Windows-Portable.zip" if args.with_engine else "Qinglan-Source.zip")
files = [root / name for name in ["README.md", ".gitignore", "Start-Game.cmd", "project.godot"]]
for folder in ["docs", "scenes", "scripts", "shaders", "tests", "third_party"]:
    files.extend(p for p in (root / folder).rglob("*") if p.is_file())
files.extend([root / "tools/check.py", root / "tools/package.py"])
if args.with_engine:
    engine = root / "tools/godot/Godot.exe"
    if not engine.is_file():
        raise SystemExit("Missing tools/godot/Godot.exe; see Windows quickstart")
    for license_name in ["LICENSE.txt", "COPYRIGHT.txt", "ORIGIN.md"]:
        if not (root / "third_party/godot" / license_name).is_file():
            raise SystemExit("Missing Godot license/provenance: " + license_name)
    files.extend([engine, root / "tools/godot/_sc_"])
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        content = path.read_bytes()
        if path.suffix == ".cmd":
            content = content.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        archive.writestr("Qinglan/" + path.relative_to(root).as_posix(), content)
    engine_note = ("便携包已附带 Godot 引擎，无需安装。" if args.with_engine else
                   "此为源码包，先按 docs\\windows-quickstart.md 准备便携 Godot 引擎。")
    archive.writestr("Qinglan/开始前必读.txt", f"""青岚问道 · 初入仙途（玩法原型）

1. 将整个 Qinglan 文件夹解压到 D:\\GameDev 下，不要放到 C 盘。
2. {engine_note} 双击 Start-Game.cmd 启动。
3. 创建角色，沿石径向北在洞府参悟残卷，采三株灵草，御剑击败妖兽，回静心台突破。
4. WASD 移动，鼠标转向，E 交互，Q/左键御剑，空格闪避，Esc 暂停，F5 保存。
5. 这是采用简单占位模型的玩法原型，不是最终写实画面。Windows 本机尚待实测。

存档：.local\\saves。请不要误删；创建新角色前会询问是否覆盖。
更多说明：docs\\windows-quickstart.md。
""".encode("utf-8-sig"))
    if not archive.testzip() is None:
        raise SystemExit("ZIP CRC check failed")
with zipfile.ZipFile(output) as archive:
    names = archive.namelist()
    if any("/.local/" in n or "/.git/" in n or "/.godot/" in n for n in names):
        raise SystemExit("Unexpected private data or cache in artifact")
    print(f"{output}: {output.stat().st_size / 1024**2:.1f} MiB, {len(names)} files")
