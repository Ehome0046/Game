# 青岚问道 · 初入仙途

原创角色、单人第三人称 3D 修仙玩法原型。长期方向为写实国风；当前使用自制几何占位模型，不代表最终画质。首段流程包含创建角色、探索洞府、采药、御剑战斗、首次突破与存档。

- [Windows 试玩与非 C 盘路径说明](docs/windows-quickstart.md)
- [玩法与美术方向](docs/game-vision.md)

使用 Godot **4.6.3 标准版**，无需 .NET 或第三方插件。打开 `project.godot`，或在项目根目录运行：

```sh
godot --path . --log-file .local/logs/game.log
```

Windows 便携包请解压到 D/E 盘后运行 `Start-Game.cmd`。当前为源码工程加便携引擎，不是正式发行版。存档位于项目内 `.local/saves`，重新解压更新时请保留。

开发检查（Python 3 + Godot；在临时项目内运行，不触碰玩家存档）：

```sh
python3 tools/check.py
# 在有 X11 显示服务的 Linux 环境中验证渲染并截图：
python3 tools/check.py --capture-dir /tmp/qinglan-captures
```

按键：WASD 移动，鼠标转向，Shift 奔跑，空格闪避，E 交互，Q/左键御剑，Tab/Esc 暂停，F5 保存。
