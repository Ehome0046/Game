@echo off
setlocal
rem Process-local paths only: no registry edits or global environment changes.
if /I "%~d0"=="C:" (
  echo Please extract the entire Qinglan folder to D: or E: first.
  echo This launcher will not start a project stored on C:.
  pause
  exit /b 1
)
set "PROJECT_DIR=%~dp0"
set "ENGINE=%PROJECT_DIR%tools\godot\Godot.exe"
if not exist "%ENGINE%" (
  echo Missing portable Godot: tools\godot\Godot.exe
  echo See docs\windows-quickstart.md for the official download.
  pause
  exit /b 1
)
set "APPDATA=%PROJECT_DIR%.local\profile\Roaming"
set "LOCALAPPDATA=%PROJECT_DIR%.local\profile\Local"
set "TEMP=%PROJECT_DIR%.local\temp"
set "TMP=%TEMP%"
for %%D in ("%APPDATA%" "%LOCALAPPDATA%" "%TEMP%" "%PROJECT_DIR%.local\logs") do (
  if not exist "%%~D" mkdir "%%~D"
  if not exist "%%~D" (
    echo Cannot create runtime directories. Check free space and permissions.
    pause
    exit /b 1
  )
)
rem Godot self-contained mode keeps editor settings beside the portable engine.
if not exist "%PROJECT_DIR%tools\godot\_sc_" type nul > "%PROJECT_DIR%tools\godot\_sc_"
pushd "%PROJECT_DIR%"
"%ENGINE%" --path "%PROJECT_DIR%." --rendering-method gl_compatibility --log-file "%PROJECT_DIR%.local\logs\game.log" %*
set "RESULT=%ERRORLEVEL%"
popd
if not "%RESULT%"=="0" (
  echo Game exited with error %RESULT%. See .local\logs\game.log.
  pause
)
exit /b %RESULT%
