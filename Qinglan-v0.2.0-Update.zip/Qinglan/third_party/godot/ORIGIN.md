# Portable Godot provenance

Version: 4.6.3-stable, official Windows x86_64 standard editor.

Downloaded from https://github.com/godotengine/godot-builds/releases/download/4.6.3-stable/Godot_v4.6.3-stable_win64.exe.zip

The downloaded archive was verified against the official release SHA512-SUMS.txt before extraction:

```text
d44ea7ef5bab754cacd49d581b6062836b2eea12a82e1d183aebfad9cd8c7db2bd82513337bd657d6d2d5c04d46239c0570b029faf1343e81e8a2fa7b85dd83b  Godot_v4.6.3-stable_win64.exe.zip
```

The main editor executable is included as tools/godot/Godot.exe, unchanged apart from its filename. It runs the source project in game mode; this is not an exported standalone game binary. Extracted executable SHA-256:

```text
ef90e929ba1a6a4322860285d97f40f4aa349c90329a91b0e8b55b8df0f4cb00
```

LICENSE.txt and COPYRIGHT.txt are taken from the corresponding official godotengine/godot 4.6.3-stable source tag. No engine modifications were made. The optional Windows console wrapper is not included.
