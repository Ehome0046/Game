shader_type spatial;
render_mode diffuse_burley;
varying vec3 world_position;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x),
		mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

void vertex() {
	world_position = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 p = world_position.xz;
	float moss = noise(p * 0.33) * 0.65 + noise(p * 1.8) * 0.25 + noise(p * 9.0) * 0.1;
	ALBEDO = mix(vec3(0.12, 0.135, 0.10), vec3(0.24, 0.29, 0.19), moss);
	ROUGHNESS = 0.96;
}
