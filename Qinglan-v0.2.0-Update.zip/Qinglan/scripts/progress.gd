extends RefCounted
## Pure gameplay state. No renderer or device-specific input dependencies.

const VERSION := 2
const HERB_COUNT := 5
const ROBES := ["青灰", "墨绿", "赭红"]
var character_name := "无名"
var robe := 0
var learned := false
var collected: Array[int] = []
var core := false
var beast_dead := false
var realm := 0
var hp := 100.0
var qi := 100.0
var herb_stock := 0
var home_claimed := false
var home_style := 0
var vault_herbs := 0
var seeds := 0
var plots: Array[float] = [-1.0, -1.0, -1.0]
var world_time := 0.0
var cultivation := 0
var runes := 0
var spitter_dead := false
var guardian_dead := false
var relic := false
const GROW_SECONDS := 90.0

func max_hp() -> float:
	return (140.0 if realm == 1 else 100.0) + cultivation * 5

func max_qi() -> float:
	return (140.0 if realm == 1 else 100.0) + cultivation * 10

func herbs() -> int:
	return herb_stock

func gather(id: int) -> bool:
	if id < 0 or id >= HERB_COUNT or id in collected:
		return false
	collected.append(id)
	herb_stock += 1
	return true

func cast() -> bool:
	if not learned or qi < 14.0 or hp <= 0.0:
		return false
	qi -= 14.0
	return true

func breakthrough() -> bool:
	if realm != 0 or not learned or not core or herbs() < 3:
		return false
	realm = 1
	herb_stock -= 3
	core = false
	hp = max_hp()
	qi = max_qi()
	return true

func spend_qi(amount: float) -> bool:
	if not learned or amount <= 0 or qi < amount or hp <= 0:
		return false
	qi -= amount
	return true

func claim_home() -> bool:
	if home_claimed:
		return false
	home_claimed = true
	seeds += 3
	return true

func plant_or_harvest(id: int) -> String:
	if not home_claimed or id < 0 or id >= plots.size():
		return "先认领洞府，才能使用灵田。"
	if plots[id] < 0:
		if seeds <= 0:
			return "没有灵种。遗府传承也会赠送灵种。"
		seeds -= 1
		plots[id] = world_time + GROW_SECONDS
		return "种下灵草：游玩 90 秒后成熟，暂停与离线不计时。"
	if world_time < plots[id]:
		return "灵草尚未成熟，还需 %d 秒。" % ceili(plots[id] - world_time)
	plots[id] = -1
	herb_stock += 2
	seeds += 1
	return "收获两株灵草，并回收一枚灵种。"

func transfer_herb(to_vault: bool) -> bool:
	if not home_claimed:
		return false
	if to_vault:
		if herb_stock <= 0:
			return false
		herb_stock -= 1
		vault_herbs += 1
	else:
		if vault_herbs <= 0:
			return false
		vault_herbs -= 1
		herb_stock += 1
	return true

func cultivate() -> bool:
	if not home_claimed or not learned or herbs() < 2 or cultivation >= 3:
		return false
	herb_stock -= 2
	cultivation += 1
	hp = max_hp()
	qi = max_qi()
	return true

func activate_rune(id: int) -> bool:
	if runes == 3 or id < 0 or id > 2:
		return false
	if id != runes:
		runes = 0
		return false
	runes += 1
	return true

func take_relic() -> bool:
	if relic or not guardian_dead or runes != 3 or realm != 1:
		return false
	relic = true
	seeds += 3
	return true

func snapshot(position: Vector3) -> Dictionary:
	return {"version": VERSION, "name": character_name, "robe": robe,
		"learned": learned, "collected": collected.duplicate(), "core": core,
		"beast_dead": beast_dead, "realm": realm, "hp": hp, "qi": qi,
		"position": [position.x, position.y, position.z],
		"herb_stock": herb_stock, "home_claimed": home_claimed, "vault_herbs": vault_herbs,
		"home_style": home_style,
		"seeds": seeds, "plots": plots.duplicate(), "world_time": world_time,
		"cultivation": cultivation, "runes": runes, "spitter_dead": spitter_dead,
		"guardian_dead": guardian_dead, "relic": relic}

func restore(data: Variant) -> bool:
	# Validate the entire save before changing live state.
	if not data is Dictionary:
		return false
	for key in ["version", "name", "robe", "learned", "collected", "core", "beast_dead", "realm", "hp", "qi", "position"]:
		if not data.has(key):
			return false
	if data.version != 1 and data.version != VERSION:
		return false
	if not data.name is String or data.name.strip_edges().is_empty() or data.name.length() > 16:
		return false
	for key in ["learned", "core", "beast_dead"]:
		if not data[key] is bool:
			return false
	for key in ["robe", "realm", "hp", "qi"]:
		if not (data[key] is int or data[key] is float) or not is_finite(float(data[key])):
			return false
	if data.robe != int(data.robe) or data.robe < 0 or data.robe >= ROBES.size():
		return false
	if data.realm != int(data.realm) or int(data.realm) not in [0, 1]:
		return false
	if not data.collected is Array or data.collected.size() > HERB_COUNT:
		return false
	var ids: Array[int] = []
	for id in data.collected:
		if not (id is int or id is float) or not is_finite(float(id)):
			return false
		if id != int(id) or id < 0 or id >= HERB_COUNT or int(id) in ids:
			return false
		ids.append(int(id))
	if data.core and not data.beast_dead:
		return false
	if data.realm == 1 and (not data.learned or not data.beast_dead or data.core):
		return false
	if not data.position is Array or data.position.size() != 3:
		return false
	for n in data.position:
		if not (n is int or n is float) or not is_finite(float(n)) or absf(float(n)) > 100.0:
			return false
	if absf(float(data.position[0])) > 36.0 or absf(float(data.position[2])) > 36.0 or float(data.position[1]) < 0 or float(data.position[1]) > 5:
		return false
	var extra := {"herb_stock": ids.size() - (3 if data.realm == 1 else 0), "home_claimed": false,
		"vault_herbs": 0, "seeds": 0, "plots": [-1.0, -1.0, -1.0], "world_time": 0.0,
		"cultivation": 0, "runes": 0, "spitter_dead": false, "guardian_dead": false, "relic": false}
	extra["home_style"] = 0
	if data.version == VERSION:
		for key in extra:
			if not data.has(key):
				return false
			extra[key] = data[key]
	for key in ["home_claimed", "spitter_dead", "guardian_dead", "relic"]:
		if not extra[key] is bool:
			return false
	for key in ["herb_stock", "vault_herbs", "seeds", "cultivation", "runes", "world_time", "home_style"]:
		if not (extra[key] is int or extra[key] is float) or not is_finite(float(extra[key])) or extra[key] < 0:
			return false
		if key != "world_time" and (extra[key] != int(extra[key]) or extra[key] > 100000):
			return false
	if extra.cultivation > 3 or extra.runes > 3 or extra.home_style > 2 or extra.world_time > 100000000:
		return false
	if not extra.plots is Array or extra.plots.size() != 3:
		return false
	for time in extra.plots:
		if not (time is int or time is float) or not is_finite(float(time)):
			return false
		if time != -1 and (time < 0 or time > extra.world_time + GROW_SECONDS + 0.1):
			return false
	if not extra.home_claimed and (extra.vault_herbs != 0 or extra.cultivation != 0 or extra.plots != [-1.0, -1.0, -1.0]):
		return false
	if extra.guardian_dead and extra.runes != 3:
		return false
	if (extra.cultivation > 0 or extra.runes > 0) and not data.learned:
		return false
	if extra.relic and (not extra.guardian_dead or data.realm != 1):
		return false
	var limit: float = (140.0 if data.realm == 1 else 100.0)
	if data.hp <= 0 or data.hp > limit + extra.cultivation * 5 or data.qi < 0 or data.qi > limit + extra.cultivation * 10:
		return false
	character_name = data.name
	robe = int(data.robe)
	learned = data.learned
	collected = ids
	core = data.core
	beast_dead = data.beast_dead
	realm = int(data.realm)
	hp = float(data.hp)
	qi = float(data.qi)
	herb_stock = int(extra.herb_stock)
	home_claimed = extra.home_claimed
	home_style = int(extra.home_style)
	vault_herbs = int(extra.vault_herbs)
	seeds = int(extra.seeds)
	plots.assign(extra.plots)
	world_time = float(extra.world_time)
	cultivation = int(extra.cultivation)
	runes = int(extra.runes)
	spitter_dead = extra.spitter_dead
	guardian_dead = extra.guardian_dead
	relic = extra.relic
	return true
