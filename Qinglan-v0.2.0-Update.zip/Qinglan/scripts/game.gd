extends Node3D

const Progress = preload("res://scripts/progress.gd")
const Traveler = preload("res://scripts/traveler.gd")
const Valley = preload("res://scripts/valley.gd")
const Adventure = preload("res://scripts/adventure.gd")
const SAVE := "res://.local/saves/journey.json"
var progress = Progress.new()
var traveler: CharacterBody3D
var valley: Node3D
var adventure: Node3D
var ui: Control
var menu: PanelContainer
var pause_panel: PanelContainer
var name_input: LineEdit
var robe_input: OptionButton
var identity: Label
var quest: Label
var meters: Label
var prompt: Label
var message: Label
var journal: Label
var quest_panel: PanelContainer
var controls: Label
var skills: Label
var shield_mesh: MeshInstance3D
var enemy_label: Label3D
var playing := false
var paused := false
var beast_hp := 112.0
var attack_cooldown := 0.0
var enemy_cooldown := 1.8
var windup := -1.0
var message_time := 0.0
var autosave_time := 0.0
var test_mode := false
var journey_generation := 0
var shield_strength := 0.0
var shield_time := 0.0
var shield_cooldown := 0.0
var fire_cooldown := 0.0
var combo_stage := -1
var combo_window := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	test_mode = "--test" in OS.get_cmdline_user_args()
	setup_input()
	valley = Valley.new()
	valley.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(valley)
	traveler = Traveler.new()
	traveler.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(traveler)
	traveler.position = Vector3(0, 0.1, 18)
	enemy_label = valley.sign_text("石角兽  112 / 112", valley.beast_origin + Vector3.UP * 2.4, 24)
	setup_ui()
	adventure = Adventure.new()
	adventure.game = self
	add_child(adventure)
	var sphere := SphereMesh.new()
	sphere.radius = 0.85
	sphere.height = 2.1
	shield_mesh = MeshInstance3D.new()
	shield_mesh.mesh = sphere
	var shield_material := StandardMaterial3D.new()
	shield_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shield_material.albedo_color = Color(0.45, 0.8, 0.75, 0.18)
	shield_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shield_mesh.material_override = shield_material
	add_child(shield_mesh)
	shield_mesh.hide()
	get_tree().auto_accept_quit = false
	show_menu()

func setup_input() -> void:
	var keys := {"forward": [KEY_W, KEY_UP], "back": [KEY_S, KEY_DOWN],
		"left": [KEY_A, KEY_LEFT], "right": [KEY_D, KEY_RIGHT], "run": [KEY_SHIFT],
		"dodge": [KEY_SPACE], "interact": [KEY_E], "cast": [KEY_Q, KEY_1], "save": [KEY_F5], "journal": [KEY_TAB],
		"fire": [KEY_R, KEY_2], "shield": [KEY_F, KEY_3], "cultivate": [KEY_G], "home": [KEY_H]}
	for action in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key in keys[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("cast", click)

func label(text: String, size: int, color := Color("e6e7d7")) -> Label:
	var result := Label.new()
	result.text = text
	result.add_theme_font_size_override("font_size", size)
	result.add_theme_color_override("font_color", color)
	return result

func panel(at: Vector2, size: Vector2) -> PanelContainer:
	var result := PanelContainer.new()
	result.position = at
	result.custom_minimum_size = size
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.075, 0.07, 0.93)
	style.border_color = Color("8b9272")
	style.set_border_width_all(1)
	style.content_margin_left = 28
	style.content_margin_right = 28
	style.content_margin_top = 24
	style.content_margin_bottom = 24
	result.add_theme_stylebox_override("panel", style)
	ui.add_child(result)
	return result

func button(text: String, callback: Callable, parent: Node) -> Button:
	var result := Button.new()
	result.text = text
	result.custom_minimum_size.y = 44
	result.pressed.connect(callback)
	parent.add_child(result)
	return result

func setup_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	ui = Control.new()
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme := Theme.new()
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Microsoft YaHei", "Noto Sans CJK SC", "sans-serif"])
	theme.default_font = font
	theme.default_font_size = 18
	theme.set_color("font_shadow_color", "Label", Color(0, 0, 0, 0.85))
	theme.set_constant("shadow_offset_x", "Label", 1)
	theme.set_constant("shadow_offset_y", "Label", 2)
	ui.theme = theme
	canvas.add_child(ui)
	identity = label("", 27)
	identity.position = Vector2(34, 28)
	ui.add_child(identity)
	meters = label("", 17, Color("c6d5bb"))
	meters.position = Vector2(35, 68)
	ui.add_child(meters)
	quest_panel = panel(Vector2(34, 118), Vector2(310, 150))
	quest_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	quest = label("", 17)
	quest.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quest.custom_minimum_size.x = 255
	quest_panel.add_child(quest)
	quest_panel.name = "QuestPanel"
	var region := label("青 岚 谷\n雨霁 · 卯时", 21, Color("e1dfc7"))
	region.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	region.position = Vector2(1030, 30)
	region.size.x = 210
	ui.add_child(region)
	message = label("", 21, Color("f0d49b"))
	message.position = Vector2(310, 550)
	message.size = Vector2(660, 60)
	message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ui.add_child(message)
	prompt = label("", 22)
	prompt.position = Vector2(360, 614)
	prompt.size.x = 560
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(prompt)
	skills = label("", 18, Color("d3d7b2"))
	skills.position = Vector2(34, 643)
	ui.add_child(skills)
	controls = label("WASD 移动  鼠标转向  Shift 奔跑  空格 闪避  E 交互  H 回府  G 修炼  Tab 行囊  F5 保存  Esc 暂停", 16)
	controls.position = Vector2(34, 679)
	ui.add_child(controls)
	menu = panel(Vector2(55, 118), Vector2(440, 470))
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	menu.add_child(column)
	column.add_child(label("青 岚 问 道", 42, Color("dfc997")))
	column.add_child(label("v0.2 · 遗府与归居", 18))
	column.add_child(label("一介凡人，从此山开始。", 19))
	name_input = LineEdit.new()
	name_input.placeholder_text = "取一个道名"
	name_input.text = "无名"
	name_input.max_length = 16
	name_input.custom_minimum_size.y = 42
	column.add_child(name_input)
	robe_input = OptionButton.new()
	for color_name in Progress.ROBES:
		robe_input.add_item("行装 · " + color_name)
	robe_input.item_selected.connect(func(index: int): traveler.set_robe(index))
	column.add_child(robe_input)
	button("创建角色 · 入山", request_new, column)
	button("继续上次旅程", continue_game, column)
	column.add_child(label("占位模型 · 非最终写实画质", 15, Color("a6b4a8")))
	pause_panel = panel(Vector2(400, 80), Vector2(480, 500))
	var pause_column := VBoxContainer.new()
	pause_column.add_theme_constant_override("separation", 14)
	pause_panel.add_child(pause_column)
	pause_column.add_child(label("暂 歇", 32, Color("dfc997")))
	journal = label("", 17)
	pause_column.add_child(journal)
	button("继续修行", func(): set_paused(false), pause_column)
	button("保存旅程", func(): save_game(), pause_column)
	button("保存并返回标题", return_to_title, pause_column)
	pause_panel.hide()

func request_new() -> void:
	if name_input.text.strip_edges().is_empty():
		notify("先给自己取一个道名。")
		return
	if FileAccess.file_exists(SAVE):
		var dialog := ConfirmationDialog.new()
		dialog.dialog_text = "创建新角色将覆盖上次旅程，是否继续？"
		dialog.title = "重新入山"
		dialog.confirmed.connect(begin_new)
		dialog.confirmed.connect(dialog.queue_free)
		dialog.canceled.connect(dialog.queue_free)
		ui.add_child(dialog)
		dialog.popup_centered()
	else:
		begin_new()

func begin_new() -> void:
	progress = Progress.new()
	progress.character_name = name_input.text.strip_edges()
	progress.robe = robe_input.selected
	start_game(Vector3(0, 0.1, 18))
	save_game(false)
	notify("沿石径向北寻找洞府。靠近目标按 E。")

func start_game(at: Vector3) -> void:
	journey_generation += 1
	get_tree().paused = false
	playing = true
	paused = false
	menu.hide()
	quest_panel.show()
	controls.show()
	skills.show()
	pause_panel.hide()
	traveler.position = at
	traveler.velocity = Vector3.ZERO
	traveler.yaw = 0
	traveler.set_robe(progress.robe)
	traveler.enabled = true
	valley.beast.position = valley.beast_origin
	beast_hp = 112.0
	attack_cooldown = 0
	enemy_cooldown = 1.8
	windup = -1
	shield_strength = 0
	shield_time = 0
	shield_cooldown = 0
	fire_cooldown = 0
	combo_stage = -1
	combo_window = 0
	traveler.invincible = 0
	traveler.dodge_cooldown = 0
	shield_mesh.hide()
	adventure.storage_panel.hide()
	adventure.reset_encounters()
	autosave_time = 0
	sync_world()
	if not test_mode:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	update_hud()

func show_menu() -> void:
	journey_generation += 1
	get_tree().paused = false
	playing = false
	paused = false
	traveler.enabled = false
	menu.show()
	quest_panel.hide()
	controls.hide()
	skills.hide()
	shield_mesh.hide()
	adventure.storage_panel.hide()
	pause_panel.hide()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	identity.text = "山中一日，世上千年。"
	meters.text = ""
	quest.text = "自由角色 · 单人 3D\n\n探索洞府 / 采集灵草\n御剑战斗 / 炼气入门"
	prompt.text = ""

func set_paused(value: bool) -> void:
	paused = value
	get_tree().paused = value
	traveler.enabled = playing and not paused
	pause_panel.visible = value
	adventure.storage_panel.hide()
	journal.text = "道名：%s  ·  %s\n灵草 %d  妖丹 %d  灵种 %d\n洞府：%s  ·  修炼 %d / 3\n阵柱 %d / 3  ·  传承 %s\n\n路线：北面残卷 → 石角兽 → 静心台\n东侧遗府：山、水、月三柱 → 石卫\n村庄西侧：认领洞府，播种与储物\n蒲团 E 调息 / G 修炼；脱战后 H 回府" % [progress.character_name,
		"炼气一层" if progress.realm else "凡人", progress.herbs(), int(progress.core), progress.seeds,
		"已认领" if progress.home_claimed else "未认领", progress.cultivation, progress.runes, "已取得" if progress.relic else "未取得"]
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED
	if test_mode:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _unhandled_input(event: InputEvent) -> void:
	if not playing:
		return
	if event.is_action_pressed("ui_cancel") or event.is_action_pressed("journal"):
		set_paused(not paused)
		get_viewport().set_input_as_handled()
		return
	if paused:
		return
	if event.is_action_pressed("interact"):
		interact()
	elif event.is_action_pressed("cast"):
		cast_sword()
	elif event.is_action_pressed("fire"):
		cast_attack("fire")
	elif event.is_action_pressed("shield"):
		cast_shield()
	elif event.is_action_pressed("cultivate"):
		adventure.cultivate_near_bed()
	elif event.is_action_pressed("home"):
		adventure.return_home()
	elif event.is_action_pressed("save"):
		save_game()

func nearest() -> Dictionary:
	var result := {}
	var distance := 2.7
	for point in valley.interactions:
		if point.kind == "herb" and point.id in progress.collected:
			continue
		var d: float = traveler.position.distance_to(point.position)
		if d < distance:
			distance = d
			result = point
	return result

func interact() -> void:
	var point := nearest()
	if point.is_empty():
		notify("靠近灵草、洞府残卷或静心台，再按 E。")
		return
	match point.kind:
		"herb":
			if progress.gather(point.id):
				notify("采得灵草。突破需要三株灵草与一枚妖丹。")
		"scroll":
			progress.learned = true
			notify("领悟御剑诀。Q 或左键御剑，灵力会缓慢恢复。")
		"altar":
			if progress.breakthrough():
				notify("引气入体 · 炼气一层！生命与灵力上限提升至 140。")
			else:
				progress.hp = progress.max_hp()
				progress.qi = progress.max_qi()
				notify("静心调息，状态已恢复。" if progress.realm else "调息恢复。突破还需：功法、三株灵草、一枚妖丹。")
		_:
			adventure.interact(point)
	sync_world()
	save_game(false)
	update_hud()

func sync_world() -> void:
	for point in valley.interactions:
		if point.kind == "herb":
			point.node.visible = point.id not in progress.collected
	valley.beast.visible = not progress.beast_dead
	enemy_label.visible = not progress.beast_dead
	adventure.sync()

func cast_sword() -> bool:
	return cast_attack("sword")

func combat_target() -> Dictionary:
	var best := {}
	var distance := 13.0
	if not progress.beast_dead:
		var d: float = traveler.position.distance_to(valley.beast.position)
		if d <= distance:
			distance = d
			best = {"id": "beast", "node": valley.beast}
	for enemy in adventure.enemies:
		if adventure.is_dead(enemy) or (enemy.id == "guardian" and progress.runes != 3):
			continue
		var d: float = traveler.position.distance_to(enemy.node.position)
		if d < distance:
			distance = d
			best = {"id": enemy.id, "node": enemy.node}
	return best

func cast_attack(kind: String) -> bool:
	if attack_cooldown > 0:
		return false
	if not progress.learned:
		notify("尚未习得功法。沿石径向北寻找洞府残卷。")
		return false
	if kind == "fire" and (not progress.relic or fire_cooldown > 0):
		notify("火弹术需要取得遗府传承，并等待三秒冷却。")
		return false
	var victim := combat_target()
	if victim.is_empty():
		notify("附近没有可锁定的妖兽。御剑范围为 13 米。")
		return false
	var target: Vector3 = victim.node.position + Vector3.UP
	var ray := PhysicsRayQueryParameters3D.create(traveler.position + Vector3.UP, target)
	ray.exclude = [traveler.get_rid()]
	if not get_world_3d().direct_space_state.intersect_ray(ray).is_empty():
		notify("法器被地形遮挡，请移动到开阔处。")
		return false
	if not progress.spend_qi(24 if kind == "fire" else 14):
		notify("灵力不足，稍候恢复或回静心台调息。")
		return false
	attack_cooldown = 0.55
	var damage: float = 60 if kind == "fire" else (40 if progress.realm else 28)
	if kind == "sword":
		combo_stage = (combo_stage + 1) % 3 if combo_window > 0 else 0
		combo_window = 1.4
		damage *= [1.0, 1.15, 1.4][combo_stage]
		if progress.relic:
			damage *= 1.15
		if combo_stage == 2:
			notify("飞剑三连 · 破阵！")
	else:
		fire_cooldown = 3
	damage += progress.cultivation * 2
	var sword: MeshInstance3D = valley.box(traveler.position + Vector3.UP * 1.2,
		Vector3(0.4, 0.4, 0.4) if kind == "fire" else Vector3(0.09, 0.09, 1.2),
		valley.material("e4a05c" if kind == "fire" else "c4e9d2", true))
	if (target - sword.position).cross(Vector3.UP).length_squared() > 0.001:
		sword.look_at(target)
	var tween := create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_STOP)
	var cast_generation := journey_generation
	tween.tween_property(sword, "position", target, 0.17)
	tween.tween_callback(func():
		sword.queue_free()
		if not playing or journey_generation != cast_generation:
			return
		if victim.id != "beast":
			adventure.hit(victim.id, damage)
			return
		if not progress.beast_dead:
			beast_hp = maxf(0, beast_hp - damage)
			if beast_hp == 0:
				progress.beast_dead = true
				progress.core = true
				sync_world()
				save_game(false)
				notify("石角兽已败，获得妖丹。回静心台尝试突破。")
	)
	return true

func cast_shield() -> bool:
	if shield_cooldown > 0 or not progress.spend_qi(20):
		notify("护体术需要已学功法、20 点灵力，并等待十秒冷却。")
		return false
	shield_strength = 45
	shield_time = 5
	shield_cooldown = 10
	shield_mesh.show()
	notify("护体术：五秒内吸收最多 45 点伤害。")
	return true

func take_damage(amount: float) -> void:
	if traveler.invincible > 0:
		return
	var absorbed: float = minf(shield_strength, amount)
	shield_strength -= absorbed
	amount -= absorbed
	progress.hp = maxf(0, progress.hp - amount)
	notify("护体抵挡攻击！" if amount == 0 else "受到攻击，注意地面预警与空格闪避。")
	if progress.hp <= 0:
		progress.hp = progress.max_hp()
		progress.qi = progress.max_qi()
		traveler.position = valley.altar + Vector3(0, 0.2, 2)
		traveler.velocity = Vector3.ZERO
		valley.beast.position = valley.beast_origin
		beast_hp = 112
		windup = -1
		shield_strength = 0
		adventure.reset_encounters()
		save_game(false)
		notify("力竭后在静心台苏醒，物品保留，存活的敌人恢复。")

func _process(delta: float) -> void:
	message_time -= delta
	message.visible = message_time > 0
	if not playing or paused:
		return
	attack_cooldown = maxf(0, attack_cooldown - delta)
	combo_window = maxf(0, combo_window - delta)
	fire_cooldown = maxf(0, fire_cooldown - delta)
	shield_cooldown = maxf(0, shield_cooldown - delta)
	shield_time = maxf(0, shield_time - delta)
	if shield_time == 0:
		shield_strength = 0
	shield_mesh.visible = shield_strength > 0
	shield_mesh.position = traveler.position + Vector3.UP
	progress.world_time += delta
	progress.qi = minf(progress.max_qi(), progress.qi + delta * 6)
	autosave_time += delta
	if autosave_time > 20:
		save_game(false)
		autosave_time = 0
	if not progress.beast_dead:
		update_beast(delta)
	update_hud()

func update_beast(delta: float) -> void:
	var offset: Vector3 = traveler.position - valley.beast.position
	offset.y = 0
	var distance := offset.length()
	enemy_cooldown -= delta
	if windup >= 0:
		windup -= delta
		valley.beast.scale = Vector3.ONE * (1.0 + 0.06 * sin(windup * 25))
		if windup < 0:
			valley.beast.scale = Vector3.ONE
			if distance < 2.8 and traveler.invincible <= 0:
				take_damage(18)
	elif distance < 2.2 and enemy_cooldown <= 0:
		windup = 0.65
		enemy_cooldown = 2.0
	elif distance < 10 and distance > 1.8:
		valley.beast.position += offset.normalized() * delta * 2.2
	elif distance > 14:
		valley.beast.position = valley.beast.position.move_toward(valley.beast_origin, delta * 2)
	if distance > 0.05:
		valley.beast.rotation.y = atan2(-offset.x, -offset.z)
	enemy_label.position = valley.beast.position + Vector3.UP * 2.4
	enemy_label.text = "蓄力冲撞 · 空格闪避" if windup >= 0 else "石角兽  %d / 112" % int(beast_hp)

func update_hud() -> void:
	identity.text = "%s  /  %s" % [progress.character_name, "炼气一层" if progress.realm else "凡人"]
	meters.text = "生命 %d / %d    灵力 %d / %d" % [int(progress.hp), int(progress.max_hp()), int(progress.qi), int(progress.max_qi())]
	if progress.realm and not progress.relic:
		quest.text = "叁 / 遗府传承\n\n往东侧遗府依次激活山、水、月阵柱（%d/3）。\n击败石卫，取得火弹术传承。" % progress.runes
	elif progress.relic:
		quest.text = "肆 / 归居修行\n\n村西认领洞府，播种灵草、储物。\n蒲团 E 调息，G 修炼（%d/3）。" % progress.cultivation
	elif not progress.learned:
		quest.text = "壹 / 寻仙\n\n沿石径向北寻找洞府。\n靠近残卷，按 E 领悟功法。"
	else:
		quest.text = "贰 / 引气入体\n\n灵草 %d / 3    妖丹 %d / 1\n石角兽在洞府东南侧。\n备齐材料后，回静心台按 E。" % [progress.herbs(), int(progress.core)]
	var point := nearest()
	skills.text = "1 / Q 御剑三连   2 / R 火弹[%s]   3 / F 护体[%s]   灵种 %d   修炼 %d/3" % [
		"未传承" if not progress.relic else ("就绪" if fire_cooldown == 0 else "%.1fs" % fire_cooldown),
		"未领悟" if not progress.learned else ("就绪" if shield_cooldown == 0 else "%.1fs" % shield_cooldown), progress.seeds, progress.cultivation]
	prompt.text = ""
	if not point.is_empty():
		var names := {"herb": "采集灵草", "scroll": "参悟残卷", "altar": "调息 / 尝试突破"}
		prompt.text = "[ E ]  " + names.get(point.kind, point.get("label", "交互"))

func notify(text: String) -> void:
	message.text = text
	message_time = 5.0
	message.show()

func save_game(feedback := true) -> bool:
	if not playing:
		return false
	var dir_error := DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://.local/saves"))
	if dir_error != OK:
		notify("无法创建存档目录，请检查项目所在磁盘是否可写。")
		return false
	var file := FileAccess.open(SAVE + ".tmp", FileAccess.WRITE)
	if file == null:
		notify("保存失败：无法写入磁盘。")
		return false
	# Save on the walkable floor, not in the middle of a fall or dodge.
	var at := Vector3(traveler.position.x, 0.1, traveler.position.z)
	file.store_string(JSON.stringify(progress.snapshot(at)))
	file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error != OK or DirAccess.rename_absolute(ProjectSettings.globalize_path(SAVE + ".tmp"), ProjectSettings.globalize_path(SAVE)) != OK:
		notify("保存失败，已有存档未主动删除。")
		return false
	if feedback:
		notify("旅程已保存到项目的 .local/saves 目录。")
	return true

func continue_game() -> bool:
	if not FileAccess.file_exists(SAVE):
		notify("还没有存档，请先创建角色。")
		return false
	var file := FileAccess.open(SAVE, FileAccess.READ)
	if file == null:
		notify("无法读取存档，请检查文件权限。")
		return false
	var parser := JSON.new()
	if parser.parse(file.get_as_text()) != OK:
		notify("存档格式损坏，未覆盖原文件。")
		return false
	var data: Variant = parser.data
	var loaded = Progress.new()
	if not loaded.restore(data):
		notify("存档损坏或版本不兼容，未覆盖原文件。")
		return false
	if data.version == 1 and not FileAccess.file_exists(SAVE + ".v1.bak"):
		file.close()
		if DirAccess.copy_absolute(ProjectSettings.globalize_path(SAVE), ProjectSettings.globalize_path(SAVE + ".v1.bak")) != OK:
			notify("无法备份旧存档，已停止迁移，请检查磁盘权限。")
			return false
	progress = loaded
	start_game(Vector3(float(data.position[0]), float(data.position[1]), float(data.position[2])))
	notify("重返青岚谷。未击败的妖兽会恢复状态。")
	return true

func return_to_title() -> void:
	if save_game(false):
		show_menu()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		if playing and not save_game(false):
			set_paused(true)
			notify("保存未成功，请检查磁盘后重试。")
			return
		get_tree().quit()
