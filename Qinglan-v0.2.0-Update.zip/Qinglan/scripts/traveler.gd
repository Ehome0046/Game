extends CharacterBody3D

var enabled := false
var invincible := 0.0
var dodge_cooldown := 0.0
var dodge_direction := Vector3.FORWARD
var yaw := 0.0
var pitch := -0.28
var motion_time := 0.0
var model: Node3D
var camera_pivot: Node3D
var camera: Camera3D
var left_leg: MeshInstance3D
var right_leg: MeshInstance3D

func _ready() -> void:
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.8
	var collision := CollisionShape3D.new()
	collision.shape = capsule
	collision.position.y = 0.9
	add_child(collision)
	model = Node3D.new()
	add_child(model)
	var cloth := StandardMaterial3D.new()
	cloth.albedo_color = Color("536a68")
	cloth.roughness = 0.95
	var robe_mesh := CylinderMesh.new()
	robe_mesh.top_radius = 0.23
	robe_mesh.bottom_radius = 0.41
	robe_mesh.height = 1.0
	part(robe_mesh, Vector3(0, 0.91, 0), cloth)
	var skin := StandardMaterial3D.new()
	skin.albedo_color = Color("c5a68a")
	var head := SphereMesh.new()
	head.radius = 0.19
	head.height = 0.38
	part(head, Vector3(0, 1.59, 0), skin)
	var hair := SphereMesh.new()
	hair.radius = 0.195
	hair.height = 0.29
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color("202b29")
	part(hair, Vector3(0, 1.72, 0.035), dark)
	var bun := SphereMesh.new()
	bun.radius = 0.10
	bun.height = 0.17
	part(bun, Vector3(0, 1.88, 0.04), dark)
	var leg := BoxMesh.new()
	leg.size = Vector3(0.17, 0.40, 0.23)
	left_leg = part(leg, Vector3(-0.15, 0.24, 0), dark)
	right_leg = part(leg, Vector3(0.15, 0.24, 0), dark)
	for side in [-1.0, 1.0]:
		var sleeve := CapsuleMesh.new()
		sleeve.radius = 0.13
		sleeve.height = 0.65
		var arm := part(sleeve, Vector3(side * 0.32, 1.16, 0), cloth)
		arm.rotation.z = side * 0.25
	camera_pivot = Node3D.new()
	camera_pivot.position.y = 1.4
	add_child(camera_pivot)
	var spring := SpringArm3D.new()
	spring.spring_length = 5.7
	spring.margin = 0.25
	spring.add_excluded_object(get_rid())
	camera_pivot.add_child(spring)
	camera = Camera3D.new()
	camera.fov = 62
	camera.near = 0.1
	spring.add_child(camera)
	camera.current = true

func part(mesh: Mesh, at: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	model.add_child(instance)
	return instance

func set_robe(index: int) -> void:
	var color: Color = [Color("536a68"), Color("344c3e"), Color("78534b")][index]
	for child in model.get_children():
		if child.mesh is CylinderMesh or child.mesh is CapsuleMesh:
			child.material_override.albedo_color = color

func _unhandled_input(event: InputEvent) -> void:
	if enabled and event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		yaw -= event.relative.x * 0.003
		pitch = clampf(pitch - event.relative.y * 0.003, -0.8, 0.28)

func _physics_process(delta: float) -> void:
	invincible = maxf(0, invincible - delta)
	dodge_cooldown = maxf(0, dodge_cooldown - delta)
	camera_pivot.rotation = Vector3(pitch, yaw, 0)
	var direction := Vector3.ZERO
	if enabled:
		var axis := Input.get_vector("left", "right", "forward", "back")
		direction = Vector3(axis.x, 0, axis.y).rotated(Vector3.UP, yaw)
		if Input.is_action_just_pressed("dodge") and dodge_cooldown == 0:
			dodge_direction = direction if direction.length() > 0.1 else -camera.global_basis.z * Vector3(1, 0, 1)
			dodge_direction = dodge_direction.normalized()
			invincible = 0.35
			dodge_cooldown = 1.1
	var speed := 6.8 if enabled and Input.is_action_pressed("run") else 4.0
	if enabled and invincible > 0:
		direction = dodge_direction
		speed = 11.0
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	velocity.y = maxf(velocity.y - 20 * delta, -25)
	move_and_slide()
	position.x = clampf(position.x, -35.0, 35.0)
	position.z = clampf(position.z, -35.0, 35.0)
	if direction.length_squared() > 0.01:
		model.rotation.y = lerp_angle(model.rotation.y, atan2(-direction.x, -direction.z), delta * 12)
		motion_time += delta * speed * 2.1
		left_leg.rotation.x = sin(motion_time) * 0.5
		right_leg.rotation.x = -sin(motion_time) * 0.5
	else:
		left_leg.rotation.x = 0
		right_leg.rotation.x = 0
