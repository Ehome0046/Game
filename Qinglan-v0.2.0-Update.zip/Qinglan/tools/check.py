#!/usr/bin/env python3
"""Exercise the real scene in a temporary copy; never touch a player's save."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--godot", default="godot")
parser.add_argument("--capture-dir", type=Path, help="Use a real DISPLAY and capture PNGs")
args = parser.parse_args()
source = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="qinglan-check-") as temporary:
    project = Path(temporary) / "Game"
    shutil.copytree(source, project, ignore=shutil.ignore_patterns(
        ".git", ".godot", ".local", "dist", "__pycache__", "godot"))
    command = [args.godot, "--path", str(project), "--fixed-fps", "60",
               "--audio-driver", "Dummy", "--log-file", str(Path(temporary) / "run.log"),
               "--script", "res://tests/smoke.gd"]
    if not args.capture_dir:
        command.insert(1, "--headless")
    command.extend(["--", "--test"])
    if args.capture_dir:
        args.capture_dir.mkdir(parents=True, exist_ok=True)
        command.append("--capture-dir=" + str(args.capture_dir.resolve()))
    try:
        result = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=120, env=os.environ.copy())
    except subprocess.TimeoutExpired as error:
        print(error.stdout.decode() if isinstance(error.stdout, bytes) else error.stdout or "")
        sys.exit("Godot check timed out")
    print(result.stdout)
    # Some Godot script-load errors still return zero: require the suite summary too.
    failed = result.returncode != 0 or "RESULT:" not in result.stdout or any(
        marker in result.stdout for marker in ["SCRIPT ERROR:", "ERROR:", "FAIL:"])
    sys.exit(1 if failed else 0)
