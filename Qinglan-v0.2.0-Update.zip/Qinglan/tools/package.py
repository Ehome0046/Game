#!/usr/bin/env python3
"""Build a portable project ZIP without saves, caches, Git metadata or test data."""
from pathlib import Path
import argparse
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("--with-engine", action="store_true")
parser.add_argument("--update-only", action="store_true", help="Overlay files for an existing portable installation")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
destination = root / "dist"
destination.mkdir(exist_ok=True)
if args.with_engine and args.update_only:
    parser.error("--with-engine and --update-only are mutually exclusive")
suffix = "Windows-Portable" if args.with_engine else ("Update" if args.update_only else "Source")
output = destination / f"Qinglan-v0.2.0-{suffix}.zip"
files = [root / name for name in ["README.md", ".gitignore", "Start-Game.cmd", "project.godot"]]
for folder in ["docs", "scenes", "scripts", "shaders", "tests", "third_party"]:
    files.extend(p for p in (root / folder).rglob("*") if p.is_file())
files.extend([root / "tools/check.py", root / "tools/package.py"])
if args.with_engine:
    engine = root / "tools/godot/Godot.exe"
    if not engine.is_file():
        raise SystemExit("Missing tools/godot/Godot.exe; see Windows quickstart")
    for license_name in ["LICENSE.txt", "COPYRIGHT.txt", "ORIGIN.md"]:
        if not (root / "third_party/godot" / license_name).is_file():
            raise SystemExit("Missing Godot license/provenance: " + license_name)
    files.extend([engine, root / "tools/godot/_sc_"])
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        content = path.read_bytes()
        if path.suffix == ".cmd":
            content = content.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        archive.writestr("Qinglan/" + path.relative_to(root).as_posix(), content)
    engine_note = ("便携包已附带 Godot 引擎，无需安装。" if args.with_engine else
                   ("这是小更新包，请覆盖原有 Qinglan 文件夹，保留 tools\\godot 和 .local。" if args.update_only else
                    "此为源码包，先按 docs\\windows-quickstart.md 准备便携 Godot 引擎。"))
    archive.writestr("Qinglan/开始前必读.txt", f"""青岚问道 v0.2.0 · 遗府与归居（玩法原型）

1. 将整个 Qinglan 文件夹解压到 D:\\GameDev 下，不要放到 C 盘。
2. {engine_note} 双击 Start-Game.cmd 启动。
3. 继续旧存档即可。炼气后去东侧遗府，按山、水、月激活阵柱，击败石卫，取得传承。
4. 村庄西侧可认领自己的洞府，使用储物箱、三块灵田和修炼蒲团。
5. Q/1/左键御剑连击，R/2火弹，F/3护体；H脱战回府，G在蒲团修炼。
6. WASD 移动，鼠标转向，E 交互，空格闪避，Esc/Tab 暂停，F5 保存。
7. 这是采用简单占位模型的玩法原型，不是最终写实画面。Windows 本机尚待实测。

存档：.local\\saves。请不要误删；创建新角色前会询问是否覆盖。
旧存档会自动迁移并备份为 journey.json.v1.bak。
本次更新说明：docs\\update-0.2.md；首次启动说明：docs\\windows-quickstart.md。
""".encode("utf-8-sig"))
    if not archive.testzip() is None:
        raise SystemExit("ZIP CRC check failed")
with zipfile.ZipFile(output) as archive:
    names = archive.namelist()
    if any("/.local/" in n or "/.git/" in n or "/.godot/" in n for n in names):
        raise SystemExit("Unexpected private data or cache in artifact")
    print(f"{output}: {output.stat().st_size / 1024**2:.1f} MiB, {len(names)} files")
