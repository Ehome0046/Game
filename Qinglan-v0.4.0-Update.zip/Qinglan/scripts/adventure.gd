extends Node3D
## Ruins, home and encounter content. Persistent rules live in progress.gd.

var game: Node3D
var enemies: Array[Dictionary] = []
var rune_nodes: Array[MeshInstance3D] = []
var crop_nodes: Array[Node3D] = []
var crop_labels: Array[Label3D] = []
var gate: MeshInstance3D
var gate_shape: CollisionShape3D
var relic_node: MeshInstance3D
var owner_label: Label3D
var home_banner: MeshInstance3D
var home_lamps: Array[OmniLight3D] = []
var storage_panel: PanelContainer
var storage_label: Label
var visual_timer := 0.0
const HOME := Vector3(-25, 0.1, 23)
const RUNE_NAMES := ["山", "水", "月"]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	build_home()
	build_ruins()
	build_enemy("spitter", Vector3(24, 0, -6), 90, "青瘴灵蛛", "73835b")
	build_enemy("guardian", Vector3(24, 0, -28), 280, "镇府石卫", "646f77")

func point(kind: String, at: Vector3, text: String, id := -1) -> void:
	game.valley.interactions.append({"kind": kind, "id": id, "position": at, "label": text})

func build_home() -> void:
	var v = game.valley
	# Land the bridge south of the home wall so the approach stays walkable.
	v.box(Vector3(-19, 0.08, 23.5), Vector3(5.5, 0.12, 2.5), v.wood)
	v.box(Vector3(-25, 0.02, 17), Vector3(9, 0.04, 9), v.stone)
	for x in [-29.4, -20.6]:
		v.box(Vector3(x, 2, 17), Vector3(0.8, 4, 8), v.stone, true)
	v.box(Vector3(-25, 2, 13), Vector3(9.6, 4, 0.8), v.stone, true)
	v.box(Vector3(-25, 4, 16), Vector3(9.6, 0.6, 6), v.stone, true)
	for x in [-28, -22]:
		v.box(Vector3(x, 1.7, 21), Vector3(0.5, 3.4, 0.5), v.wood, true)
	v.box(Vector3(-25, 3.3, 21), Vector3(7, 0.35, 0.7), v.wood)
	home_banner = v.box(Vector3(-25, 2.3, 13.5), Vector3(1.4, 1.8, 0.05), v.material("536f64"))
	for x in [-28, -22]:
		v.cylinder(Vector3(x, 2.4, 19), 0.15, 0.15, 0.45, v.material("c6aa77", true))
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(x, 2.4, 18.5)
		lamp.omni_range = 6
		lamp.light_energy = 0.65
		v.add_child(lamp)
		home_lamps.append(lamp)
	owner_label = v.sign_text("无主石室 · E 认领", Vector3(-25, 3, 22), 29)
	point("claim_home", Vector3(-25, 0, 22), "认领 / 进入独立洞府")
	v.box(Vector3(-25, 1.5, 20.7), Vector3(4.7, 3, 0.25), v.material("4e4636"), true)
	for x in [-27.4, -22.6]:
		v.box(Vector3(x, 1.6, 21), Vector3(0.18, 3.2, 0.45), v.material("ac9466"))
	for i in range(3):
		var at := Vector3(-29 + i * 4, 0, 9)
		v.box(at + Vector3.UP * 0.06, Vector3(2.4, 0.12, 2.4), v.material("403b2c"))
		for x in [-1.2, 1.2]:
			v.box(at + Vector3(x, 0.12, 0), Vector3(0.15, 0.2, 2.6), v.wood)
		var crop := Node3D.new()
		v.add_child(crop)
		crop.position = at
		v.cylinder(Vector3.UP * 0.55, 0.03, 0.07, 1.1, v.leaf, crop)
		for j in range(4):
			var sprig: MeshInstance3D = v.box(Vector3.UP * (0.3 + 0.19 * j), Vector3(0.9, 0.06, 0.25), v.material("7d9d70"), false, crop)
			sprig.rotation.y = j * 1.0
		crop_nodes.append(crop)
		crop_labels.append(v.sign_text("", at + Vector3.UP * 1.8, 22))
		point("plot", at, "播种 / 收获灵草", i)
	v.sign_text("灵田 · 游玩 90 秒成熟", Vector3(-25, 2.8, 7), 27)
	v.sign_text("← 隐居洞府", Vector3(-10, 2, 21), 28)

func build_ruins() -> void:
	var v = game.valley
	v.box(Vector3(24.5, 0.04, -27), Vector3(16, 0.08, 18), v.stone)
	for x in [16.8, 32.3]:
		v.box(Vector3(x, 1.8, -27), Vector3(0.8, 3.6, 18), v.stone, true)
	v.box(Vector3(24.5, 1.8, -35.5), Vector3(16, 3.6, 0.8), v.stone, true)
	for x in [19.3, 29.3]:
		v.box(Vector3(x, 1.8, -18.5), Vector3(5.7, 3.6, 0.8), v.stone, true)
	gate = v.box(Vector3(24.3, 1.7, -18.5), Vector3(4.4, 3.4, 0.6), v.material("52776f", true), true)
	gate_shape = gate.get_child(0).get_child(0)
	point("gate", Vector3(24, 0, -16.5), "查看阵法线索")
	v.sign_text("古修遗府 · 封印石门", Vector3(24, 4.3, -18.5), 30)
	var positions := [Vector3(18, 0, -11), Vector3(26, 0, -3), Vector3(30, 0, -14)]
	for i in range(3):
		v.cylinder(positions[i] + Vector3.UP * 0.5, 0.55, 0.7, 1, v.stone)
		rune_nodes.append(v.cylinder(positions[i] + Vector3.UP * 1.07, 0.24, 0.24, 0.12, v.material("6b8074")))
		v.sign_text(RUNE_NAMES[i] + "之阵柱", positions[i] + Vector3.UP * 2, 25)
		point("rune", positions[i], "注入灵力 · " + RUNE_NAMES[i], i)
	relic_node = v.box(Vector3(24, 1, -33), Vector3(0.8, 0.3, 0.65), v.material("dcaa67", true))
	point("relic", Vector3(24, 0, -32), "取得遗府传承")
	v.sign_text("传承玉简", Vector3(24, 2.6, -33), 25)
	v.sign_text("遗府碑记：山生水，水映月。\n依次唤醒三柱，石门自开。", Vector3(24, 2.6, -15), 24)
	# Short paths and lanterns make the two additions discoverable from the valley.
	for i in range(8):
		v.box(Vector3(4 + i * 2.5, 0.035, -15), Vector3(1.7, 0.05, 1.1), v.stone)
	v.sign_text("古修遗府 →", Vector3(5, 2.1, -16), 26)

func build_enemy(id: String, at: Vector3, health: float, title: String, color: String) -> void:
	var v = game.valley
	var body := Node3D.new()
	v.add_child(body)
	body.position = at
	var mat: StandardMaterial3D = v.material(color)
	if id == "guardian":
		v.box(Vector3(0, 1.25, 0), Vector3(1.4, 1.7, 0.9), mat, false, body)
		v.box(Vector3(0, 2.3, 0), Vector3(0.85, 0.7, 0.8), mat, false, body)
		for side in [-1.0, 1.0]:
			v.box(Vector3(side * 0.9, 1.25, 0), Vector3(0.4, 1.5, 0.5), mat, false, body)
			v.box(Vector3(side * 0.42, 0.35, 0), Vector3(0.45, 0.7, 0.55), mat, false, body)
		v.box(Vector3(0, 1.55, -0.47), Vector3(0.35, 0.5, 0.05), v.material("9fc3be", true), false, body)
	else:
		var sphere := SphereMesh.new()
		sphere.radius = 0.7
		sphere.height = 0.9
		v.mesh_at(sphere, Vector3.UP * 0.6, mat, body)
		for side in [-1.0, 1.0]:
			for i in range(3):
				var leg: MeshInstance3D = v.box(Vector3(side * 0.8, 0.3, (i - 1) * 0.5), Vector3(1, 0.13, 0.13), mat, false, body)
				leg.rotation.z = side * 0.35
	var ring := TorusMesh.new()
	ring.inner_radius = 2.0 if id == "guardian" else 1.35
	ring.outer_radius = ring.inner_radius + 0.1
	var warning: MeshInstance3D = v.mesh_at(ring, at + Vector3.UP * 0.13, v.material("d28c4e", true))
	warning.hide()
	var health_label: Label3D = v.sign_text(title, at + Vector3.UP * (3.2 if id == "guardian" else 1.8), 24)
	enemies.append({"id": id, "node": body, "origin": at, "hp": health, "max_hp": health,
		"title": title, "cooldown": 2.0, "windup": -1.0, "mark": at,
		"warning": warning, "label": health_label})

func is_dead(enemy: Dictionary) -> bool:
	return game.progress.spitter_dead if enemy.id == "spitter" else game.progress.guardian_dead

func reset_encounters() -> void:
	for enemy in enemies:
		enemy.hp = enemy.max_hp
		enemy.node.position = enemy.origin
		enemy.cooldown = 2.0
		enemy.windup = -1.0
		enemy.warning.hide()
	sync()

func sync() -> void:
	var p = game.progress
	gate.visible = p.runes < 3
	gate_shape.set_deferred("disabled", p.runes == 3)
	relic_node.visible = not p.relic
	for i in range(3):
		rune_nodes[i].material_override = game.valley.material("bad8b2" if i < p.runes else "52675f", i < p.runes)
		var remaining: float = p.plots[i] - p.world_time
		crop_nodes[i].visible = p.plots[i] >= 0
		crop_nodes[i].scale = Vector3.ONE * (1.0 if remaining <= 0 else 0.25 + 0.75 * clampf(1 - remaining / 90.0, 0, 1))
		crop_labels[i].text = "灵田 %d · %s" % [i + 1, "待播种" if p.plots[i] < 0 else ("可收获" if remaining <= 0 else "%d 秒" % ceili(remaining))]
	owner_label.text = p.character_name + "的洞府 · E 入室" if p.home_claimed else "无主石室 · E 认领"
	home_banner.material_override = game.valley.material(["536f64", "956f48", "69747d"][p.home_style])
	for lamp in home_lamps:
		lamp.visible = p.home_claimed
		lamp.light_color = [Color("bbd7c5"), Color("ffd5a0"), Color("c6d8ed")][p.home_style]
	for enemy in enemies:
		enemy.node.visible = not is_dead(enemy)
		enemy.label.visible = not is_dead(enemy)
		if is_dead(enemy):
			enemy.warning.hide()

func _process(delta: float) -> void:
	if not game.playing or game.paused or game.progress.inside_home:
		return
	visual_timer -= delta
	if visual_timer <= 0:
		visual_timer = 1
		sync()
	for enemy in enemies:
		if is_dead(enemy) or (enemy.id == "guardian" and game.progress.runes != 3):
			continue
		update_enemy(enemy, delta)

func update_enemy(enemy: Dictionary, delta: float) -> void:
	var at: Vector3 = enemy.node.position
	var distance: float = game.traveler.position.distance_to(at)
	enemy.cooldown -= delta
	if enemy.windup >= 0:
		enemy.windup -= delta
		if enemy.windup < 0:
			enemy.warning.hide()
			launch_enemy_attack(enemy)
	elif distance < 12 and enemy.cooldown <= 0:
		enemy.windup = 0.6 if enemy.id == "guardian" and enemy.hp <= enemy.max_hp / 2 else 1.0
		enemy.cooldown = 2.2
		enemy.mark = Vector3(game.traveler.position.x, 0.14, game.traveler.position.z)
		enemy.warning.position = enemy.mark
		enemy.warning.show()
	elif enemy.id == "guardian" and distance < 13 and distance > 4:
		var move: Vector3 = (game.traveler.position - at).normalized() * delta * 1.6
		enemy.node.position += move * Vector3(1, 0, 1)
		enemy.node.position.x = clampf(enemy.node.position.x, 19, 30)
		enemy.node.position.z = clampf(enemy.node.position.z, -32, -22)
	if distance > 0.1:
		enemy.node.rotation.y = atan2(at.x - game.traveler.position.x, at.z - game.traveler.position.z)
	enemy.label.position = enemy.node.position + Vector3.UP * (3.2 if enemy.id == "guardian" else 1.8)
	enemy.label.text = "%s  %d / %d%s" % [enemy.title, int(enemy.hp), int(enemy.max_hp), " · 狂暴" if enemy.id == "guardian" and enemy.hp <= enemy.max_hp / 2 else ""]

func launch_enemy_attack(enemy: Dictionary) -> void:
	var at: Vector3 = enemy.node.position + Vector3.UP
	var impact: Vector3 = enemy.mark
	var ray := PhysicsRayQueryParameters3D.create(at, impact + Vector3.UP)
	ray.exclude = [game.traveler.get_rid()]
	if not game.get_world_3d().direct_space_state.intersect_ray(ray).is_empty():
		return
	var orb := SphereMesh.new()
	orb.radius = 0.18
	orb.height = 0.36
	var shot: MeshInstance3D = game.valley.mesh_at(orb, at, game.valley.material("c8a15f" if enemy.id == "guardian" else "8ba851", true))
	var generation: int = game.journey_generation
	var tween := create_tween()
	tween.tween_property(shot, "position", impact + Vector3.UP * 0.6, 0.4)
	tween.tween_callback(func():
		shot.queue_free()
		if not game.playing or game.journey_generation != generation or is_dead(enemy):
			return
		var radius: float = 2.1 if enemy.id == "guardian" else 1.5
		if game.traveler.position.distance_to(impact) < radius:
			game.take_damage(28 if enemy.id == "guardian" else 14)
	)

func hit(id: String, damage: float) -> void:
	for enemy in enemies:
		if enemy.id != id or is_dead(enemy):
			continue
		enemy.hp = maxf(0, enemy.hp - damage)
		if enemy.hp == 0:
			if id == "spitter":
				game.progress.spitter_dead = true
				game.frontier.drop(enemy.node.position, [{"item": "herb", "count": 2}, {"item": "coins", "count": 8}])
				game.notify("青瘴灵蛛已败，灵草与金币掉在地上，靠近按 E 拾取。")
			else:
				game.progress.guardian_dead = true
				game.frontier.drop(enemy.node.position, [{"item": "core", "count": 2}, {"item": "coins", "count": 20}])
				game.notify("镇府石卫已败！前往石室深处取得传承玉简。")
			sync()
			game.save_game(false)

func interact(point_data: Dictionary) -> void:
	var p = game.progress
	match point_data.kind:
		"claim_home":
			if p.home_claimed:
				game.room.enter()
			else:
				p.claim_home()
				game.notify("认领成功，获得三枚灵种！再按 E 进入独立房间，屋外北侧可种灵田。")
		"plot":
			game.notify(p.plant_or_harvest(point_data.id))
		"decor":
			if not p.home_claimed:
				game.notify("先认领洞府，才能调整布置。")
				return
			p.home_style = (p.home_style + 1) % 3
			game.room.apply_style()
			game.notify("洞府布置已切换为：" + ["青竹", "暖灯", "素石"][p.home_style])
		"gate":
			game.notify("碑记：山生水，水映月。依次触发山、水、月三柱；错序会重置。")
		"rune":
			if not p.learned:
				game.notify("先去北面洞府习得功法，才能唤醒阵柱。")
				return
			if p.runes == 3:
				game.notify("阵法已解，石门已经开启。")
			else:
				var correct: bool = p.activate_rune(point_data.id)
				game.notify(("三柱共鸣，遗府石门开启！" if p.runes == 3 else "阵柱响应：%d / 3。" % p.runes) if correct else "阵序不符，三柱熄灭。重新从山之柱开始。")
		"relic":
			if p.take_relic():
				game.notify("获得传承：火弹术（2 / R）、飞剑强化，以及三枚灵种！")
			elif p.relic:
				game.notify("传承已取，可回府种植、储物与修炼。")
			else:
				game.notify("需达到炼气一层，解开三柱并击败镇府石卫，才能取得传承。")
	sync()
	game.save_game(false)

func transfer(to_vault: bool) -> void:
	game.room.transfer("herb", to_vault)

func update_storage() -> void:
	game.room.update_storage()

func cultivate_near_bed() -> bool:
	return game.room.begin_rest(true)

func in_combat() -> bool:
	if game.progress.inside_home: return false
	if game.frontier.in_combat():
		return true
	if not game.progress.beast_dead and game.traveler.position.distance_to(game.valley.beast.position) < 11:
		return true
	for enemy in enemies:
		if not is_dead(enemy) and (enemy.id != "guardian" or game.progress.runes == 3) and game.traveler.position.distance_to(enemy.node.position) < 13:
			return true
	return false

func return_home() -> bool:
	if not game.progress.home_claimed or in_combat():
		game.notify("回府需要已认领洞府，且附近没有正在威胁你的妖兽。")
		return false
	if game.progress.inside_home:
		game.room.leave()
	game.traveler.position = HOME
	game.traveler.velocity = Vector3.ZERO
	game.traveler.yaw = 0
	game.save_game(false)
	game.notify("已回到自己的洞府。")
	return true
