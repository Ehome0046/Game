extends Node3D

const Progress = preload("res://scripts/progress.gd")
const Traveler = preload("res://scripts/traveler.gd")
const Valley = preload("res://scripts/valley.gd")
const Adventure = preload("res://scripts/adventure.gd")
const Effects = preload("res://scripts/effects.gd")
const Navigation = preload("res://scripts/navigation.gd")
const Frontier = preload("res://scripts/frontier.gd")
const Town = preload("res://scripts/town.gd")
const Rules = preload("res://scripts/world_rules.gd")
const Interior = preload("res://scripts/home_interior.gd")
const HUD = preload("res://scripts/hud.gd")
const SAVE := "res://.local/saves/journey.json"
var progress = Progress.new()
var traveler: CharacterBody3D
var valley: Node3D
var adventure: Node3D
var effects: Node3D
var navigation: Control
var frontier: Node3D
var town: Node3D
var room: Node3D
var hud: Control
var compat_mouse := false
var exiting := false
var ui: Control
var menu: PanelContainer
var pause_panel: PanelContainer
var name_input: LineEdit
var robe_input: OptionButton
var identity: Label
var quest: Label
var meters: Label
var wallet: Label
var region_label: Label
var prompt: Label
var message: Label
var journal: Label
var quest_panel: PanelContainer
var controls: Label
var skills: Label
var shield_mesh: MeshInstance3D
var enemy_label: Label3D
var playing := false
var paused := false
var beast_hp := 112.0
var attack_cooldown := 0.0
var enemy_cooldown := 1.8
var windup := -1.0
var message_time := 0.0
var autosave_time := 0.0
var test_mode := false
var journey_generation := 0
var shield_strength := 0.0
var shield_time := 0.0
var shield_cooldown := 0.0
var fire_cooldown := 0.0
var combo_stage := -1
var combo_window := 0.0
var paused_for_focus := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	test_mode = "--test" in OS.get_cmdline_user_args()
	setup_input()
	valley = Valley.new()
	valley.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(valley)
	traveler = Traveler.new()
	traveler.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(traveler)
	traveler.position = Vector3(0, 0.1, 18)
	enemy_label = valley.sign_text("石角兽  112 / 112", valley.beast_origin + Vector3.UP * 2.4, 24)
	setup_ui()
	adventure = Adventure.new()
	adventure.game = self
	add_child(adventure)
	effects = Effects.new()
	add_child(effects)
	traveler.connect("footstep", Callable(effects, "footstep"))
	var sphere := SphereMesh.new()
	sphere.radius = 0.85
	sphere.height = 2.1
	shield_mesh = MeshInstance3D.new()
	shield_mesh.mesh = sphere
	var shield_material := StandardMaterial3D.new()
	shield_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	shield_material.albedo_color = Color(0.45, 0.8, 0.75, 0.18)
	shield_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	shield_mesh.material_override = shield_material
	add_child(shield_mesh)
	shield_mesh.hide()
	frontier = Frontier.new()
	frontier.game = self
	add_child(frontier)
	town = Town.new()
	town.game = self
	add_child(town)
	room = Interior.new()
	room.game = self
	add_child(room)
	adventure.storage_panel = room.storage_panel
	adventure.storage_label = room.storage_label
	hud = HUD.new()
	hud.game = self
	ui.add_child(hud)
	room.restore()
	load_mouse_preference()
	navigation = Navigation.new()
	navigation.game = self
	ui.add_child(navigation)
	get_tree().auto_accept_quit = false
	get_window().focus_entered.connect(on_focus_entered)
	get_window().focus_exited.connect(on_focus_exited)
	get_window().close_requested.connect(request_exit)
	show_menu()

func setup_input() -> void:
	var keys := {"forward": [KEY_W, KEY_UP], "back": [KEY_S, KEY_DOWN],
		"left": [KEY_A, KEY_LEFT], "right": [KEY_D, KEY_RIGHT], "run": [KEY_SHIFT],
		"dodge": [KEY_SPACE], "interact": [KEY_E], "cast": [KEY_Q, KEY_1], "save": [KEY_F5], "journal": [KEY_TAB],
		"fire": [KEY_R, KEY_2], "shield": [KEY_F, KEY_3], "cultivate": [KEY_G], "home": [KEY_H],
		"map": [KEY_M], "track_home": [KEY_N], "heal": [KEY_4], "mana": [KEY_5]}
	for action in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key in keys[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("cast", click)

func label(text: String, size: int, color := Color("e6e7d7")) -> Label:
	var result := Label.new()
	result.text = text
	result.add_theme_font_size_override("font_size", size)
	result.add_theme_color_override("font_color", color)
	return result

func panel(at: Vector2, size: Vector2) -> PanelContainer:
	var result := PanelContainer.new()
	result.position = at
	result.custom_minimum_size = size
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.075, 0.07, 0.93)
	style.border_color = Color("8b9272")
	style.set_border_width_all(1)
	style.content_margin_left = 28
	style.content_margin_right = 28
	style.content_margin_top = 24
	style.content_margin_bottom = 24
	result.add_theme_stylebox_override("panel", style)
	ui.add_child(result)
	return result

func button(text: String, callback: Callable, parent: Node) -> Button:
	var result := Button.new()
	result.text = text
	result.custom_minimum_size.y = 44
	result.pressed.connect(callback)
	parent.add_child(result)
	return result

func setup_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	ui = Control.new()
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var theme := Theme.new()
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Microsoft YaHei", "Noto Sans CJK SC", "sans-serif"])
	theme.default_font = font
	theme.default_font_size = 18
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("253a31")
	normal.border_color = Color("73816b")
	normal.set_border_width_all(1)
	normal.set_corner_radius_all(4)
	var hover: StyleBoxFlat = normal.duplicate()
	hover.bg_color = Color("3b5140")
	hover.border_color = Color("d4bb84")
	theme.set_stylebox("normal", "Button", normal)
	theme.set_stylebox("hover", "Button", hover)
	theme.set_stylebox("pressed", "Button", hover)
	theme.set_color("font_shadow_color", "Label", Color(0, 0, 0, 0.85))
	theme.set_constant("shadow_offset_x", "Label", 1)
	theme.set_constant("shadow_offset_y", "Label", 2)
	ui.theme = theme
	canvas.add_child(ui)
	identity = label("", 27)
	identity.position = Vector2(34, 28)
	ui.add_child(identity)
	meters = label("", 17, Color("c6d5bb"))
	meters.position = Vector2(35, 68)
	ui.add_child(meters)
	wallet = label("", 16, Color("e2cb91"))
	wallet.position = Vector2(35, 94)
	ui.add_child(wallet)
	quest_panel = panel(Vector2(28, 218), Vector2(310, 150))
	quest_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	quest = label("", 17)
	quest.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quest.custom_minimum_size.x = 255
	quest_panel.add_child(quest)
	quest_panel.name = "QuestPanel"
	region_label = label("青 岚 谷\n雨霁 · 卯时", 21, Color("e1dfc7"))
	region_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	region_label.position = Vector2(1030, 30)
	region_label.size.x = 210
	ui.add_child(region_label)
	message = label("", 18, Color("f0d49b"))
	message.position = Vector2(445, 34)
	message.size = Vector2(420, 75)
	message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ui.add_child(message)
	prompt = label("", 22)
	prompt.position = Vector2(360, 575)
	prompt.size.x = 560
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(prompt)
	skills = label("", 18, Color("d3d7b2"))
	skills.position = Vector2(34, 643)
	ui.add_child(skills)
	controls = label("WASD 移动 · Shift 跑 · 空格闪避 · E 交互 · M 地图 · Tab 行囊", 12)
	controls.position = Vector2(28, 689)
	ui.add_child(controls)
	menu = panel(Vector2(55, 118), Vector2(440, 530))
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	menu.add_child(column)
	column.add_child(label("青 岚 问 道", 42, Color("dfc997")))
	column.add_child(label("v0.4.0 · 洞府新居", 18))
	column.add_child(label("一介凡人，从此山开始。", 19))
	name_input = LineEdit.new()
	name_input.placeholder_text = "取一个道名"
	name_input.text = "无名"
	name_input.max_length = 16
	name_input.custom_minimum_size.y = 42
	column.add_child(name_input)
	robe_input = OptionButton.new()
	for color_name in Progress.ROBES:
		robe_input.add_item("行装 · " + color_name)
	robe_input.item_selected.connect(func(index: int): traveler.set_robe(index))
	column.add_child(robe_input)
	button("创建角色 · 入山", request_new, column)
	button("继续上次旅程", continue_game, column)
	button("退出到桌面", request_exit, column)
	column.add_child(label("占位模型 · 非最终写实画质", 15, Color("a6b4a8")))
	pause_panel = panel(Vector2(385, 24), Vector2(510, 664))
	var pause_column := VBoxContainer.new()
	pause_column.add_theme_constant_override("separation", 8)
	pause_panel.add_child(pause_column)
	pause_column.add_child(label("暂 歇", 32, Color("dfc997")))
	journal = label("", 14)
	pause_column.add_child(journal)
	button("继续修行", func(): set_paused(false), pause_column)
	button("保存旅程", func(): save_game(), pause_column)
	button("保存并返回标题", return_to_title, pause_column)
	var input_row := HBoxContainer.new()
	input_row.add_theme_constant_override("separation", 8)
	pause_column.add_child(input_row)
	button("F8 切换鼠标模式", toggle_mouse_mode, input_row)
	button("保存并退出", request_exit, input_row)
	pause_panel.hide()

func request_new() -> void:
	if name_input.text.strip_edges().is_empty():
		notify("先给自己取一个道名。")
		return
	if FileAccess.file_exists(SAVE):
		var dialog := ConfirmationDialog.new()
		dialog.dialog_text = "创建新角色将覆盖上次旅程，是否继续？"
		dialog.title = "重新入山"
		dialog.confirmed.connect(begin_new)
		dialog.confirmed.connect(dialog.queue_free)
		dialog.canceled.connect(dialog.queue_free)
		ui.add_child(dialog)
		dialog.popup_centered()
	else:
		begin_new()

func begin_new() -> void:
	progress = Progress.new()
	progress.character_name = name_input.text.strip_edges()
	progress.robe = robe_input.selected
	start_game(Vector3(0, 0.1, 18))
	save_game(false)
	notify("北面残卷可学御剑；村南坊市找顾伯接委托。采药、猎妖、交易可反复进行。")

func start_game(at: Vector3) -> void:
	journey_generation += 1
	get_tree().paused = false
	playing = true
	paused = false
	menu.hide()
	quest_panel.show()
	controls.show()
	wallet.show()
	skills.show()
	pause_panel.hide()
	# A v0.1 save can be in the field where the sealed ruins were later built.
	# Keep that old position from trapping an uninitiated player behind the gate.
	if progress.runes < 3 and at.x > 17.2 and at.x < 32 and at.z > -35.5 and at.z < -18.5:
		at = Vector3(24, 0.1, -16)
	if not progress.inside_home and at.x > -29 and at.x < -21 and at.z > 12.5 and at.z < 21:
		at = adventure.HOME
	traveler.position = at
	traveler.sitting = false
	traveler.busy = false
	traveler.interaction_time = 0
	traveler.sit_blend = 0
	traveler.velocity = Vector3.ZERO
	traveler.yaw = 0
	traveler.pitch = -0.28
	traveler.set_robe(progress.robe)
	traveler.enabled = true
	valley.beast.position = valley.beast_origin
	beast_hp = 112.0
	attack_cooldown = 0
	enemy_cooldown = 1.8
	windup = -1
	shield_strength = 0
	shield_time = 0
	shield_cooldown = 0
	fire_cooldown = 0
	combo_stage = -1
	combo_window = 0
	traveler.invincible = 0
	traveler.dodge_cooldown = 0
	shield_mesh.hide()
	adventure.storage_panel.hide()
	adventure.reset_encounters()
	frontier.reset()
	room.restore(at if progress.inside_home else Interior.ENTRY)
	town.hide_popup()
	effects.clear()
	navigation.reset()
	autosave_time = 0
	sync_world()
	capture_mouse()
	update_hud()

func show_menu() -> void:
	journey_generation += 1
	get_tree().paused = false
	playing = false
	paused = false
	room.stop_rest()
	room.close_storage()
	hud.hide()
	paused_for_focus = false
	navigation.hide_map()
	traveler.enabled = false
	effects.clear()
	menu.show()
	quest_panel.hide()
	controls.hide()
	wallet.hide()
	town.hide_popup()
	skills.hide()
	shield_mesh.hide()
	adventure.storage_panel.hide()
	pause_panel.hide()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	identity.text = "山中一日，世上千年。"
	meters.text = ""
	quest.text = "自由角色 · 单人 3D\n\n探索洞府 / 采集灵草\n御剑战斗 / 炼气入门"
	prompt.text = ""

func set_paused(value: bool) -> void:
	paused = value
	get_tree().paused = value
	traveler.enabled = playing and not paused
	pause_panel.visible = value
	adventure.storage_panel.hide()
	town.hide_popup()
	navigation.hide_map()
	room.close_storage()
	journal.text = "道名：%s  ·  %s\n灵草 %d  妖丹 %d  灵种 %d\n洞府：%s  ·  修炼 %d / 3\n阵柱 %d / 3  ·  传承 %s\n\n路线：北面残卷 → 石角兽 → 静心台\n东侧遗府：山、水、月三柱 → 石卫\n村庄西侧：认领洞府，播种与储物\n蒲团 E 调息 / G 修炼；脱战后 H 回府" % [progress.character_name,
		"炼气一层" if progress.realm else "凡人", progress.herbs(), int(progress.core), progress.seeds,
		"已认领" if progress.home_claimed else "未认领", progress.cultivation, progress.runes, "已取得" if progress.relic else "未取得"]
	journal.text += "\n金币 %d · 兽丹 %d · 飞剑强化 %d/8\n养元丹 %d（4）· 回灵散 %d（5）" % [progress.coins, progress.beast_cores, progress.weapon_level, progress.heal_potions, progress.mana_potions]
	journal.text += "\n鼠标模式：%s · F8 切换 / F10 释放" % ("兼容" if compat_mouse else "标准")
	journal.text += "\n洞府开局可认领：M 地图，N 金色引路。"
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED
	if not value:
		capture_mouse()
		call_deferred("capture_mouse")
		if paused_for_focus:
			paused_for_focus = false
			notify("镜头已恢复。直接移动鼠标即可转向，右键可重新锁定。")
	if test_mode:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func capture_mouse() -> void:
	if not playing or paused:
		return
	get_viewport().gui_release_focus()
	traveler.enabled = true
	traveler.compatibility_mouse = compat_mouse
	if not test_mode:
		Input.mouse_mode = Input.MOUSE_MODE_CONFINED_HIDDEN if compat_mouse else Input.MOUSE_MODE_CAPTURED
		traveler.mouse_anchor = get_viewport().get_visible_rect().size / 2
		if compat_mouse: Input.warp_mouse(traveler.mouse_anchor)

func load_mouse_preference() -> void:
	if FileAccess.file_exists("res://.local/mouse.json"):
		var value: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://.local/mouse.json"))
		if value is Dictionary and value.get("compatibility") is bool:
			compat_mouse = value.compatibility

func toggle_mouse_mode() -> void:
	compat_mouse = not compat_mouse
	traveler.compatibility_mouse = compat_mouse
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://.local"))
	var file := FileAccess.open("res://.local/mouse.json", FileAccess.WRITE)
	if file: file.store_string(JSON.stringify({"compatibility": compat_mouse}))
	if playing and not paused: capture_mouse()
	notify("已切换为%s鼠标。关闭暂停界面后，点击画面或右键进入控制。" % ("兼容" if compat_mouse else "标准"))

func _input(event: InputEvent) -> void:
	# Recovery shortcuts run before GUI controls so no overlay can swallow them.
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F8 or event.physical_keycode == KEY_F8:
			toggle_mouse_mode()
			get_viewport().set_input_as_handled()
			return
		if playing and (event.keycode == KEY_F10 or event.physical_keycode == KEY_F10):
			set_paused(true)
			get_viewport().set_input_as_handled()
			return
		if playing and (event.is_action_pressed("ui_cancel") or event.is_action_pressed("journal")):
			if navigation.map_panel.visible: navigation.close_map()
			else: set_paused(not paused)
			get_viewport().set_input_as_handled()
			return
	if not playing:
		return
	if event is InputEventMouseButton and event.pressed:
		if paused and paused_for_focus and event.button_index == MOUSE_BUTTON_LEFT:
			set_paused(false)
			get_viewport().set_input_as_handled()
		elif not paused and (event.button_index == MOUSE_BUTTON_RIGHT or (event.button_index == MOUSE_BUTTON_LEFT and Input.mouse_mode == Input.MOUSE_MODE_VISIBLE)):
			capture_mouse()
			get_viewport().set_input_as_handled()

func _unhandled_input(event: InputEvent) -> void:
	if not playing:
		return
	if event.is_action_pressed("map"):
		if navigation.map_panel.visible:
			navigation.close_map()
		else:
			navigation.open_map()
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("ui_cancel") or event.is_action_pressed("journal"):
		if navigation.map_panel.visible:
			navigation.close_map()
		else:
			set_paused(not paused)
		get_viewport().set_input_as_handled()
		return
	if paused:
		return
	if event.is_action_pressed("interact"):
		interact()
	elif event.is_action_pressed("track_home"):
		navigation.toggle_tracking()
	elif event.is_action_pressed("cast"):
		cast_sword()
	elif event.is_action_pressed("fire"):
		cast_attack("fire")
	elif event.is_action_pressed("shield"):
		cast_shield()
	elif event.is_action_pressed("cultivate"):
		adventure.cultivate_near_bed()
	elif event.is_action_pressed("home"):
		adventure.return_home()
	elif event.is_action_pressed("save"):
		save_game()
	elif event.is_action_pressed("heal") or event.is_action_pressed("mana"):
		var kind := "heal" if event.is_action_pressed("heal") else "mana"
		if progress.use_potion(kind):
			traveler.play_interaction(kind, traveler.position)
			notify("已使用药品恢复状态。")
			save_game(false)
		else:
			notify("没有对应药品，或当前状态已满。村南沈娘处可以买补给。")

func nearest() -> Dictionary:
	var result := {}
	var distance := 2.7
	var candidates: Array = room.points if progress.inside_home else valley.interactions
	for point in candidates:
		if not frontier.available(point):
			continue
		var d: float = traveler.position.distance_to(point.position)
		if d < distance:
			distance = d
			result = point
	return result

func interact() -> void:
	if room.meditating:
		room.stop_rest()
		return
	var point := nearest()
	if point.is_empty():
		notify("靠近灵草、洞府残卷或静心台，再按 E。")
		return
	traveler.play_interaction(point.kind, point.position)
	match point.kind:
		"exit_home":
			room.leave()
		"storage":
			room.open_storage()
		"bed":
			room.begin_rest(false)
		"herb":
			frontier.harvest(point)
		"wild_herb":
			frontier.harvest(point)
		"loot":
			frontier.pickup(point.id)
		"npc":
			town.open_dialog(point.npc)
		"survey":
			if progress.active_order == "survey":
				progress.surveyed = true
				notify("石谷界碑勘察完成，返回村长顾伯处交付委托。")
			else:
				notify("这里是石谷界碑。顾伯的勘察委托会带你来到此处。")
		"scroll":
			progress.learned = true
			notify("领悟御剑诀。Q 或左键御剑，灵力会缓慢恢复。")
		"altar":
			if progress.breakthrough():
				notify("引气入体 · 炼气一层！生命与灵力上限提升至 140。")
			else:
				progress.hp = progress.max_hp()
				progress.qi = progress.max_qi()
				notify("静心调息，状态已恢复。" if progress.realm else "调息恢复。突破还需：功法、三株灵草、一枚妖丹。")
		_:
			adventure.interact(point)
	sync_world()
	save_game(false)
	update_hud()

func sync_world() -> void:
	frontier.sync_resources()
	valley.beast.visible = not progress.beast_dead
	enemy_label.visible = not progress.beast_dead
	adventure.sync()

func cast_sword() -> bool:
	return cast_attack("sword")

func combat_target() -> Dictionary:
	var best := {}
	var distance := 13.0
	if not progress.beast_dead:
		var d: float = traveler.position.distance_to(valley.beast.position)
		if d <= distance:
			distance = d
			best = {"id": "beast", "node": valley.beast}
	for enemy in adventure.enemies:
		if adventure.is_dead(enemy) or (enemy.id == "guardian" and progress.runes != 3):
			continue
		var d: float = traveler.position.distance_to(enemy.node.position)
		if d < distance:
			distance = d
			best = {"id": enemy.id, "node": enemy.node}
	for enemy in frontier.enemies:
		if frontier.dead(enemy):
			continue
		var d: float = traveler.position.distance_to(enemy.node.position)
		if d < distance:
			distance = d
			best = {"id": enemy.id, "node": enemy.node}
	return best

func cast_attack(kind: String) -> bool:
	if attack_cooldown > 0 or progress.inside_home or room.meditating:
		return false
	if not progress.learned:
		notify("尚未习得功法。沿石径向北寻找洞府残卷。")
		return false
	if kind == "fire" and (not progress.relic or fire_cooldown > 0):
		notify("火弹术需要取得遗府传承，并等待三秒冷却。")
		return false
	var victim := combat_target()
	if victim.is_empty():
		notify("附近没有可锁定的妖兽。御剑范围为 13 米。")
		return false
	var target: Vector3 = victim.node.position + Vector3.UP
	var ray := PhysicsRayQueryParameters3D.create(traveler.position + Vector3.UP, target)
	ray.exclude = [traveler.get_rid()]
	if victim.node is CollisionObject3D:
		ray.exclude = [traveler.get_rid(), victim.node.get_rid()]
	if not get_world_3d().direct_space_state.intersect_ray(ray).is_empty():
		notify("法器被地形遮挡，请移动到开阔处。")
		return false
	if not progress.spend_qi(24 if kind == "fire" else 14):
		notify("灵力不足，稍候恢复或回静心台调息。")
		return false
	attack_cooldown = 0.55
	var damage: float = 60 if kind == "fire" else (40 if progress.realm else 28)
	if kind == "sword":
		combo_stage = (combo_stage + 1) % 3 if combo_window > 0 else 0
		combo_window = 1.4
		damage *= [1.0, 1.15, 1.4][combo_stage]
		if progress.relic:
			damage *= 1.15
		if combo_stage == 2:
			notify("飞剑三连 · 破阵！")
	else:
		fire_cooldown = 3
	damage += progress.cultivation * 2 + progress.weapon_level * 3
	traveler.play_cast(kind)
	var cast_generation := journey_generation
	effects.launch(kind, traveler.position + Vector3(0.35, 1.35, 0), victim.node, combo_stage, func():
		if not playing or journey_generation != cast_generation:
			return
		effects.impact(victim.node.position + Vector3.UP, damage, kind, victim.node)
		if victim.id in Rules.FIELD_IDS:
			frontier.hit(victim.id, damage)
			return
		if victim.id != "beast":
			adventure.hit(victim.id, damage)
			return
		if not progress.beast_dead:
			beast_hp = maxf(0, beast_hp - damage)
			if beast_hp == 0:
				progress.beast_dead = true
				frontier.drop(valley.beast.position, [{"item": "core", "count": 1}, {"item": "coins", "count": 10}])
				sync_world()
				save_game(false)
				notify("石角兽已败！兽丹和金币掉在地上，靠近按 E 拾取，再回静心台突破。")
	)
	return true

func cast_shield() -> bool:
	if shield_cooldown > 0 or not progress.spend_qi(20):
		notify("护体术需要已学功法、20 点灵力，并等待十秒冷却。")
		return false
	shield_strength = 45
	shield_time = 5
	shield_cooldown = 10
	shield_mesh.show()
	traveler.play_cast("shield")
	effects.ring(traveler.position + Vector3.UP * 0.5, Color("b4efdb"), 0.8)
	notify("护体术：五秒内吸收最多 45 点伤害。")
	return true

func take_damage(amount: float) -> void:
	if traveler.invincible > 0:
		return
	var absorbed: float = minf(shield_strength, amount)
	shield_strength -= absorbed
	amount -= absorbed
	if absorbed > 0:
		effects.ring(traveler.position + Vector3.UP, Color("b4efdb"), 0.65)
	elif amount > 0:
		effects.burst(traveler.position + Vector3.UP, Color("dfb399"), 6)
	progress.hp = maxf(0, progress.hp - amount)
	notify("护体抵挡攻击！" if amount == 0 else "受到攻击，注意地面预警与空格闪避。")
	if progress.hp <= 0:
		progress.hp = progress.max_hp()
		progress.qi = progress.max_qi()
		traveler.position = valley.altar + Vector3(0, 0.2, 2)
		traveler.velocity = Vector3.ZERO
		valley.beast.position = valley.beast_origin
		beast_hp = 112
		windup = -1
		shield_strength = 0
		adventure.reset_encounters()
		frontier.reset_encounters()
		if navigation.tracking:
			navigation.plan_route()
		save_game(false)
		notify("力竭后在静心台苏醒，物品保留，存活的敌人恢复。")

func _process(delta: float) -> void:
	if is_instance_valid(hud): hud.refresh(delta)
	if playing:
		quest_panel.visible = not paused
		controls.visible = not paused
		region_label.text = "自 有 洞 府\n室内 · 安居" if progress.inside_home else "青 岚 谷\n雨霁 · 卯时"
	identity.visible = not playing
	meters.hide()
	wallet.hide()
	skills.hide()
	message_time -= delta
	message.visible = message_time > 0
	if not playing or paused:
		return
	effects.update_orbit(traveler.position, traveler.model.rotation.y, progress.learned, delta)
	attack_cooldown = maxf(0, attack_cooldown - delta)
	combo_window = maxf(0, combo_window - delta)
	fire_cooldown = maxf(0, fire_cooldown - delta)
	shield_cooldown = maxf(0, shield_cooldown - delta)
	shield_time = maxf(0, shield_time - delta)
	if shield_time == 0:
		shield_strength = 0
	shield_mesh.visible = shield_strength > 0
	shield_mesh.position = traveler.position + Vector3.UP
	progress.world_time += delta
	progress.qi = minf(progress.max_qi(), progress.qi + delta * 6)
	autosave_time += delta
	if autosave_time > 20:
		save_game(false)
		autosave_time = 0
	if not progress.beast_dead and not progress.inside_home:
		update_beast(delta)
	update_hud()

func update_beast(delta: float) -> void:
	var offset: Vector3 = traveler.position - valley.beast.position
	offset.y = 0
	var distance := offset.length()
	enemy_cooldown -= delta
	if windup >= 0:
		windup -= delta
		valley.beast.scale = Vector3.ONE * (1.0 + 0.06 * sin(windup * 25))
		if windup < 0:
			valley.beast.scale = Vector3.ONE
			if distance < 2.8 and traveler.invincible <= 0:
				take_damage(18)
	elif distance < 2.2 and enemy_cooldown <= 0:
		windup = 0.65
		enemy_cooldown = 2.0
	elif distance < 10 and distance > 1.8:
		valley.beast.position += offset.normalized() * delta * 2.2
	elif distance > 14:
		valley.beast.position = valley.beast.position.move_toward(valley.beast_origin, delta * 2)
	if distance > 0.05:
		valley.beast.rotation.y = atan2(-offset.x, -offset.z)
	enemy_label.position = valley.beast.position + Vector3.UP * 2.4
	enemy_label.text = "蓄力冲撞 · 空格闪避" if windup >= 0 else "石角兽  %d / 112" % int(beast_hp)

func update_hud() -> void:
	identity.text = "%s  /  %s" % [progress.character_name, "炼气一层" if progress.realm else "凡人"]
	meters.text = "生命 %d / %d    灵力 %d / %d" % [int(progress.hp), int(progress.max_hp()), int(progress.qi), int(progress.max_qi())]
	wallet.text = "金币 %d    灵草 %d    兽丹 %d    养元丹 %d（4）  回灵散 %d（5）  飞剑 +%d" % [progress.coins, progress.herbs(), progress.beast_cores, progress.heal_potions, progress.mana_potions, progress.weapon_level]
	if progress.realm and not progress.relic:
		quest.text = "叁 / 遗府传承\n\n往东侧遗府依次激活山、水、月阵柱（%d/3）。\n击败石卫，取得火弹术传承。" % progress.runes
	elif progress.relic:
		quest.text = "肆 / 归居修行\n\n村西认领洞府，播种灵草、储物。\n蒲团 E 调息，G 修炼（%d/3）。" % progress.cultivation
	elif not progress.learned:
		quest.text = "壹 / 寻仙\n\n沿石径向北寻找洞府。\n靠近残卷，按 E 领悟功法。"
	else:
		quest.text = "贰 / 引气入体\n\n灵草 %d / 3    妖丹 %d / 1\n石角兽在洞府东南侧。\n备齐材料后，回静心台按 E。" % [progress.herbs(), int(progress.core)]
	if not progress.home_claimed:
		quest.text += "\n\n安家支线：M 地图，N 洞府引路。"
	if not progress.active_order.is_empty():
		quest.text = "坊市委托 / 可重复\n\n" + town.objective() + "\n\n回村南顾伯处交付。\nM 地图可切区域总览。"
	else:
		quest.text += "\n村南顾伯：可重复委托。"
	if progress.inside_home:
		quest.text = "洞府 / 安居修行\n\n右侧箱子：E 打开物品格\n左侧蒲团：E 调息 / G 修炼\n身后门口：E 返回庭院\n屋外北侧：三块灵田"
	var point := nearest()
	skills.text = "1 / Q 御剑三连   2 / R 火弹[%s]   3 / F 护体[%s]   灵种 %d   修炼 %d/3" % [
		"未传承" if not progress.relic else ("就绪" if fire_cooldown == 0 else "%.1fs" % fire_cooldown),
		"未领悟" if not progress.learned else ("就绪" if shield_cooldown == 0 else "%.1fs" % shield_cooldown), progress.seeds, progress.cultivation]
	prompt.text = ""
	if room.meditating:
		prompt.text = "[ E ] 起身 · [ G ] 继续修炼"
	elif not point.is_empty():
		var names := {"herb": "采集灵草", "scroll": "参悟残卷", "altar": "调息 / 尝试突破"}
		prompt.text = "[ E ]  " + names.get(point.kind, point.get("label", "交互"))

func notify(text: String) -> void:
	message.text = text
	message_time = 5.0
	message.show()

func save_game(feedback := true) -> bool:
	if not playing:
		return false
	var dir_error := DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://.local/saves"))
	if dir_error != OK:
		notify("无法创建存档目录，请检查项目所在磁盘是否可写。")
		return false
	var file := FileAccess.open(SAVE + ".tmp", FileAccess.WRITE)
	if file == null:
		notify("保存失败：无法写入磁盘。")
		return false
	# Save on the walkable floor, not in the middle of a fall or dodge.
	var at := Vector3(traveler.position.x, 0.1, traveler.position.z)
	file.store_string(JSON.stringify(progress.snapshot(at)))
	file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error != OK or DirAccess.rename_absolute(ProjectSettings.globalize_path(SAVE + ".tmp"), ProjectSettings.globalize_path(SAVE)) != OK:
		notify("保存失败，已有存档未主动删除。")
		return false
	if feedback:
		notify("旅程已保存到项目的 .local/saves 目录。")
	return true

func continue_game() -> bool:
	if not FileAccess.file_exists(SAVE):
		notify("还没有存档，请先创建角色。")
		return false
	var file := FileAccess.open(SAVE, FileAccess.READ)
	if file == null:
		notify("无法读取存档，请检查文件权限。")
		return false
	var parser := JSON.new()
	if parser.parse(file.get_as_text()) != OK:
		notify("存档格式损坏，未覆盖原文件。")
		return false
	var data: Variant = parser.data
	var loaded = Progress.new()
	if not loaded.restore(data):
		notify("存档损坏或版本不兼容，未覆盖原文件。")
		return false
	var backup := SAVE + ".v%d.bak" % int(data.version)
	if data.version < Progress.VERSION and not FileAccess.file_exists(backup):
		file.close()
		if DirAccess.copy_absolute(ProjectSettings.globalize_path(SAVE), ProjectSettings.globalize_path(backup)) != OK:
			notify("无法备份旧存档，已停止迁移，请检查磁盘权限。")
			return false
	progress = loaded
	start_game(Vector3(float(data.position[0]), float(data.position[1]), float(data.position[2])))
	notify("重返青岚谷。未击败的妖兽会恢复状态。")
	return true

func return_to_title() -> void:
	if save_game(false):
		show_menu()

func on_focus_exited() -> void:
	if playing and not paused:
		paused_for_focus = true
		set_paused(true)
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		notify("窗口失去焦点，已暂停。切回后点击画面继续；F8 可切兼容鼠标。")

func on_focus_entered() -> void:
	if playing and not paused:
		call_deferred("capture_mouse")

func request_exit() -> void:
	if exiting: return
	if playing and not save_game(false):
		set_paused(true)
		var dialog := ConfirmationDialog.new()
		dialog.dialog_text = "保存失败。是否放弃本次未保存的进度并退出？之前的存档会保留。"
		dialog.confirmed.connect(func(): get_tree().quit())
		ui.add_child(dialog)
		dialog.popup_centered()
		return
	exiting = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().quit()

func _notification(what: int) -> void:
	if not is_instance_valid(traveler): return
	if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT: on_focus_exited()
	elif what == NOTIFICATION_WM_WINDOW_FOCUS_IN: on_focus_entered()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST: request_exit()
