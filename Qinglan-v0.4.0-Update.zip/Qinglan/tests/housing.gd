extends SceneTree
const Game = preload("res://scripts/game.gd")
const Progress = preload("res://scripts/progress.gd")
const Interior = preload("res://scripts/home_interior.gd")
var checks := 0
var failures := 0
var capture_dir := ""

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-dir="): capture_dir = arg.trim_prefix("--capture-dir=")
	call_deferred("run")

func frames(count: int) -> void:
	for i in range(count): await physics_frame

func check(ok: bool, description: String) -> void:
	checks += 1
	if ok: print("PASS: " + description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func capture(name: String) -> void:
	if capture_dir.is_empty(): return
	await process_frame
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)

func approach(game: Node3D, kind: String) -> void:
	for point in game.room.points:
		if point.kind == kind:
			game.traveler.position = point.position + Vector3(0, 0.1, 0.5)
			game.traveler.velocity = Vector3.ZERO
			return

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	root.push_input(event, true)

func click_slot(slot: Button) -> void:
	var event := InputEventMouseButton.new()
	event.position = slot.get_global_rect().get_center()
	event.button_index = MOUSE_BUTTON_LEFT
	event.pressed = true
	root.push_input(event, true)
	event = event.duplicate()
	event.pressed = false
	root.push_input(event, true)

func run() -> void:
	var game = Game.new()
	root.add_child(game)
	game.begin_new()
	await frames(3)
	check(not game.room.enter() and not game.progress.inside_home, "unowned home cannot be entered")
	game.progress.claim_home()
	game.progress.learned = true
	game.progress.herb_stock = 8
	game.progress.beast_cores = 4
	game.progress.heal_potions = 2
	game.progress.mana_potions = 3
	game.traveler.position = game.adventure.HOME
	game.interact()
	await frames(5)
	check(game.progress.inside_home and game.room.visible and not game.valley.visible, "owned door switches to separate furnished room")
	check(game.traveler.position.y > 29 and game.room.points.all(func(p): return p.position.y >= 30), "interior and its interactions occupy an isolated space")
	check(not game.adventure.in_combat() and not game.cast_sword(), "interior is safe and outdoor combat cannot target through room")
	var before: Vector3 = game.valley.beast.position
	await frames(30)
	check(game.valley.beast.position == before, "outdoor encounter simulation suspends while indoors")
	await capture("19-home-interior")
	approach(game, "storage")
	game.interact()
	await frames(28)
	check(game.paused and game.room.storage_panel.visible and game.room.lid.rotation.x < -1, "chest lid animates open with interactive inventory")
	check(game.room.chest_slots[0].get_parent().get_child_count() == 18 and game.room.bag_slots[0].get_parent().get_child_count() == 18, "chest and bag each display eighteen slots")
	click_slot(game.room.bag_slots[0])
	await frames(2)
	check(game.progress.herbs() == 7 and game.progress.vault_herbs == 1, "actual slot click deposits one herb")
	click_slot(game.room.chest_slots[0])
	await frames(2)
	check(game.progress.herbs() == 8 and game.progress.vault_herbs == 0, "actual chest slot click withdraws without duplicating herbs")
	for item in ["core", "seed", "heal", "mana"]:
		var total: int = game.progress.item_count(item)
		game.room.transfer(item, true)
		check(game.progress.item_count(item) == total - 1 and game.progress.item_count(item, true) == 1, "grid storage transfers " + item)
	check(not game.progress.transfer_item("coins", true) and not game.progress.transfer_item("core", true, 1000), "unsupported or excessive transfer cannot corrupt inventory")
	var shift := InputEventKey.new()
	shift.keycode = KEY_SHIFT
	shift.pressed = true
	Input.parse_input_event(shift)
	await frames(2)
	click_slot(game.room.bag_slots[0])
	await frames(2)
	check(game.progress.herbs() == 0 and game.progress.vault_herbs == 8, "Shift slot click deposits entire stack")
	click_slot(game.room.chest_slots[0])
	await frames(2)
	check(game.progress.herbs() == 8 and game.progress.vault_herbs == 0, "Shift chest click withdraws entire stack")
	shift.pressed = false
	Input.parse_input_event(shift)
	await frames(2)
	game.progress.transfer_item("herb", true, 3)
	game.room.update_storage()
	await capture("20-chest-grid")
	game.set_paused(false)
	var stock: int = game.progress.herbs()
	game.room.transfer("herb", true)
	await frames(22)
	check(game.progress.herbs() == stock and is_zero_approx(game.room.lid.rotation.x), "closed chest cannot transact and lid closes")
	approach(game, "bed")
	game.progress.hp = 25
	game.interact()
	await frames(60)
	check(game.room.meditating and game.traveler.sit_blend > 0.9 and game.progress.hp == 25, "meditation blends into seated pose before restoring health")
	check(game.traveler.left_leg.rotation.z < -0.5 and game.traveler.right_leg.rotation.z > 0.5 and game.traveler.model.position.y < -0.45, "sitting folds both legs and lowers body onto cushion")
	game.set_paused(true)
	var timer: float = game.room.rest_elapsed
	await frames(20)
	check(game.room.rest_elapsed == timer, "pause suspends meditation progress")
	game.set_paused(false)
	game.interact()
	check(not game.room.meditating and game.progress.hp == 25, "E cancels unfinished rest without free healing")
	game.room.begin_rest()
	Input.action_press("forward")
	await frames(3)
	Input.action_release("forward")
	check(not game.room.meditating and not game.traveler.busy and game.progress.hp == 25, "movement cancels seated rest and returns control without free healing")
	approach(game, "bed")
	game.adventure.cultivate_near_bed()
	await frames(70)
	game.traveler.yaw = -0.65
	game.traveler.pitch = -0.22
	game.traveler.spring.spring_length = 4.8
	await frames(3)
	await capture("21-seated-cultivation")
	game.interact()
	check(game.progress.cultivation == 0 and game.progress.herbs() == stock, "cancelled training spends no herbs or advancement")
	check(game.adventure.cultivate_near_bed(), "G starts cultivation from actual indoor cushion")
	await frames(370)
	check(game.progress.cultivation == 1 and game.progress.herbs() == stock - 2 and game.room.rest_done, "completed animated cultivation pays exact resource cost once")
	await frames(40)
	check(game.progress.cultivation == 1 and game.progress.herbs() == stock - 2, "remaining seated cannot repeatedly award cultivation")
	check(game.save_game(false) and game.continue_game() and game.progress.inside_home and game.traveler.position.y > 29, "save reload restores room location without placing player under outdoor ground")
	check(not game.room.meditating and not game.traveler.busy and game.progress.vault_items.core == 1, "reload keeps stored items and safely ends transient sitting action")
	game.room.leave()
	await frames(5)
	check(not game.progress.inside_home and game.valley.visible and not game.room.visible and game.traveler.position.distance_to(game.adventure.HOME) < 0.4, "exit returns to outdoor yard and restores world")
	game.progress.hp = 36
	game.progress.qi = 28
	game.update_hud()
	await frames(20)
	check(absf(game.hud.hp_bar.value - 36) < 1 and game.hud.qi_bar.value > 28 and game.hud.gold_text.text == str(game.progress.coins), "HUD bars and coin display reflect actual gameplay state")
	await capture("22-vitals-hud")
	var fixture: Dictionary = game.progress.snapshot(Vector3(-25, 0.1, 16))
	fixture.version = 3
	fixture.erase("vault_items")
	fixture.erase("inside_home")
	fixture.vault_herbs = 9
	fixture.coins = 123
	fixture.weapon_level = 2
	fixture.pending_loot = [{"uid": 1, "item": "core", "count": 2, "position": [45, 0.2, 45]}]
	fixture.next_loot_id = 2
	var original := JSON.stringify(fixture)
	var file := FileAccess.open(Game.SAVE, FileAccess.WRITE)
	file.store_string(original)
	file.close()
	check(game.continue_game() and game.progress.coins == 123 and game.progress.vault_herbs == 9 and game.progress.weapon_level == 2 and game.progress.pending_loot.size() == 1, "genuine v3 schema migrates economy, old chest and pending drops")
	check(game.traveler.position.distance_to(game.adventure.HOME) < 0.2, "legacy outdoor home position moves safely outside new closed doorway")
	check(FileAccess.get_file_as_string(Game.SAVE + ".v3.bak") == original, "migration keeps exact v3 save backup")
	var bad: Dictionary = game.progress.snapshot(Vector3.ZERO)
	bad.vault_items.core = -1
	check(not game.progress.restore(bad) and game.progress.coins == 123, "invalid new chest data rejects atomically")
	bad = game.progress.snapshot(Vector3(40, 0.1, 40))
	bad.inside_home = true
	check(not game.progress.restore(bad), "out-of-room indoor position cannot load outside room walls")
	var blocker := Control.new()
	blocker.size = Vector2(1280, 720)
	blocker.mouse_filter = Control.MOUSE_FILTER_STOP
	game.ui.add_child(blocker)
	key(KEY_F10)
	check(game.paused and Input.mouse_mode == Input.MOUSE_MODE_VISIBLE, "F10 releases cursor even when GUI blocks unhandled input")
	key(KEY_ESCAPE)
	check(not game.paused and game.traveler.enabled, "Escape resumes even beneath full-window GUI control")
	game.notification(Node.NOTIFICATION_WM_WINDOW_FOCUS_OUT)
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	click.position = Vector2(600, 400)
	click.pressed = true
	root.push_input(click, true)
	check(not game.paused and not game.paused_for_focus and game.traveler.enabled, "first click after focus loss resumes control before GUI interception")
	key(KEY_F8)
	check(game.compat_mouse and game.traveler.compatibility_mouse, "F8 switches to alternative mouse input path")
	var settings: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://.local/mouse.json"))
	check(settings.compatibility, "mouse compatibility preference persists beside game")
	game.compat_mouse = false
	game.load_mouse_preference()
	check(game.compat_mouse, "reloading preferences restores selected compatibility mode")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
