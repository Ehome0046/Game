#!/usr/bin/env python3
"""Build a portable project ZIP without saves, caches, Git metadata or test data."""
from pathlib import Path
import argparse
import re
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("--with-engine", action="store_true")
parser.add_argument("--update-only", action="store_true", help="Overlay files for an existing portable installation")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
destination = root / "dist"
destination.mkdir(exist_ok=True)
if args.with_engine and args.update_only:
    parser.error("--with-engine and --update-only are mutually exclusive")
suffix = "Windows-Portable" if args.with_engine else ("Update" if args.update_only else "Source")
version = re.search(r'^config/version="([0-9.]+)"$', (root / "project.godot").read_text(encoding="utf-8"), re.MULTILINE)
if not version:
    raise SystemExit("Missing application version in project.godot")
version = version.group(1)
output = destination / f"Qinglan-v{version}-{suffix}.zip"
files = [root / name for name in ["README.md", ".gitignore", "Start-Game.cmd", "project.godot"]]
for folder in ["docs", "scenes", "scripts", "shaders", "tests", "third_party"]:
    files.extend(p for p in (root / folder).rglob("*") if p.is_file())
files.extend([root / "tools/check.py", root / "tools/check_window_input.py", root / "tools/package.py"])
if args.with_engine:
    engine = root / "tools/godot/Godot.exe"
    if not engine.is_file():
        raise SystemExit("Missing tools/godot/Godot.exe; see Windows quickstart")
    for license_name in ["LICENSE.txt", "COPYRIGHT.txt", "ORIGIN.md"]:
        if not (root / "third_party/godot" / license_name).is_file():
            raise SystemExit("Missing Godot license/provenance: " + license_name)
    files.extend([engine, root / "tools/godot/_sc_"])
with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(set(files)):
        content = path.read_bytes()
        if path.suffix == ".cmd":
            content = content.replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")
        archive.writestr("Qinglan/" + path.relative_to(root).as_posix(), content)
    engine_note = ("便携包已附带 Godot 引擎，无需安装。" if args.with_engine else
                   ("这是小更新包，请覆盖原有 Qinglan 文件夹，保留 tools\\godot 和 .local。" if args.update_only else
                    "此为源码包，先按 docs\\windows-quickstart.md 准备便携 Godot 引擎。"))
    archive.writestr("Qinglan/开始前必读.txt", f"""青岚问道 v{version} · 洞府新居（玩法原型）

1. 将整个 Qinglan 文件夹解压到 D:\\GameDev 下，不要放到 C 盘。
2. {engine_note} 双击 Start-Game.cmd 启动。
3. 继续旧存档。自己的洞府门口 E 入室；室内箱子 E 储物，蒲团 E 调息 / G 修炼，门口 E 出门。
4. 箱子显示物品格，点击转移一个，Shift 点击全部。盘坐 4 秒调息、6 秒修炼，E 或移动取消。
5. M 地图可切区域总览，外围有四类十二只刷新妖兽、十二处新灵草。战利品落地，靠近 E 拾取。
6. 野生灵草游玩 45 秒再长，妖兽游玩 60 秒且离开出生点 10 米后重生，暂停与离线不计时。
7. 鼠标即时转镜头，右移向右转，上移抬头；右键恢复锁定，滚轮缩放。F8 切兼容模式，F10 释放指针。
8. 北面残卷 E 学御剑，Q/1/左键攻击，R/2火弹，F/3护体；空格闪避，F5 保存。
9. 这是采用简单占位模型的玩法原型，不是最终写实画面。Windows 本机尚待实测。

鼠标进不去时先 Alt+Tab 选中游戏，点一下画面或右键；F8 切换兼容方式，Esc 继续。暂停页可保存并退出。
村南顾伯接重复委托，沈娘卖补给，陆舟收材料 / 强化。4 养元丹，5 回灵散。WASD 移动。
安家：M 地图、N 洞府引路；村口南侧绕过房屋，向西过桥到无主石室门前按 E。无需先通关遗府。
认领后 H 脱战回府，箱子 E 储物、蒲团 E 调息/G 修炼；灵田 E 播种或收获。
切换窗口时自动暂停，回来后点击继续修行。Tab/Esc 行囊与暂停。

存档：.local\\saves。请不要误删；创建新角色前会询问是否覆盖。
旧存档会自动迁移，原 v1/v2/v3 文件分别备份为 journey.json.v1.bak / .v2.bak / .v3.bak。
本次洞府与鼠标恢复：docs\\update-0.4.md；循环玩法：docs\\update-0.3.md；洞府指引：docs\\update-0.2.2.md；遗府洞府：docs\\update-0.2.md。
""".encode("utf-8-sig"))
    if not archive.testzip() is None:
        raise SystemExit("ZIP CRC check failed")
with zipfile.ZipFile(output) as archive:
    names = archive.namelist()
    if any("/.local/" in n or "/.git/" in n or "/.godot/" in n for n in names):
        raise SystemExit("Unexpected private data or cache in artifact")
    print(f"{output}: {output.stat().st_size / 1024**2:.1f} MiB, {len(names)} files")
