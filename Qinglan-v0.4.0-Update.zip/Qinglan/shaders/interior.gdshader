shader_type spatial;
render_mode diffuse_burley;
uniform vec4 base_color : source_color = vec4(0.24, 0.16, 0.105, 1.0);
uniform bool stone = false;
varying vec3 at;
float rand(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void vertex() { at = VERTEX; }
void fragment() {
 vec2 p = at.xz;
 vec2 cells = floor(p * (stone ? vec2(1.1, 1.1) : vec2(1.5, 0.28)));
 vec2 edge = fract(p * (stone ? vec2(1.1, 1.1) : vec2(1.5, 0.28)));
 float seam = step(0.025, edge.x) * step(0.025, edge.y);
 float grain = sin(p.x * 90.0 + sin(p.y * 2.0) * 3.0) * 0.025;
 ALBEDO = base_color.rgb * (0.8 + rand(cells) * 0.35 + grain) * mix(0.4, 1.0, seam);
 ROUGHNESS = stone ? 0.86 : 0.72;
}
