extends SceneTree
## Input is dispatched through the viewport so GUI interception is exercised.

const Game = preload("res://scripts/game.gd")
var checks := 0
var failures := 0
var capture_dir := ""
var steps := 0

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-dir="):
			capture_dir = arg.trim_prefix("--capture-dir=")
	call_deferred("run")

func check(value: bool, description: String) -> void:
	checks += 1
	if value:
		print("PASS: " + description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func frames(count: int) -> void:
	for i in range(count):
		await physics_frame

func motion(delta: Vector2) -> void:
	var event := InputEventMouseMotion.new()
	event.position = Vector2(640, 360)
	event.relative = delta
	event.screen_relative = delta
	root.push_input(event, true)

func click(button: MouseButton) -> void:
	var event := InputEventMouseButton.new()
	event.position = Vector2(640, 360)
	event.button_index = button
	event.pressed = true
	root.push_input(event, true)
	event = event.duplicate()
	event.pressed = false
	root.push_input(event, true)

func capture(name: String) -> void:
	if capture_dir.is_empty():
		return
	await process_frame
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)

func run() -> void:
	var game = Game.new()
	root.add_child(game)
	game.progress.learned = true
	game.start_game(Vector3(0, 0.1, 18))
	await frames(3)
	var blocker := Control.new()
	blocker.size = Vector2(1280, 720)
	blocker.mouse_filter = Control.MOUSE_FILTER_STOP
	game.ui.add_child(blocker)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var before: float = game.traveler.yaw
	motion(Vector2(40, 15))
	check(not is_equal_approx(before, game.traveler.yaw), "camera responds with released pointer and GUI overlay (v0.2 regression)")
	check(game.traveler.pitch < -0.28, "mouse vertical motion changes camera pitch")
	motion(Vector2(0, 10000))
	check(is_equal_approx(game.traveler.pitch, -0.85), "mouse pitch is clamped")
	for i in range(30):
		click(MOUSE_BUTTON_WHEEL_UP)
	check(is_equal_approx(game.traveler.spring.spring_length, 3.2), "zoom minimum keeps camera outside character")
	for i in range(30):
		click(MOUSE_BUTTON_WHEEL_DOWN)
	check(is_equal_approx(game.traveler.spring.spring_length, 8), "zoom maximum is bounded")
	var center := InputEventKey.new()
	center.keycode = KEY_C
	center.physical_keycode = KEY_C
	center.pressed = true
	root.push_input(center, true)
	check(is_equal_approx(game.traveler.pitch, -0.28) and is_equal_approx(game.traveler.yaw, game.traveler.model.rotation.y), "C recenters view through real input dispatch")
	blocker.queue_free()
	await frames(2)
	before = game.traveler.yaw
	Input.action_press("look_left")
	await frames(15)
	Input.action_release("look_left")
	check(absf(game.traveler.yaw - before) > 0.2, "keyboard camera fallback rotates view")
	game.set_paused(true)
	before = game.traveler.yaw
	motion(Vector2(50, 20))
	check(is_equal_approx(before, game.traveler.yaw), "pause menu prevents mouse look")
	game.set_paused(false)
	game.notification(Node.NOTIFICATION_WM_WINDOW_FOCUS_OUT)
	check(game.paused and paused and not game.traveler.enabled and game.pause_panel.visible, "focus loss pauses world and exposes resume control")
	game.set_paused(false)
	if DisplayServer.get_name() != "headless":
		game.test_mode = false
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		click(MOUSE_BUTTON_RIGHT)
		check(Input.mouse_mode == Input.MOUSE_MODE_CAPTURED, "right click restores native pointer capture")
		game.test_mode = true
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	game.traveler.yaw = 0
	game.traveler.pitch = -0.28
	game.traveler.spring.spring_length = 5.7
	game.traveler.connect("footstep", func(_at: Vector3, _running: bool): steps += 1)
	Input.action_press("forward")
	await frames(30)
	check(game.traveler.gait_blend > 0.8, "walking blends into locomotion pose")
	check(game.traveler.left_arm.rotation.x * game.traveler.right_arm.rotation.x < 0, "walk arms swing in opposition")
	check(absf(game.traveler.left_knee.rotation.x) + absf(game.traveler.right_knee.rotation.x) > 0.1, "walking articulates knees")
	check(steps > 0, "grounded walking emits footsteps")
	await capture("07-walk")
	Input.action_press("run")
	await frames(20)
	check(game.traveler.camera.fov > 64 and game.traveler.torso.rotation.x < -0.05, "running changes posture and camera FOV")
	await capture("08-run")
	Input.action_release("run")
	Input.action_release("forward")
	await frames(60)
	check(game.traveler.gait_blend < 0.01 and absf(game.traveler.left_leg.rotation.x) < 0.02, "stopping settles legs to idle")
	game.traveler.position = Vector3(9, 0.1, -6.5)
	game.traveler.velocity = Vector3.ZERO
	game.traveler.yaw = -1.15
	game.traveler.pitch = -0.2
	game.traveler.spring.spring_length = 4.2
	game.progress.qi = game.progress.max_qi()
	await frames(4)
	check(is_instance_valid(game.effects.orbit) and game.effects.orbit.visible, "learned sword hovers beside character")
	var health: float = game.beast_hp
	check(game.cast_sword(), "sword launches into real combat")
	await frames(6)
	check(game.effects.shots.size() == 1 and game.effects.shots[0].ribbon.get_surface_count() > 0, "flying sword builds visible ribbon trail")
	check(not game.effects.orbit.visible, "hovering sword leaves character during attack")
	check(game.traveler.right_arm.rotation.x < -0.5, "casting raises the character's arm")
	await capture("09-sword-flight")
	game.set_paused(true)
	var age: float = game.effects.shots[0].age
	await frames(12)
	check(game.effects.shots[0].age == age and game.beast_hp == health, "pause freezes projectile visuals and gameplay impact")
	game.set_paused(false)
	await frames(11)
	check(game.beast_hp < health and not game.effects.numbers.is_empty() and not game.effects.sparks.is_empty(), "impact produces damage, floating number and sparks")
	await capture("10-sword-impact")
	await frames(60)
	check(game.effects.shots.is_empty() and game.effects.numbers.is_empty() and game.effects.trails.is_empty(), "finished effects clean up automatically")
	check(game.effects.orbit.visible, "idle hovering sword returns after attack")
	var first_mesh: MeshInstance3D = game.valley.beast.get_child(0)
	check(first_mesh.material_overlay == null, "hit flash restores original enemy material")
	game.cast_sword()
	check(not game.effects.shots.is_empty(), "second cast creates new in-flight effect")
	game.show_menu()
	game.start_game(Vector3(9, 0.1, -6.5))
	await frames(25)
	check(game.beast_hp == 112 and game.effects.shots.is_empty(), "changing journey cancels stale projectile damage")
	game.progress.relic = true
	game.progress.qi = game.progress.max_qi()
	check(game.cast_attack("fire"), "fire effect can be launched")
	await frames(6)
	check(game.effects.shots.size() == 1 and game.effects.shots[0].kind == "fire", "fire has distinct projectile and trail")
	await capture("11-fire-flight")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
