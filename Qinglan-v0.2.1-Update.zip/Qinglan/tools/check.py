#!/usr/bin/env python3
"""Exercise the real scene in a temporary copy; never touch a player's save."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--godot", default="godot")
parser.add_argument("--capture-dir", type=Path, help="Use a real DISPLAY and capture PNGs")
parser.add_argument("--suite", choices=["all", "smoke", "feel"], default="all")
args = parser.parse_args()
source = Path(__file__).resolve().parents[1]
failed = False
for suite in (["smoke", "feel"] if args.suite == "all" else [args.suite]):
    with tempfile.TemporaryDirectory(prefix=f"qinglan-{suite}-") as temporary:
        project = Path(temporary) / "Game"
        shutil.copytree(source, project, ignore=shutil.ignore_patterns(
            ".git", ".godot", ".local", "dist", "__pycache__", "godot"))
        command = [args.godot, "--path", str(project), "--fixed-fps", "60",
                   "--audio-driver", "Dummy", "--log-file", str(Path(temporary) / "run.log"),
                   "--script", f"res://tests/{suite}.gd"]
        if not args.capture_dir:
            command.insert(1, "--headless")
        command.extend(["--", "--test"])
        if args.capture_dir:
            args.capture_dir.mkdir(parents=True, exist_ok=True)
            command.append("--capture-dir=" + str(args.capture_dir.resolve()))
        try:
            result = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, timeout=120, env=os.environ.copy())
        except subprocess.TimeoutExpired as error:
            print(error.stdout.decode() if isinstance(error.stdout, bytes) else error.stdout or "")
            sys.exit(f"Godot {suite} check timed out")
        print(f"--- {suite} ---\n{result.stdout}", flush=True)
        # Godot script-load errors may return zero: require the suite summary too.
        failed |= result.returncode != 0 or "RESULT:" not in result.stdout or any(
            marker in result.stdout for marker in ["SCRIPT ERROR:", "ERROR:", "FAIL:"])
sys.exit(1 if failed else 0)
