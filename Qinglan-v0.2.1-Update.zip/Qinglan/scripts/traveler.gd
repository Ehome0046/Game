extends CharacterBody3D

signal footstep(at: Vector3, running: bool)

var enabled := false
var invincible := 0.0
var dodge_cooldown := 0.0
var dodge_direction := Vector3.FORWARD
var yaw := 0.0
var pitch := -0.28
var motion_time := 0.0
var gait_blend := 0.0
var cast_time := 0.0
var cast_duration := 0.38
var cast_kind := "sword"
var step_clock := 0.0
var model: Node3D
var camera_pivot: Node3D
var camera: Camera3D
var spring: SpringArm3D
var left_leg: Node3D
var right_leg: Node3D
var left_knee: Node3D
var right_knee: Node3D
var left_arm: Node3D
var right_arm: Node3D
var left_elbow: Node3D
var right_elbow: Node3D
var torso: Node3D
var sash: MeshInstance3D
var cloth: StandardMaterial3D

func material(color: String) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color)
	mat.roughness = 0.9
	return mat

func pivot(parent: Node3D, at: Vector3) -> Node3D:
	var node := Node3D.new()
	node.position = at
	parent.add_child(node)
	return node

func part(mesh: Mesh, at: Vector3, mat: Material, parent: Node3D) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = mat
	instance.position = at
	parent.add_child(instance)
	return instance

func capsule(at: Vector3, radius: float, height: float, mat: Material, parent: Node3D) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	mesh.radial_segments = 10
	mesh.rings = 3
	return part(mesh, at, mat, parent)

func box(at: Vector3, size: Vector3, mat: Material, parent: Node3D) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return part(mesh, at, mat, parent)

func _ready() -> void:
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.8
	var collision := CollisionShape3D.new()
	collision.shape = shape
	collision.position.y = 0.9
	add_child(collision)
	model = pivot(self, Vector3.ZERO)
	cloth = material("536a68")
	var dark := material("242e2b")
	var skin := material("c5a68a")
	var trim := material("9a8965")
	torso = pivot(model, Vector3(0, 1.05, 0))
	var robe := CylinderMesh.new()
	robe.top_radius = 0.23
	robe.bottom_radius = 0.29
	robe.height = 0.63
	robe.radial_segments = 16
	part(robe, Vector3(0, 0.13, 0), cloth, torso)
	var skirt := CylinderMesh.new()
	skirt.top_radius = 0.28
	skirt.bottom_radius = 0.34
	skirt.height = 0.5
	skirt.radial_segments = 16
	part(skirt, Vector3(0, -0.39, 0), cloth, torso)
	box(Vector3(0, -0.07, -0.02), Vector3(0.56, 0.075, 0.48), trim, torso)
	sash = box(Vector3(0.19, -0.3, -0.27), Vector3(0.07, 0.4, 0.035), trim, torso)
	box(Vector3(0, 0.27, -0.23), Vector3(0.05, 0.35, 0.035), trim, torso).rotation.z = -0.35
	capsule(Vector3(0, 0.57, 0), 0.16, 0.38, skin, torso)
	var hair := capsule(Vector3(0, 0.69, 0.045), 0.17, 0.24, dark, torso)
	hair.scale.z = 0.95
	capsule(Vector3(0, 0.87, 0.04), 0.085, 0.17, dark, torso)
	box(Vector3(0, 0.61, -0.153), Vector3(0.27, 0.035, 0.025), trim, torso)
	for side in [-1.0, 1.0]:
		box(Vector3(side * 0.065, 0.56, -0.151), Vector3(0.035, 0.025, 0.025), dark, torso)
	capsule(Vector3(0, 0.49, -0.158), 0.035, 0.07, skin, torso)
	var legs: Array[Node3D] = []
	var knees: Array[Node3D] = []
	var arms: Array[Node3D] = []
	var elbows: Array[Node3D] = []
	for side in [-1.0, 1.0]:
		var leg := pivot(model, Vector3(side * 0.15, 0.84, 0))
		capsule(Vector3(0, -0.18, 0), 0.105, 0.4, cloth, leg)
		var knee := pivot(leg, Vector3(0, -0.35, 0))
		capsule(Vector3(0, -0.18, 0), 0.085, 0.38, dark, knee)
		box(Vector3(0, -0.38, -0.045), Vector3(0.18, 0.13, 0.3), dark, knee)
		legs.append(leg)
		knees.append(knee)
		var arm := pivot(torso, Vector3(side * 0.31, 0.28, 0))
		capsule(Vector3(0, -0.16, 0), 0.12, 0.36, cloth, arm)
		var elbow := pivot(arm, Vector3(0, -0.30, 0))
		capsule(Vector3(0, -0.13, 0), 0.09, 0.29, cloth, elbow)
		capsule(Vector3(0, -0.29, 0), 0.065, 0.14, skin, elbow)
		arms.append(arm)
		elbows.append(elbow)
	left_leg = legs[0]
	right_leg = legs[1]
	left_knee = knees[0]
	right_knee = knees[1]
	left_arm = arms[0]
	right_arm = arms[1]
	left_elbow = elbows[0]
	right_elbow = elbows[1]
	camera_pivot = pivot(self, Vector3(0, 1.4, 0))
	camera_pivot.rotation = Vector3(pitch, yaw, 0)
	spring = SpringArm3D.new()
	spring.spring_length = 5.7
	spring.margin = 0.25
	spring.add_excluded_object(get_rid())
	camera_pivot.add_child(spring)
	camera = Camera3D.new()
	camera.fov = 62
	camera.near = 0.1
	spring.add_child(camera)
	camera.current = true

func set_robe(index: int) -> void:
	cloth.albedo_color = [Color("536a68"), Color("344c3e"), Color("78534b")][index]

func reset_camera() -> void:
	yaw = model.rotation.y
	pitch = -0.28

func play_cast(kind: String) -> void:
	cast_kind = kind
	cast_duration = 0.5 if kind == "fire" else 0.38
	cast_time = cast_duration

func _input(event: InputEvent) -> void:
	if not enabled:
		return
	# Handle look before GUI controls; paused/title screens disable this node.
	# Motion also works inside the window if the OS has released pointer capture.
	if event is InputEventMouseMotion:
		var motion: Vector2 = event.screen_relative if event.screen_relative != Vector2.ZERO else event.relative
		yaw = wrapf(yaw - motion.x * 0.003, -PI, PI)
		pitch = clampf(pitch - motion.y * 0.003, -0.85, 0.4)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP or event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			var amount := -0.5 if event.button_index == MOUSE_BUTTON_WHEEL_UP else 0.5
			spring.spring_length = clampf(spring.spring_length + amount, 3.2, 8.0)
			get_viewport().set_input_as_handled()
	elif event.is_action_pressed("center_camera"):
		reset_camera()
		get_viewport().set_input_as_handled()

func _physics_process(delta: float) -> void:
	invincible = maxf(0, invincible - delta)
	dodge_cooldown = maxf(0, dodge_cooldown - delta)
	var direction := Vector3.ZERO
	if enabled:
		yaw = wrapf(yaw + Input.get_axis("look_right", "look_left") * delta * 1.9, -PI, PI)
		pitch = clampf(pitch + Input.get_axis("look_down", "look_up") * delta * 1.2, -0.85, 0.4)
		var axis := Input.get_vector("left", "right", "forward", "back")
		direction = Vector3(axis.x, 0, axis.y).rotated(Vector3.UP, yaw)
		if Input.is_action_just_pressed("dodge") and dodge_cooldown == 0:
			dodge_direction = direction if direction.length() > 0.1 else -camera.global_basis.z * Vector3(1, 0, 1)
			dodge_direction = dodge_direction.normalized()
			invincible = 0.35
			dodge_cooldown = 1.1
	var running := enabled and Input.is_action_pressed("run")
	var speed := 6.8 if running else 4.0
	if enabled and invincible > 0:
		direction = dodge_direction
		speed = 11.0
	velocity.x = direction.x * speed
	velocity.z = direction.z * speed
	velocity.y = maxf(velocity.y - 20 * delta, -25)
	var previous := position
	move_and_slide()
	position.x = clampf(position.x, -35.0, 35.0)
	position.z = clampf(position.z, -35.0, 35.0)
	var moved := Vector2(position.x - previous.x, position.z - previous.z).length() / maxf(delta, 0.001)
	if direction.length_squared() > 0.01:
		model.rotation.y = lerp_angle(model.rotation.y, atan2(-direction.x, -direction.z), 1 - exp(-delta * 12))
	animate(delta, moved, running)
	camera_pivot.rotation.x = lerpf(camera_pivot.rotation.x, pitch, 1 - exp(-delta * 18))
	camera_pivot.rotation.y = lerp_angle(camera_pivot.rotation.y, yaw, 1 - exp(-delta * 18))
	camera.fov = lerpf(camera.fov, 67 if running and moved > 0.5 else 62, delta * 5)

func animate(delta: float, speed: float, running: bool) -> void:
	gait_blend = lerpf(gait_blend, clampf(speed / 4.0, 0, 1), 1 - exp(-delta * 12))
	motion_time += delta * (5 + minf(speed, 7))
	cast_time = maxf(0, cast_time - delta)
	var pose := sin((1 - cast_time / cast_duration) * PI) if cast_time > 0 else 0.0
	var wave := sin(motion_time)
	var stride := (0.85 if running else 0.56) * gait_blend
	left_leg.rotation.x = wave * stride
	right_leg.rotation.x = -wave * stride
	left_knee.rotation.x = -maxf(0, -wave) * stride * 1.2 - 0.04
	right_knee.rotation.x = -maxf(0, wave) * stride * 1.2 - 0.04
	left_arm.rotation = Vector3(-wave * stride * 0.8 - pose * 0.35, 0, -0.10)
	right_arm.rotation = Vector3(wave * stride * 0.8 - pose * 1.45, 0, 0.10 + pose * 0.18)
	left_elbow.rotation.x = -0.15 - (0.35 if running else 0.1) * gait_blend
	right_elbow.rotation.x = -0.15 - (0.35 if running else 0.1) * gait_blend - pose * 0.45
	torso.rotation.x = -(0.10 if running else 0.025) * gait_blend + pose * 0.07
	torso.rotation.z = sin(motion_time) * 0.025 * gait_blend
	sash.rotation.x = -wave * 0.14 * gait_blend
	model.position.y = absf(cos(motion_time)) * 0.025 * gait_blend + sin(motion_time * 0.24) * 0.004
	if invincible > 0:
		torso.rotation.x -= 0.35
		left_knee.rotation.x -= 0.45
		right_knee.rotation.x -= 0.45
	if speed > 0.5 and is_on_floor() and invincible == 0:
		step_clock += delta
		if step_clock >= (0.28 if running else 0.40):
			step_clock = 0
			footstep.emit(global_position + Vector3(0, 0.04, 0), running)
	else:
		step_clock = 0
