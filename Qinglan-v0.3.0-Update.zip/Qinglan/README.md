# 青岚问道 v0.3.0 · 坊市与外域

原创角色、单人第三人称 3D 修仙玩法原型。长期方向为写实国风；当前使用自制几何占位模型，不代表最终画质。保留角色创建、御剑、突破、遗府、洞府、灵田与存档；新增金币、三名 NPC、药材铺、飞剑强化、三类重复委托，以及四片外域中的十二只可刷新妖兽。

现在可以循环游玩：接采药 / 猎妖 / 勘察委托 → 到外域采集和战斗 → 按 E 拾取实体兽丹、金币和草药 → 回坊市交付、出售、购买补给或强化 → 再次出门。野生灵草在游玩 45 秒后再长，妖兽在游玩 60 秒后、玩家离开刷新点时重生。暂停和离线不计时。

- [Windows 试玩与非 C 盘路径说明](docs/windows-quickstart.md)
- [v0.3.0 循环玩法、坊市与鼠标镜头](docs/update-0.3.md)
- [v0.2 更新、旧存档与新增玩法](docs/update-0.2.md)
- [v0.2.1 镜头修复、人物动作与特效](docs/update-0.2.1.md)
- [v0.2.2 洞府认领路线、地图与引路](docs/update-0.2.2.md)
- [玩法与美术方向](docs/game-vision.md)

使用 Godot **4.6.3 标准版**，无需 .NET 或第三方插件。打开 `project.godot`，或在项目根目录运行：

```sh
godot --path . --log-file .local/logs/game.log
```

Windows 便携包请解压到 D/E 盘后运行 `Start-Game.cmd`。当前为源码工程加便携引擎，不是正式发行版。存档位于项目内 `.local/saves`，重新解压更新时请保留。

开发检查（Python 3 + Godot；在临时项目内运行，不触碰玩家存档）：

```sh
python3 tools/check.py
# 在有 X11 显示服务的 Linux 环境中验证渲染并截图：
python3 tools/check.py --capture-dir /tmp/qinglan-captures
```

按键：WASD 移动，鼠标即时转镜头，右键锁定，滚轮缩放，Shift 奔跑，空格闪避，E 交互 / 拾取，Q/1/左键御剑，R/2 火弹，F/3 护体，4 养元丹，5 回灵散，M 地图（可切区域总览），N 洞府引路，H 脱战回府，G 蒲团修炼，Tab/Esc 暂停，F5 保存。镜头仅由鼠标控制，右移向右转，上移抬头。切换窗口会自动暂停。洞府开局即可步行认领，无需先通关遗府。

打包：`python3 tools/package.py --with-engine` 生成完整便携包；`--update-only` 生成不含引擎的小更新包。原始 v0.1 ZIP 不会被覆盖。
