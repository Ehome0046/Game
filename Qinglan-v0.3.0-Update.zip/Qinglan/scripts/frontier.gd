extends Node3D
## Renewable encounters, gatherable plants and saved physical loot.

const Rules = preload("res://scripts/world_rules.gd")
var game: Node3D
var enemies: Array[Dictionary] = []
var herbs: Array[Dictionary] = []
var loot_nodes := {}
var refresh := 0.0
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	rng.seed = 3019
	build_regions()
	for i in range(Rules.FIELD_IDS.size()):
		build_enemy(Rules.FIELD_IDS[i], Rules.FIELD_SPAWNS[i], i / 3)
	var plants := [Vector3(-39, 0, 35), Vector3(-53, 0, 41), Vector3(-62, 0, 64),
		Vector3(35, 0, 37), Vector3(48, 0, 64), Vector3(67, 0, 60),
		Vector3(-36, 0, -37), Vector3(-61, 0, -39), Vector3(-68, 0, -65),
		Vector3(39, 0, -42), Vector3(66, 0, -25), Vector3(72, 0, -65)]
	for i in range(plants.size()):
		build_herb(i, plants[i])
	game.valley.box(Rules.SURVEY + Vector3.UP * 0.8, Vector3(1.2, 1.6, 0.5), game.valley.stone, true)
	game.valley.sign_text("石谷界碑 · E 勘察", Rules.SURVEY + Vector3.UP * 2.2, 25)
	game.valley.interactions.append({"kind": "survey", "id": -1, "position": Rules.SURVEY, "label": "勘察石谷界碑"})

func build_regions() -> void:
	var v = game.valley
	for zone in [{"at": Vector3(-49, 0, 49), "name": "南坡林地 · 狼群出没", "color": "526342"},
		{"at": Vector3(-49, 0, -50), "name": "西北瘴泽 · 留意毒弹", "color": "465d48"},
		{"at": Vector3(55, 0, -48), "name": "东北石谷 · 石妖徘徊", "color": "77786d"},
		{"at": Vector3(51, 0, 52), "name": "东南兽径 · 厚皮山豕", "color": "737054"}]:
		v.box(zone.at + Vector3(0, 0.015, 0), Vector3(30, 0.025, 30), v.material(zone.color))
		v.sign_text(zone.name, zone.at + Vector3.UP * 4.0, 30)
	for i in range(55):
		var at := Vector3(rng.randf_range(-73, 73), 0, rng.randf_range(-73, 73))
		if absf(at.x) < 35 and absf(at.z) < 35:
			continue
		if Rules.FIELD_SPAWNS.any(func(point): return point.distance_to(at) < 5):
			continue
		if absf(at.x + 19) < 3:
			continue
		if at.x < 0:
			v.pine(at, rng.randf_range(0.8, 1.3))
		else:
			var rock := SphereMesh.new()
			rock.radius = rng.randf_range(1, 2.5)
			rock.height = rock.radius * 1.4
			rock.radial_segments = 8
			rock.rings = 5
			v.mesh_at(rock, at, v.stone)
	for at in [Vector3(-24, 0, 37), Vector3(27, 0, 37), Vector3(-30, 0, -35), Vector3(36, 0, -12)]:
		v.sign_text("外域猎场 · M 查看区域总览", at + Vector3.UP * 2.4, 25)

func build_enemy(id: String, at: Vector3, species: int) -> void:
	var v = game.valley
	var body := CharacterBody3D.new()
	body.collision_layer = 2
	body.collision_mask = 1
	add_child(body)
	body.position = at
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.5
	capsule.height = 1.4
	shape.shape = capsule
	shape.position.y = 0.7
	body.add_child(shape)
	var model := Node3D.new()
	body.add_child(model)
	var colors := ["6d7469", "736152", "697f4e", "797e79"]
	var mat: StandardMaterial3D = v.material(colors[species])
	var titles := ["灰鬃妖狼", "赤牙山豕", "瘴泽毒蛛", "青岩石妖"]
	var health: float = [75.0, 110.0, 85.0, 150.0][species]
	if species == 3:
		v.box(Vector3(0, 1.0, 0), Vector3(1.25, 1.4, 0.9), mat, false, model)
		v.box(Vector3(0, 1.9, 0), Vector3(0.7, 0.6, 0.7), mat, false, model)
		for side in [-1.0, 1.0]:
			v.box(Vector3(side * 0.85, 1, 0), Vector3(0.4, 1.3, 0.5), mat, false, model)
			v.box(Vector3(side * 0.35, 0.25, 0), Vector3(0.4, 0.5, 0.5), mat, false, model)
	else:
		var sphere := SphereMesh.new()
		sphere.radius = 0.65
		sphere.height = 0.85
		sphere.radial_segments = 12
		sphere.rings = 6
		var torso: MeshInstance3D = v.mesh_at(sphere, Vector3(0, 0.7, 0), mat, model)
		torso.scale = Vector3(0.8, 1, 1.4 if species != 2 else 1)
		if species != 2:
			var head: MeshInstance3D = v.mesh_at(sphere, Vector3(0, 0.85, -0.85), mat, model)
			head.scale = Vector3(0.6, 0.7, 0.6)
		for side in [-1.0, 1.0]:
			for j in range(3 if species == 2 else 2):
				var leg: MeshInstance3D = v.box(Vector3(side * (0.7 if species == 2 else 0.4), 0.3, (j - 0.5) * 0.65),
					Vector3(0.9, 0.12, 0.12) if species == 2 else Vector3(0.18, 0.6, 0.2), mat, false, model)
				leg.rotation.z = side * 0.25 if species == 2 else 0
			v.cylinder(Vector3(side * 0.3, 1.15, -0.9), 0, 0.1, 0.45 if species == 0 else 0.25, v.stone, model)
	var warning_mesh := TorusMesh.new()
	warning_mesh.inner_radius = 1.5 if species == 2 else 2.9
	warning_mesh.outer_radius = warning_mesh.inner_radius + 0.1
	var warning: MeshInstance3D = v.mesh_at(warning_mesh, at + Vector3.UP * 0.13, v.material("cb9e65", true))
	warning.hide()
	var label: Label3D = v.sign_text(titles[species], at + Vector3.UP * 2.6, 23)
	enemies.append({"id": id, "node": body, "model": model, "origin": at, "hp": health, "max_hp": health,
		"species": species, "title": titles[species], "cooldown": 1.8, "windup": -1.0, "mark": at,
		"warning": warning, "label": label})

func build_herb(id: int, at: Vector3) -> void:
	var v = game.valley
	var node := Node3D.new()
	add_child(node)
	node.position = at
	v.cylinder(Vector3.UP * 0.45, 0.035, 0.06, 0.9, v.leaf, node)
	for i in range(5):
		var leaf: MeshInstance3D = v.box(Vector3.UP * (0.18 + i * 0.13), Vector3(0.75, 0.05, 0.2), v.material("85ad79"), false, node)
		leaf.rotation = Vector3(0, i * 1.1, 0.25)
	v.cylinder(Vector3.UP * 0.95, 0.12, 0.06, 0.2, v.material("c7cda3", true), node)
	var label: Label3D = v.sign_text("野生灵草 · E 采集", at + Vector3.UP * 1.7, 22)
	herbs.append({"id": id, "node": node, "label": label, "position": at})
	game.valley.interactions.append({"kind": "wild_herb", "id": id, "position": at, "label": "采集野生灵草"})

func available(point: Dictionary) -> bool:
	if point.kind == "loot":
		return game.progress.pending_loot.any(func(item): return int(item.uid) == point.id)
	if point.kind in ["herb", "wild_herb"]:
		var key := ("legacy_" if point.kind == "herb" else "field_") + str(point.id)
		return float(game.progress.herb_ready.get(key, -1)) <= game.progress.world_time
	return true

func harvest(point: Dictionary) -> bool:
	if not available(point):
		return false
	var p = game.progress
	if point.kind == "herb" and point.id not in p.collected:
		p.gather(point.id)
	else:
		p.herb_stock += 1
	var key := ("legacy_" if point.kind == "herb" else "field_") + str(point.id)
	p.herb_ready[key] = p.world_time + Rules.HERB_REGROW
	sync_resources()
	game.notify("采得一株实体灵草。此处会在游玩 45 秒后重新生长，可出售或交委托。")
	return true

func drop(at: Vector3, items: Array) -> void:
	for i in range(items.size()):
		var position := at + Vector3((i - (items.size() - 1) * 0.5) * 0.8, 0, 0.4)
		position.x = clampf(position.x, -77, 77)
		position.z = clampf(position.z, -77, 77)
		game.progress.add_loot(items[i].item, items[i].count, position)
	sync_loot()

func make_loot(record: Dictionary) -> Node3D:
	var v = game.valley
	var body := Node3D.new()
	add_child(body)
	body.position = Vector3(record.position[0], 0.25, record.position[2])
	if record.item == "core":
		var orb := SphereMesh.new()
		orb.radius = 0.19
		orb.height = 0.38
		orb.radial_segments = 8
		orb.rings = 4
		v.mesh_at(orb, Vector3.UP * 0.17, v.material("a4cfbf", true), body)
		var band := TorusMesh.new()
		band.inner_radius = 0.2
		band.outer_radius = 0.23
		v.mesh_at(band, Vector3.UP * 0.17, v.material("c3aa78"), body).rotation.x = 0.5
	elif record.item == "herb":
		for i in range(3):
			var leaf: MeshInstance3D = v.box(Vector3(0, i * 0.08, 0), Vector3(0.5, 0.05, 0.16), v.material("8cae75"), false, body)
			leaf.rotation.y = i * 0.9
		v.box(Vector3(0, 0.06, 0), Vector3(0.07, 0.3, 0.3), v.material("b6a17c"), false, body)
	else:
		for i in range(3):
			v.cylinder(Vector3(i * 0.09, i * 0.055, 0), 0.12, 0.12, 0.04, v.material("d8b66d", true), body)
	var label := Label3D.new()
	label.position.y = 0.85
	label.font_size = 24
	label.pixel_size = 0.008
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.outline_size = 5
	label.name = "LootLabel"
	body.add_child(label)
	return body

func sync_loot() -> void:
	var p = game.progress
	game.valley.interactions = game.valley.interactions.filter(func(point): return point.kind != "loot")
	var ids := []
	for record in p.pending_loot:
		var id := int(record.uid)
		ids.append(id)
		if not loot_nodes.has(id):
			loot_nodes[id] = make_loot(record)
		var title: String = {"core": "兽丹", "herb": "灵草", "coins": "金币"}[record.item]
		loot_nodes[id].get_node("LootLabel").text = "%s × %d · E 拾取" % [title, record.count]
		game.valley.interactions.append({"kind": "loot", "id": id, "position": Vector3(record.position[0], 0.2, record.position[2]), "label": "拾取 %s × %d" % [title, record.count]})
	for id in loot_nodes.keys():
		if id not in ids:
			loot_nodes[id].queue_free()
			loot_nodes.erase(id)

func pickup(id: int) -> bool:
	for record in game.progress.pending_loot:
		if int(record.uid) != id:
			continue
		var at := Vector3(record.position[0], 0.2, record.position[2])
		if game.traveler.position.distance_to(at) >= 2.7:
			return false
		if game.progress.pickup_loot(id):
			sync_loot()
			game.notify("战利品已收入行囊。金币、灵草与兽丹可用于坊市和委托。")
			return true
	return false

func dead(enemy: Dictionary) -> bool:
	return game.progress.monster_ready.has(enemy.id)

func sync_resources() -> void:
	for point in game.valley.interactions:
		if point.kind == "herb":
			point.node.visible = available(point)
			point.label_node.visible = available(point)
	for plant in herbs:
		var active: bool = float(game.progress.herb_ready.get("field_%d" % plant.id, -1)) <= game.progress.world_time
		plant.node.visible = active
		plant.label.visible = active

func reset_encounters() -> void:
	for enemy in enemies:
		enemy.hp = enemy.max_hp
		enemy.node.position = enemy.origin
		enemy.node.velocity = Vector3.ZERO
		enemy.cooldown = 1.8
		enemy.windup = -1.0
		enemy.warning.hide()
		enemy.node.visible = not dead(enemy)
		enemy.node.collision_layer = 0 if dead(enemy) else 2
		enemy.label.visible = not dead(enemy)

func reset() -> void:
	for node in loot_nodes.values():
		node.queue_free()
	loot_nodes.clear()
	reset_encounters()
	sync_resources()
	sync_loot()

func _process(delta: float) -> void:
	if not game.playing or game.paused:
		return
	refresh -= delta
	if refresh <= 0:
		refresh = 0.5
		sync_resources()
	for record in game.progress.pending_loot:
		if loot_nodes.has(int(record.uid)):
			var body: Node3D = loot_nodes[int(record.uid)]
			body.position.y = 0.25 + sin(game.progress.world_time * 2 + record.uid) * 0.06
			body.rotation.y += delta * 0.6
			body.visible = game.traveler.position.distance_to(body.position) < 45

func _physics_process(delta: float) -> void:
	if not game.playing or game.paused:
		return
	for enemy in enemies:
		if dead(enemy):
			if game.progress.world_time >= game.progress.monster_ready[enemy.id] and game.traveler.position.distance_to(enemy.origin) > 10:
				game.progress.monster_ready.erase(enemy.id)
				enemy.hp = enemy.max_hp
				enemy.node.position = enemy.origin
				enemy.node.visible = true
				enemy.node.collision_layer = 2
				enemy.label.show()
				enemy.cooldown = 2
			continue
		update_enemy(enemy, delta)

func update_enemy(enemy: Dictionary, delta: float) -> void:
	var body: CharacterBody3D = enemy.node
	var offset: Vector3 = game.traveler.position - body.position
	offset.y = 0
	var distance := offset.length()
	enemy.cooldown -= delta
	body.velocity = Vector3.ZERO
	if distance > 20 or body.position.distance_to(enemy.origin) > 22:
		enemy.windup = -1
		enemy.warning.hide()
		enemy.hp = enemy.max_hp
		body.velocity = (enemy.origin - body.position).normalized() * 2
	elif enemy.windup >= 0:
		enemy.windup -= delta
		if enemy.windup < 0:
			enemy.warning.hide()
			attack(enemy)
	elif distance < 13:
		var ranged: bool = enemy.species == 2
		if enemy.cooldown <= 0 and (distance < 11 if ranged else distance < 2.5):
			enemy.windup = 0.9 if ranged else 0.65
			enemy.cooldown = 2.4
			enemy.mark = game.traveler.position if ranged else body.position
			enemy.warning.position = Vector3(enemy.mark.x, 0.15, enemy.mark.z)
			enemy.warning.show()
		elif distance > (7 if ranged else 1.8):
			body.velocity = offset.normalized() * (2.8 if enemy.species == 0 else 2.1)
	else:
		var patrol: Vector3 = enemy.origin + Vector3(sin(game.progress.world_time * 0.3 + enemy.origin.x), 0, cos(game.progress.world_time * 0.3)) * 1.8
		body.velocity = (patrol - body.position).normalized() * 0.65
	body.velocity.y = -8
	body.move_and_slide()
	body.position.x = clampf(body.position.x, -77, 77)
	body.position.z = clampf(body.position.z, -77, 77)
	if offset.length_squared() > 0.01 and distance < 14:
		body.rotation.y = atan2(-offset.x, -offset.z)
	enemy.model.scale.y = 1 + sin(game.progress.world_time * 3 + enemy.origin.x) * 0.015
	enemy.label.position = body.position + Vector3.UP * 2.6
	enemy.label.visible = distance < 28
	enemy.model.visible = distance < 70
	enemy.label.text = "%s %d / %d" % [enemy.title, roundi(enemy.hp), roundi(enemy.max_hp)]

func attack(enemy: Dictionary) -> void:
	if enemy.species != 2:
		if game.traveler.position.distance_to(enemy.node.position) < 3.1:
			game.take_damage(22 if enemy.species in [1, 3] else 15)
		return
	var target: Vector3 = enemy.mark
	var sphere := SphereMesh.new()
	sphere.radius = 0.16
	sphere.height = 0.32
	var shot: MeshInstance3D = game.valley.mesh_at(sphere, enemy.node.position + Vector3.UP, game.valley.material("abc16e", true))
	var generation: int = game.journey_generation
	var tween := create_tween()
	tween.tween_property(shot, "position", target + Vector3.UP * 0.6, 0.4)
	tween.tween_callback(func():
		shot.queue_free()
		if game.playing and game.journey_generation == generation and not dead(enemy) and game.traveler.position.distance_to(target) < 1.7:
			game.take_damage(16)
	)

func hit(id: String, damage: float) -> void:
	for enemy in enemies:
		if enemy.id != id or dead(enemy):
			continue
		enemy.hp = maxf(0, enemy.hp - damage)
		if enemy.hp == 0:
			game.progress.monster_ready[id] = game.progress.world_time + Rules.MONSTER_RESPAWN
			enemy.node.hide()
			enemy.node.collision_layer = 0
			enemy.label.hide()
			enemy.warning.hide()
			var items := [{"item": "core", "count": 1}, {"item": "coins", "count": 8 + enemy.species * 3}]
			if enemy.species == 2:
				items.append({"item": "herb", "count": 1})
			drop(enemy.node.position, items)
			game.notify("%s已败，战利品落在地上，靠近按 E 拾取。离开后 60 秒可刷新。" % enemy.title)
			game.save_game(false)

func in_combat() -> bool:
	return enemies.any(func(enemy): return not dead(enemy) and game.traveler.position.distance_to(enemy.node.position) < 14)
