extends Node3D
## Original procedural blockout assets; no downloaded artwork or IP assets.

var interactions: Array[Dictionary] = []
var beast: Node3D
var beast_origin := Vector3(13, 0, -8)
var altar := Vector3(0, 0, 9)
var scroll := Vector3(0, 0, -23)
var rng := RandomNumberGenerator.new()
var wood: StandardMaterial3D
var stone: StandardMaterial3D
var leaf: StandardMaterial3D

func material(color: String, emission := false) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(color)
	mat.roughness = 0.9
	if emission:
		mat.emission_enabled = true
		mat.emission = mat.albedo_color
		mat.emission_energy_multiplier = 1.3
	return mat

func mesh_at(mesh: Mesh, at: Vector3, mat: Material, parent: Node3D = self) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.position = at
	instance.material_override = mat
	parent.add_child(instance)
	return instance

func box(at: Vector3, size: Vector3, mat: Material, solid := false, parent: Node3D = self) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var result := mesh_at(mesh, at, mat, parent)
	if solid:
		var body := StaticBody3D.new()
		var shape := CollisionShape3D.new()
		var volume := BoxShape3D.new()
		volume.size = size
		shape.shape = volume
		body.add_child(shape)
		result.add_child(body)
	return result

func cylinder(at: Vector3, top: float, bottom: float, height: float, mat: Material, parent: Node3D = self) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top
	mesh.bottom_radius = bottom
	mesh.height = height
	mesh.radial_segments = 10
	return mesh_at(mesh, at, mat, parent)

func sign_text(text: String, at: Vector3, size := 32, color := Color("e4e4ca")) -> Label3D:
	var label := Label3D.new()
	label.text = text
	label.position = at
	label.font_size = size
	label.pixel_size = 0.005
	label.visibility_range_begin = 3.0
	label.visibility_range_end = 36.0
	label.modulate = color
	label.outline_size = 6
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = false
	add_child(label)
	return label

func _ready() -> void:
	rng.seed = 1836
	wood = material("574a39")
	stone = material("67706a")
	leaf = material("344e40")
	var env := WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	env.environment.background_color = Color("92a6a0")
	env.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color = Color("b0c0b9")
	env.environment.ambient_light_energy = 0.3
	env.environment.tonemap_mode = Environment.TONE_MAPPER_LINEAR
	env.environment.fog_enabled = true
	env.environment.fog_light_color = Color("94aaa3")
	env.environment.fog_density = 0.009
	env.environment.fog_light_energy = 0.6
	add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-42, -30, 0)
	sun.light_color = Color("fff0cf")
	sun.light_energy = 0.75
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 50
	add_child(sun)
	var earth := ShaderMaterial.new()
	earth.shader = preload("res://shaders/earth.gdshader")
	box(Vector3(0, -0.3, 0), Vector3(164, 0.6, 164), earth, true)
	box(Vector3(0, 0.014, -2), Vector3(3.4, 0.025, 58), material("858475"))
	for i in range(36):
		var at := Vector3(rng.randf_range(-1.2, 1.2), 0.035, 22 - i * 1.4)
		var slab := box(at, Vector3(rng.randf_range(0.5, 1.1), 0.05, 0.7), stone)
		slab.rotation.y = rng.randf_range(-0.25, 0.25)
	# A decorative shallow stream, kept away from the main traversal corridor.
	box(Vector3(-19, 0.025, -1), Vector3(3.5, 0.035, 157), material("4d7774"))
	for i in range(24):
		var angle: float = float(i) / 24 * TAU
		var at := Vector3(sin(angle) * rng.randf_range(150, 180), 0, cos(angle) * rng.randf_range(150, 180))
		var mountain := cylinder(at + Vector3.UP * 10, 1.1, rng.randf_range(9, 16), rng.randf_range(21, 36), material("536c62"))
		mountain.rotation.z = rng.randf_range(-0.15, 0.15)
	for i in range(65):
		var at := Vector3(rng.randf_range(-36, 36), 0, rng.randf_range(-36, 29))
		if absf(at.x) < 6 or at.distance_to(beast_origin) < 6:
			continue
		if absf(at.x + 19) < 2.6:
			continue
		if (at.x > 14 and at.z < 0) or (at.x < -19 and at.z > 4):
			continue
		pine(at, rng.randf_range(0.8, 1.7))
	for i in range(32):
		var at := Vector3(rng.randf_range(-32, 32), 0, rng.randf_range(-32, 28))
		if absf(at.x) < 4 or at.distance_to(beast_origin) < 5:
			continue
		if (at.x > 14 and at.z < 0) or (at.x < -19 and at.z > 4):
			continue
		var rock := SphereMesh.new()
		rock.radius = rng.randf_range(0.5, 1.4)
		rock.height = rock.radius * 1.4
		rock.radial_segments = 9
		rock.rings = 5
		var instance := mesh_at(rock, at + Vector3.UP * 0.3, stone)
		instance.rotation = Vector3(0.1, rng.randf_range(0, TAU), 0.25)
	# Solid borders keep saves and traversal inside the playable valley.
	for edge in [-1.0, 1.0]:
		var wall := box(Vector3(edge * 80, 4, 0), Vector3(1, 8, 162), stone, true)
		wall.visible = false
		wall = box(Vector3(0, 4, edge * 80), Vector3(162, 8, 1), stone, true)
		wall.visible = false
	house(Vector3(-7, 0, 18))
	house(Vector3(8, 0, 22))
	for x in [-2.7, 2.7]:
		box(Vector3(x, 1.8, 14), Vector3(0.3, 3.6, 0.4), wood, true)
	box(Vector3(0, 3.35, 14), Vector3(6.4, 0.3, 0.6), wood)
	sign_text("青 岚 谷", Vector3(0, 3.1, 14), 40)
	# Cave facade has a passable opening; the scroll is in front of the rear wall.
	for x in [-3.2, 3.2]:
		box(Vector3(x, 2.2, -25), Vector3(2.3, 4.4, 4), stone, true)
	box(Vector3(0, 4.4, -25), Vector3(8.8, 1.3, 4), stone, true)
	box(Vector3(0, 2.0, -27), Vector3(8.8, 4, 0.6), material("303f3c"), true)
	box(scroll + Vector3(0, 0.65, 0), Vector3(1.4, 1.3, 0.8), stone, true)
	var page := box(scroll + Vector3(0, 1.34, 0), Vector3(0.7, 0.04, 0.45), material("d3bf8d", true))
	interactions.append({"kind": "scroll", "id": -1, "position": scroll, "node": page})
	sign_text("遗世洞府 · 残卷", scroll + Vector3(0, 3.5, 0))
	cylinder(altar + Vector3(0, 0.08, 0), 2.4, 2.4, 0.15, stone)
	var ring := TorusMesh.new()
	ring.inner_radius = 1.8
	ring.outer_radius = 1.87
	mesh_at(ring, altar + Vector3(0, 0.18, 0), material("b6c9a3", true))
	interactions.append({"kind": "altar", "id": -1, "position": altar, "node": self})
	sign_text("静 心 台", altar + Vector3(0, 1.5, 0), 28)
	var locations := [Vector3(-7, 0, 5), Vector3(-9, 0, -4), Vector3(6, 0, -13), Vector3(9, 0, 2), Vector3(-5, 0, -17)]
	for i in range(locations.size()):
		var herb := Node3D.new()
		add_child(herb)
		herb.position = locations[i]
		cylinder(Vector3(0, 0.35, 0), 0.03, 0.05, 0.7, leaf, herb)
		for j in range(4):
			var sprig := box(Vector3(0, 0.25 + j * 0.12, 0), Vector3(0.55, 0.04, 0.15), material("88b59a"), false, herb)
			sprig.rotation = Vector3(0, j * 1.2, 0.3)
		cylinder(Vector3(0, 0.8, 0), 0.10, 0.07, 0.18, material("d7ddb0", true), herb)
		var herb_label := sign_text("灵草", locations[i] + Vector3.UP * 1.6, 22, Color("b7d7b6"))
		interactions.append({"kind": "herb", "id": i, "position": locations[i], "node": herb, "label_node": herb_label})
	beast = Node3D.new()
	add_child(beast)
	beast.position = beast_origin
	var body := SphereMesh.new()
	body.radius = 0.8
	body.height = 1.2
	var hide := material("595246")
	var torso := mesh_at(body, Vector3(0, 0.85, 0), hide, beast)
	torso.scale = Vector3(0.8, 1, 1.5)
	var skull := mesh_at(body, Vector3(0, 0.95, -0.9), hide, beast)
	skull.scale = Vector3(0.62, 0.7, 0.7)
	for side in [-1.0, 1.0]:
		cylinder(Vector3(side * 0.32, 1.5, -0.85), 0, 0.15, 0.55, stone, beast)
		for z in [-0.65, 0.65]:
			box(Vector3(side * 0.45, 0.3, z), Vector3(0.23, 0.6, 0.25), hide, false, beast)
		box(Vector3(side * 0.22, 1.04, -1.4), Vector3(0.09, 0.08, 0.05), material("e9a464", true), false, beast)
	sign_text("石角兽 · 山林守卫", beast_origin + Vector3(0, 3, 0), 25)

func pine(at: Vector3, size: float) -> void:
	cylinder(at + Vector3.UP * size * 2.3, size * 0.09, size * 0.17, size * 4.6, wood)
	for layer in range(3):
		cylinder(at + Vector3.UP * size * (2.9 + layer * 1.0), 0.05, size * (1.7 - layer * 0.32), size * 2.8, leaf)

func house(at: Vector3) -> void:
	box(at + Vector3(0, 1.4, 0), Vector3(4.2, 2.8, 3.8), material("c1baa2"), true)
	box(at + Vector3(0, 1, -1.92), Vector3(0.9, 2, 0.06), wood)
	var roof := PrismMesh.new()
	roof.size = Vector3(5.3, 1.8, 4.8)
	mesh_at(roof, at + Vector3(0, 3.45, 0), material("444e4b"))
	for x in [-1.3, 1.3]:
		box(at + Vector3(x, 1.5, -1.94), Vector3(0.7, 0.8, 0.07), wood)
