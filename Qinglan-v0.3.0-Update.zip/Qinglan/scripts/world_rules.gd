extends RefCounted

const LIMIT := 78.0
const HERB_REGROW := 45.0
const MONSTER_RESPAWN := 60.0
const FIELD_IDS := ["wolf0", "wolf1", "wolf2", "boar0", "boar1", "boar2", "mire0", "mire1", "mire2", "stone0", "stone1", "stone2"]
const FIELD_SPAWNS := [Vector3(-42, 0, 45), Vector3(-58, 0, 50), Vector3(-45, 0, 65),
	Vector3(38, 0, 47), Vector3(54, 0, 56), Vector3(65, 0, 40),
	Vector3(-43, 0, -42), Vector3(-60, 0, -52), Vector3(-43, 0, -64),
	Vector3(48, 0, -45), Vector3(65, 0, -53), Vector3(59, 0, -68)]
const SURVEY := Vector3(66, 0, -32)
const BUY := {"herb": 12, "seed": 8, "heal": 15, "mana": 12}
const SELL := {"herb": 5, "core": 22}
const ORDER_REWARDS := {"herbs": 35, "hunt": 65, "survey": 45}
