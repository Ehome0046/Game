extends SceneTree
## Run through tools/check.py, which isolates all save files in a temporary project.

const Progress = preload("res://scripts/progress.gd")
const Game = preload("res://scripts/game.gd")
var checks := 0
var failures := 0
var capture_dir := ""

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-dir="):
			capture_dir = arg.trim_prefix("--capture-dir=")
	call_deferred("run")

func check(condition: bool, description: String) -> void:
	checks += 1
	if condition:
		print("PASS: " + description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func frames(count: int) -> void:
	for i in range(count):
		await physics_frame

func capture(name: String) -> void:
	if capture_dir.is_empty():
		return
	await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	check(image.save_png(capture_dir.path_join(name + ".png")) == OK, "render capture " + name)

func run() -> void:
	var state = Progress.new()
	check(not state.cast(), "unlearned spell is blocked")
	check(not state.breakthrough(), "breakthrough needs all prerequisites")
	check(state.gather(0) and not state.gather(0), "harvest is awarded once")
	check(not state.gather(-1) and not state.gather(5), "out of range resource IDs are rejected")
	state.learned = true
	state.qi = 13
	check(not state.cast() and state.qi == 13, "insufficient qi does not spend resource")
	var data: Dictionary = state.snapshot(Vector3.ZERO)
	var restored = Progress.new()
	check(restored.restore(JSON.parse_string(JSON.stringify(data))), "JSON save roundtrip")
	for invalid in [null, {}, {"version": 900}]:
		check(not restored.restore(invalid), "invalid save rejected")
	var corrupt: Dictionary = data.duplicate(true)
	corrupt.collected = [0, 0]
	check(not restored.restore(corrupt), "duplicate harvest IDs in save rejected")
	corrupt = data.duplicate(true)
	corrupt.position = [999, 0, 0]
	check(not restored.restore(corrupt), "out of valley save rejected")
	corrupt = data.duplicate(true)
	corrupt.realm = 2
	check(not restored.restore(corrupt), "impossible progression rejected")
	check(restored.character_name == "无名" and restored.realm == 0, "invalid save does not mutate live state")
	var game = Game.new()
	root.add_child(game)
	await frames(3)
	await capture("01-character")
	game.name_input.text = "青禾"
	game.robe_input.select(1)
	game.request_new()
	check(game.playing and game.progress.character_name == "青禾" and game.progress.robe == 1, "create named character and select robe")
	await frames(8)
	var start: Vector3 = game.traveler.position
	Input.action_press("forward")
	await frames(30)
	Input.action_release("forward")
	check(game.traveler.position.z < start.z - 1.0, "physics input moves traveler forward")
	check(game.traveler.is_on_floor() and absf(game.traveler.position.y) < 0.2, "player collides with the valley floor")
	var before: Vector3 = game.traveler.position
	game.set_paused(true)
	Input.action_press("forward")
	await frames(10)
	Input.action_release("forward")
	check(game.traveler.position.is_equal_approx(before), "pause stops movement")
	game.set_paused(false)
	check(not game.cast_sword(), "scene blocks attack before learning")
	await capture("02-valley")
	game.traveler.position = Vector3(0, 0.1, -21)
	game.interact()
	check(game.progress.learned, "interact with cave scroll learns sword spell")
	for id in range(3):
		for point in game.valley.interactions:
			if point.kind == "herb" and point.id == id:
				game.traveler.position = point.position + Vector3.UP * 0.1
				game.interact()
	check(game.progress.herbs() == 3, "harvest three distinct herbs through world interactions")
	var resources: int = game.progress.herbs()
	game.interact()
	check(game.progress.herbs() == resources, "repeat interaction cannot duplicate herb")
	game.traveler.position = game.valley.altar + Vector3.UP * 0.1
	game.interact()
	check(game.progress.realm == 0, "altar blocks breakthrough without beast core")
	game.traveler.position = game.valley.beast.position + Vector3(1.4, 0.1, 0)
	game.enemy_cooldown = 0
	var hp_before_hit: float = game.progress.hp
	await frames(45)
	check(game.progress.hp < hp_before_hit, "telegraphed beast strike damages nearby player")
	game.traveler.position = game.valley.beast.position + Vector3(1.4, 0.1, 0)
	game.windup = 0.12
	var hp_before_dodge: float = game.progress.hp
	Input.action_press("dodge")
	await frames(1)
	Input.action_release("dodge")
	await frames(12)
	check(game.progress.hp == hp_before_dodge, "space dodge avoids telegraphed strike")
	game.traveler.invincible = 0
	game.traveler.position = game.valley.beast.position + Vector3(1.4, 0.1, 0)
	game.progress.hp = 18
	game.windup = 0.01
	await frames(2)
	check(game.progress.hp == 100 and game.traveler.position.distance_to(game.valley.altar) < 3, "defeat respawns player safely at altar")
	check(game.progress.herbs() == 3 and game.beast_hp == 112, "defeat keeps inventory and resets living beast")
	game.traveler.position = Vector3(10, 0.1, -8)
	game.traveler.yaw = -1.2
	await frames(2)
	var successful_casts := 0
	for i in range(4):
		if game.cast_sword():
			successful_casts += 1
		if i == 0:
			game.set_paused(true)
			var hp_before: float = game.beast_hp
			await frames(15)
			check(game.beast_hp == hp_before, "pause also stops in-flight sword damage")
			game.set_paused(false)
		await frames(38)
	check(successful_casts == 4, "four timed sword casts execute")
	check(game.progress.beast_dead and not game.progress.core and not game.valley.beast.visible and game.progress.pending_loot.size() >= 2, "sword defeats beast and leaves physical core and coin loot")
	pickup_drops(game)
	check(game.progress.core, "E pickup transfers dropped beast core into inventory")
	game.traveler.position = game.valley.altar + Vector3.UP * 0.1
	game.interact()
	check(game.progress.realm == 1 and game.progress.herbs() == 0 and not game.progress.core, "altar consumes materials and advances realm")
	check(game.progress.hp == 140 and game.progress.max_qi() == 140, "breakthrough raises health and qi limits")
	check(not game.progress.breakthrough(), "cannot repeat the same breakthrough")
	game.traveler.position = Vector3(0, 0.1, 13)
	game.traveler.yaw = 0
	game.update_hud()
	await frames(3)
	await capture("03-breakthrough")
	check(game.save_game(false), "save file written atomically")
	game.progress.character_name = "changed"
	check(game.continue_game() and game.progress.character_name == "青禾" and game.progress.realm == 1, "continue restores identity and realm")
	check(game.progress.collected.size() == 3 and game.progress.beast_dead and not game.valley.beast.visible, "continue preserves harvested resources and defeated beast")
	await adventure_checks(game)
	var file := FileAccess.open(Game.SAVE, FileAccess.WRITE)
	file.store_string("{broken-json")
	file.close()
	check(not game.continue_game() and game.progress.character_name == "青禾", "corrupt save fails safely without changing active character")
	check(ProjectSettings.globalize_path(Game.SAVE).begins_with(ProjectSettings.globalize_path("res://")), "save is inside project, not the OS profile")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)

func walk_to_interaction(game: Node3D, kind: String, id := -1) -> void:
	for point in game.valley.interactions:
		if point.kind == kind and (id < 0 or point.id == id):
			game.traveler.position = point.position + Vector3(0, 0.1, 0.7)
			game.traveler.velocity = Vector3.ZERO
			game.interact()
			return
	check(false, "interaction exists: " + kind)

func pickup_drops(game: Node3D) -> void:
	var drops: Array = game.progress.pending_loot.duplicate(true)
	for item in drops:
		game.traveler.position = Vector3(item.position[0], 0.1, item.position[2])
		game.traveler.velocity = Vector3.ZERO
		game.interact()

func adventure_checks(game: Node3D) -> void:
	var p = game.progress
	check(not p.transfer_herb(false), "unowned home cannot transfer resources")
	p.plant_or_harvest(0)
	check(p.plots[0] == -1, "unowned plot cannot plant")
	check(not p.take_relic(), "relic cannot be claimed before guardian defeat")
	check(not game.cast_attack("fire"), "fire spell locked before inheritance")
	p.qi = p.max_qi()
	check(game.cast_shield(), "shield spends qi and activates")
	var hp: float = p.hp
	game.take_damage(28)
	check(p.hp == hp and game.shield_strength == 17, "shield absorbs damage up to capacity")
	game.take_damage(28)
	check(p.hp == hp - 11 and game.shield_strength == 0, "shield overflow damages health")
	var qi: float = p.qi
	check(not game.cast_shield() and p.qi == qi, "shield cooldown blocks duplicate spending")
	game.shield_cooldown = 0
	game.cast_shield()
	game.shield_time = 0.01
	await frames(2)
	check(game.shield_strength == 0 and not game.shield_mesh.visible, "shield expires on gameplay clock")
	game.traveler.position = Vector3(24, 0.1, 0)
	game.traveler.velocity = Vector3.ZERO
	var spider: Dictionary = game.adventure.enemies[0]
	spider.cooldown = 0
	hp = p.hp
	await frames(90)
	check(p.hp < hp, "ranged enemy telegraph and projectile damage player")
	p.qi = p.max_qi()
	game.combo_window = 0
	for i in range(3):
		game.cast_sword()
		await frames(35)
	check(p.spitter_dead and spider.hp == 0, "sword combo defeats new ranged enemy")
	pickup_drops(game)
	var herbs_before: int = p.herbs()
	game.adventure.hit("spitter", 999)
	check(p.herbs() == herbs_before, "defeated enemy cannot award duplicate loot")
	game.traveler.position = Vector3(24, 0.1, -16)
	game.traveler.yaw = 0
	game.traveler.velocity = Vector3.ZERO
	Input.action_press("forward")
	await frames(40)
	Input.action_release("forward")
	check(game.traveler.position.z > -18.1, "sealed stone door blocks physical movement")
	walk_to_interaction(game, "rune", 1)
	check(p.runes == 0, "wrong rune order resets puzzle")
	for i in range(3):
		walk_to_interaction(game, "rune", i)
	check(p.runes == 3, "world rune interactions solve mountain-water-moon sequence")
	await frames(2)
	check(not game.adventure.gate.visible and game.adventure.gate_shape.disabled, "solved puzzle removes door and collision")
	game.traveler.position = Vector3(24, 0.1, -16)
	game.traveler.velocity = Vector3.ZERO
	Input.action_press("forward")
	await frames(75)
	Input.action_release("forward")
	check(game.traveler.position.z < -20, "opened door allows traversal into ruins")
	await capture("04-ruins")
	p.hp = p.max_hp()
	p.qi = p.max_qi()
	game.combo_window = 0
	var guardian: Dictionary = game.adventure.enemies[1]
	var damages: Array[float] = []
	for i in range(6):
		var before: float = guardian.hp
		game.cast_sword()
		await frames(35)
		damages.append(before - guardian.hp)
		if i == 2:
			check(guardian.hp < 140 and guardian.label.text.contains("狂暴"), "guardian enters second phase at half health")
	check(damages[0] < damages[1] and damages[1] < damages[2], "timed three-hit sword combo increases damage")
	check(p.guardian_dead and not guardian.node.visible, "sword combat defeats ruins guardian")
	pickup_drops(game)
	walk_to_interaction(game, "relic")
	check(p.relic and p.seeds == 3, "inheritance unlocks fire and grants seeds")
	var seeds_before: int = p.seeds
	walk_to_interaction(game, "relic")
	check(p.seeds == seeds_before, "inheritance reward is awarded once")
	walk_to_interaction(game, "claim_home")
	check(p.home_claimed and p.seeds == 6, "claim home through world interaction and receive starter seeds")
	walk_to_interaction(game, "claim_home")
	check(p.seeds == 6, "home cannot grant starter seeds twice")
	walk_to_interaction(game, "decor")
	check(p.home_style == 1, "home decor interaction changes banner and lighting preset")
	for i in range(3):
		walk_to_interaction(game, "plot", i)
	check(p.seeds == 3 and p.plots[0] > p.world_time, "three plots consume three seeds")
	var time_before: float = p.world_time
	game.set_paused(true)
	await frames(10)
	check(p.world_time == time_before, "pause freezes crop growth clock")
	game.set_paused(false)
	# Position the clock at the maturity boundary, then let real scene updates cross it.
	p.world_time = p.plots.max() - 0.05
	await frames(6)
	herbs_before = p.herbs()
	walk_to_interaction(game, "plot", 0)
	check(p.herbs() == herbs_before + 2 and p.seeds == 4, "mature crop yields herbs and renewable seed")
	walk_to_interaction(game, "plot", 0)
	check(p.herbs() == herbs_before + 2 and p.seeds == 3, "repeat harvest replants instead of duplicating reward")
	game.traveler.position = Vector3(-25, 0.1, 5)
	game.traveler.yaw = PI
	await frames(3)
	await capture("06-lingtian")
	walk_to_interaction(game, "storage")
	check(game.paused and game.adventure.storage_panel.visible, "storage opens interactive panel and pauses danger")
	herbs_before = p.herbs()
	game.adventure.transfer(true)
	check(p.herbs() == herbs_before - 1 and p.vault_herbs == 1, "storage moves resource from bag to vault")
	game.adventure.transfer(false)
	check(p.herbs() == herbs_before and p.vault_herbs == 0, "storage withdraw preserves total resources")
	game.set_paused(false)
	walk_to_interaction(game, "bed")
	herbs_before = p.herbs()
	check(game.adventure.cultivate_near_bed() and p.cultivation == 1 and p.herbs() == herbs_before - 2, "home cultivation consumes herbs and advances training")
	check(p.max_hp() == 145 and p.max_qi() == 150, "home cultivation raises gameplay stats")
	game.traveler.position = Vector3(-25, 0.1, 20)
	game.traveler.yaw = 0
	await frames(3)
	await capture("05-home")
	check(game.save_game(false) and game.continue_game(), "expanded save survives scene restart")
	p = game.progress
	check(p.relic and p.runes == 3 and p.guardian_dead and p.home_claimed and p.home_style == 1 and p.cultivation == 1 and p.plots[0] > 0, "save preserves ruin, home, decor, crop and cultivation progress")
	# A valid branch of play: player has inheritance but has not defeated optional spider.
	var fixture: Dictionary = p.snapshot(Vector3(24, 0.1, 0))
	fixture.spitter_dead = false
	check(p.restore(fixture), "valid optional enemy encounter fixture loads")
	game.start_game(Vector3(24, 0.1, 0))
	check(not game.adventure.return_home(), "home recall is blocked during combat")
	p.qi = p.max_qi()
	await frames(2)
	check(game.cast_attack("fire"), "inherited fire spell launches at live target")
	qi = p.qi
	check(not game.cast_attack("fire") and p.qi == qi, "fire cooldown prevents duplicate resource cost")
	await frames(35)
	check(game.adventure.enemies[0].hp <= 30, "fire projectile inflicts distinct damage")
	qi = p.qi
	check(not game.cast_attack("fire") and p.qi == qi, "fire-specific cooldown outlasts sword recovery")
	game.cast_sword()
	await frames(35)
	check(game.adventure.return_home() and game.traveler.position.distance_to(game.adventure.HOME) < 0.2, "home recall succeeds after combat")
	# A real v1 fixture uses the original on-disk schema, not the new serializer.
	var legacy := {"version": 1, "name": "青禾", "robe": 1, "learned": true, "collected": [0, 1, 2, 3],
		"core": false, "beast_dead": true, "realm": 1, "hp": 125, "qi": 87, "position": [0, 0.1, 13]}
	var legacy_text := JSON.stringify(legacy)
	var file := FileAccess.open(Game.SAVE, FileAccess.WRITE)
	file.store_string(legacy_text)
	file.close()
	check(game.continue_game() and game.progress.realm == 1 and game.progress.herbs() == 1, "v1 migration preserves realm and remaining herbs")
	check(FileAccess.get_file_as_string(Game.SAVE + ".v1.bak") == legacy_text, "migration keeps exact original save backup")
	check(game.save_game(false) and JSON.parse_string(FileAccess.get_file_as_string(Game.SAVE)).version == Progress.VERSION, "migrated journey saves using current schema")
	var invalid: Dictionary = game.progress.snapshot(Vector3.ZERO)
	invalid.plots = [0, 0]
	check(not game.progress.restore(invalid), "malformed crop save cannot mutate live state")
