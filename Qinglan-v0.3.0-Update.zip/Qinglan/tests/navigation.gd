extends SceneTree

const Game = preload("res://scripts/game.gd")
var checks := 0
var failures := 0
var capture_dir := ""

func _initialize() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture-dir="):
			capture_dir = arg.trim_prefix("--capture-dir=")
	call_deferred("run")

func check(value: bool, description: String) -> void:
	checks += 1
	if value:
		print("PASS: " + description)
	else:
		failures += 1
		push_error("FAIL: " + description)

func frames(count: int) -> void:
	for i in range(count):
		await physics_frame

func key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	root.push_input(event, true)

func capture(name: String) -> void:
	if capture_dir.is_empty():
		return
	await process_frame
	await RenderingServer.frame_post_draw
	check(root.get_texture().get_image().save_png(capture_dir.path_join(name + ".png")) == OK, "render " + name)

func run() -> void:
	var game = Game.new()
	root.add_child(game)
	game.name_input.text = "寻居"
	game.begin_new()
	await frames(4)
	var nav = game.navigation
	check(not game.progress.learned and not game.progress.home_claimed and nav.tracking, "new character immediately receives home route before cultivation")
	check(nav.guide.visible and nav.guide_text.text.contains("无需通关遗府") and game.quest.text.contains("安家支线"), "home instructions are independent of main quest")
	check(nav.route.size() >= 5 and nav.route[0].at.z > 20, "village route starts around the south side of houses")
	check(nav.breadcrumbs.any(func(node): return node.visible), "gold ground route markers are visible")
	check(nav.marker.visible and nav.marker_text.text.contains("米"), "waypoint HUD shows distance")
	await capture("12-home-guide")
	key(KEY_M)
	await frames(2)
	check(nav.map_panel.visible and game.paused and paused and not game.traveler.enabled, "M opens map and pauses movement")
	var position: Vector3 = game.traveler.position
	Input.action_press("forward")
	await frames(6)
	Input.action_release("forward")
	check(game.traveler.position.is_equal_approx(position), "map viewing cannot move character")
	var home: Vector2 = nav.map_view.world_point(nav.CLAIM)
	var village: Vector2 = nav.map_view.world_point(Vector3(0, 0, 18))
	check(home.x < village.x and home.y > village.y, "map places home southwest of village using world coordinates")
	check(nav.map_text.text.contains("无主石室门前按 E") and nav.map_text.text.contains("无需境界或战斗"), "map explains acquisition conditions and exact interaction")
	await capture("13-valley-map")
	key(KEY_M)
	await frames(2)
	check(not nav.map_panel.visible and not game.paused and game.traveler.enabled, "M closes map and resumes camera and movement")
	key(KEY_N)
	await frames(2)
	check(not nav.tracking and not nav.path_root.visible and not nav.marker.visible, "N hides optional route without hiding home instructions")
	check(nav.guide.visible, "acquisition instructions remain visible when tracking is hidden")
	key(KEY_M)
	nav.map_track.pressed.emit()
	await frames(2)
	check(nav.tracking and not nav.map_panel.visible and not game.paused, "map track button rebuilds route and returns to play")
	var qi: float = game.progress.qi
	var snapshots: Array[Vector3] = []
	# Follow the exact suggested waypoints through real physics, without teleporting.
	Input.action_press("forward")
	Input.action_press("run")
	for i in range(750):
		var target: Vector3 = nav.current_waypoint()
		var offset: Vector3 = target - game.traveler.position
		offset.y = 0
		if nav.cursor == nav.route.size() - 1 and offset.length() < 1.3:
			break
		game.traveler.yaw = atan2(-offset.x, -offset.z)
		if i % 60 == 0:
			snapshots.append(game.traveler.position)
		await physics_frame
	Input.action_release("forward")
	Input.action_release("run")
	await frames(2)
	check(game.traveler.position.distance_to(nav.CLAIM) < 2.5, "player physically walks from village to claim point without hitting houses or doorposts")
	check(snapshots.size() > 2 and snapshots.size() < 12, "guided walk makes progress and reaches home within bounded travel time")
	check(game.nearest().get("kind", "") == "claim_home" and game.prompt.text.contains("认领"), "arrival exposes the correct E claim prompt")
	game.traveler.yaw = 0
	await frames(10)
	await capture("14-home-arrival")
	key(KEY_E)
	await frames(10)
	check(game.progress.home_claimed and game.progress.seeds == 3, "E claims home along route and awards starter seeds")
	check(not game.progress.learned and game.progress.realm == 0 and not game.progress.guardian_dead, "home acquisition requires no spell, breakthrough or ruins clear")
	check(not nav.tracking and nav.guide_text.text.contains("H 脱战回府"), "claim finishes acquisition route and shows home usage")
	check(game.progress.qi == qi, "guidance and claiming spend no cultivation resources")
	check(game.save_game(false) and game.continue_game(), "claimed home reloads from existing save")
	await frames(10)
	check(game.progress.home_claimed and not nav.tracking and nav.guide_title.text.contains("你的洞府"), "loaded owned home does not repeat acquisition quest")
	# Check key approach regions against actual scene geometry at body height.
	for at in [Vector3(0, 0.1, -25), Vector3(0, 0.1, -34), Vector3(-25, 0.1, 9), Vector3(8, 0.1, 18)]:
		game.start_game(at)
		nav.start_tracking()
		await frames(2)
		var from: Vector3 = game.traveler.position
		var clear := true
		for point in nav.route:
			var ray := PhysicsRayQueryParameters3D.create(from + Vector3.UP, point.at + Vector3.UP)
			ray.exclude = [game.traveler.get_rid()]
			var hit: Dictionary = game.get_world_3d().direct_space_state.intersect_ray(ray)
			if not hit.is_empty():
				clear = false
				print("BLOCKED ROUTE: ", from, " -> ", point.at, " at ", hit.position, " collider ", hit.collider.get_path(), " parent position ", hit.collider.get_parent().global_position)
			from = point.at
		check(clear, "home route clears scene walls from " + str(at))
	game.start_game(Vector3(24, 0.1, -28))
	check(game.traveler.position.z > -18.5, "old save inside later-added sealed ruins is restored outside locked gate")
	key(KEY_M)
	key(KEY_ESCAPE)
	await frames(2)
	check(not nav.map_panel.visible and not game.paused, "Esc exits map without leaving invisible pause state")
	game.show_menu()
	await frames(2)
	check(not nav.visible and not nav.path_root.visible, "title screen hides all route overlays")
	game.queue_free()
	await process_frame
	print("RESULT: %d checks, %d failures" % [checks, failures])
	quit(1 if failures else 0)
